"""Runs the whole decision pipeline for one scenario."""
import random
import time
from dataclasses import dataclass
from typing import Optional

from . import config
from .models.grid import Grid
from .models.state import GridState, Scenario
from .services.crew_dispatch import DispatchPlan, plan_dispatch
from .services.load_shedding import SheddingPlan, plan_shedding
from .services.restoration import RestorationPlan, plan_restoration
from .services.stress_test import StressResult, run_stress_test
from .services.supply import SupplyLoads, assign_supply
from .utils import report


@dataclass
class ScenarioResult:
    scenario: Scenario
    baseline: SupplyLoads
    restoration: RestorationPlan
    dispatch: Optional[DispatchPlan]
    shedding: SheddingPlan
    stress: StressResult
    seconds: float


def run_scenario(grid: Grid, scenario: Scenario, seed: int = config.DEFAULT_SEED,
                 verbose: bool = True, plot: bool = False) -> ScenarioResult:
    rng = random.Random(seed)
    started = time.perf_counter()
    state = scenario.state

    # Normal operation (no faults): every zone on its own closed feeder.
    baseline = assign_supply(grid, GridState(), allow_open=False)

    # 1-2. Detect the fault (DFS, BFS) and restore supply (UCS).
    restoration = plan_restoration(grid, state, baseline)

    # 3. Send repair crews (A* travel times, Genetic Algorithm ordering).
    dispatch = plan_dispatch(grid, state, baseline, scenario.crews, rng)

    # 4. Fair load-shedding timetable (CSP, then Simulated Annealing).
    pool = [z.id for z in grid.zones
            if z.priority > config.CRITICAL_PRIORITY and z.id not in restoration.isolated]
    shedding = plan_shedding(grid, restoration.deficit_mw(grid), pool, rng)

    # 5. Worst-case stress test (Minimax + alpha-beta pruning).
    stress = run_stress_test(grid, state, restoration.switch_ops)

    result = ScenarioResult(scenario, baseline, restoration, dispatch, shedding,
                            stress, time.perf_counter() - started)
    if verbose:
        report.print_scenario(grid, result)
    if plot:
        from .utils import visualization      # needs matplotlib, so import only when asked
        for path in visualization.save_scenario_plots(grid, result):
            print(f"  saved: {path}")
    return result
