"""Draws the grid map onto a matplotlib Axes.

Used by the command-line pictures (utils/visualization.py) and by the desktop GUI, so
both always show the same map. This module only uses the Axes/Figure API (no pyplot),
so it never opens a window or changes the matplotlib backend.
"""
import re
from typing import Dict, List, Optional, Tuple

from matplotlib.lines import Line2D

COLORS = {"normal": "#2e9e5b", "rerouted": "#2b7bd6", "shed": "#f0a020", "dark": "#d63a3a"}
STATUS_TEXT = {"normal": "Normal supply", "rerouted": "Re-routed",
               "shed": "Load-shed (rotating cuts)", "dark": "No power (isolated)"}
MARKERS = {"source": "s", "transformer": "^", "zone": "o", "depot": "D"}
DEPOT_COLOR = "#8a5bd6"
FOCUS_COLOR = "#e07b00"

# Stages of the pipeline, in order (used by the "step through" feature too).
STAGES = ["detect", "restore", "dispatch", "shed", "stress"]


# ---- small helpers ---------------------------------------------------------
def zone_status(result, zone_id: str) -> str:
    """normal | rerouted | shed | dark - the same rule the text report uses."""
    plan = result.restoration
    if zone_id in plan.loads.routes:
        old = result.baseline.routes.get(zone_id)
        return "normal" if old and old.lines == plan.loads.routes[zone_id].lines else "rerouted"
    return "shed" if zone_id in plan.capacity_short else "dark"


_GENERIC_WORDS = {"Hospital", "Hosp.", "Sector", "Depot", "Station"}


def short_name(name: str) -> str:
    """Shorten a node name for map labels, e.g. 'PIMS Hospital (G-8)' -> 'PIMS'."""
    text = re.sub(r"\s*\([^)]*\)", "", name)              # drop "(G-8)" style notes
    text = re.sub(r"\b\d+ kV\s*", "", text)               # drop voltage levels
    text = text.replace("Grid Station", "GS").replace("International", "Intl.")
    text = text.replace("Industrial Area", "Industrial").replace("Super Market", "Market")
    text = re.sub(r"\bPhase (\d+)", r"Ph. \1", text)
    words = [w for w in text.split() if w not in _GENERIC_WORDS]
    return " ".join(words) or name


def node_label(node) -> str:
    return f"{node.id} {short_name(node.name)}"


def _node_color(grid, state, result, node, stage) -> str:
    if node.type == "zone":
        if stage == "detect":                              # before any restoration
            report = result.restoration.report
            if node.id in report.dark_zones:
                return COLORS["dark"]
            if node.id in report.overload_zones:
                return COLORS["shed"]
            return COLORS["normal"]
        return COLORS[zone_status(result, node.id)]
    if node.type == "depot":
        return DEPOT_COLOR
    if node.id in state.failed_nodes or (
            node.type == "source" and state.capacity_of(grid, node.id) <= 0):
        return COLORS["dark"]
    if node.type == "source" and state.capacity_of(grid, node.id) < node.capacity_mw:
        return COLORS["shed"]
    return "#444444"


def _midpoint(grid, line):
    a, b = grid.nodes[line.a], grid.nodes[line.b]
    return (a.x + b.x) / 2, (a.y + b.y) / 2


# ---- the map ---------------------------------------------------------------
def draw_grid_map(ax, grid, result, stage: Optional[str] = None,
                  focus_zone: Optional[str] = None, show_labels: bool = True,
                  label_size: float = 8.0, legend: bool = True,
                  tighten: bool = True) -> Dict[str, Tuple[float, float]]:
    """Draw lines, nodes and labels. Returns {node_id: (x, y)}.

    stage       None = everything; or one of STAGES to show only what that step knows
    focus_zone  a zone id: its supply route is drawn thick and orange
    """
    state = result.scenario.state
    plan = result.restoration
    showing_switches = stage not in ("detect",)

    # -- power lines
    for line in grid.lines.values():
        a, b = grid.nodes[line.a], grid.nodes[line.b]
        closed_now = line.normally_open and line.id in plan.switch_ops and showing_switches
        if line.id in state.failed_lines:
            style = dict(color=COLORS["dark"], linestyle=":", linewidth=2.8)
        elif closed_now:
            style = dict(color=COLORS["rerouted"], linewidth=2.6)
        elif line.normally_open:
            style = dict(color="#bbbbbb", linestyle="--", linewidth=1)
        else:
            style = dict(color="#777777", linewidth=1.2)
        if focus_zone:                                     # fade everything but the route
            style["alpha"] = 0.35
        ax.plot([a.x, b.x], [a.y, b.y], zorder=1, **style)
        if line.id in state.failed_lines:                  # little red cross on a failed line
            mx, my = _midpoint(grid, line)
            ax.scatter(mx, my, marker="x", s=110, c=COLORS["dark"], linewidths=2.5, zorder=4)

    if focus_zone and focus_zone in plan.loads.routes:
        route = plan.loads.routes[focus_zone]
        for u, v in zip(route.nodes, route.nodes[1:]):
            ax.plot([grid.nodes[u].x, grid.nodes[v].x], [grid.nodes[u].y, grid.nodes[v].y],
                    color=FOCUS_COLOR, linewidth=4, zorder=2, solid_capstyle="round")

    # -- stage-specific overlays
    if stage == "dispatch" and result.dispatch:
        _draw_crew_paths(ax, grid, result.dispatch)
    if stage == "stress":
        _draw_worst_case(ax, grid, result.stress)

    # -- nodes
    positions = {}
    for node in grid.nodes.values():
        color = _node_color(grid, state, result, node, stage)
        size = {"source": 260, "transformer": 130, "zone": 70 + node.demand_mw * 7,
                "depot": 100}[node.type]
        ax.scatter(node.x, node.y, s=size, c=color, marker=MARKERS[node.type],
                   edgecolors="black", linewidths=0.9, zorder=3)
        if node.id in state.failed_nodes:                  # red ring around a failed node
            ax.scatter(node.x, node.y, s=size * 2.6, facecolors="none",
                       edgecolors=COLORS["dark"], linewidths=2.6, zorder=2)
        if stage == "shed" and node.id in plan.capacity_short:
            ax.scatter(node.x, node.y, s=size * 2.6, facecolors="none",
                       edgecolors=COLORS["shed"], linewidths=2.4, zorder=2)
        if node.id == focus_zone:
            ax.scatter(node.x, node.y, s=size * 2.8, facecolors="none",
                       edgecolors=FOCUS_COLOR, linewidths=2.6, zorder=2)
        if node.type == "zone" and node.priority == 1:     # hospital: white cross marker
            ax.scatter(node.x, node.y, s=34, c="white", marker="P", zorder=4)
        positions[node.id] = (node.x, node.y)

    xs = [p[0] for p in positions.values()]
    ys = [p[1] for p in positions.values()]
    ax.set_xlim(min(xs) - 3, max(xs) + 3)
    ax.set_ylim(min(ys) - 3, max(ys) + 3)
    ax.set_aspect("equal", adjustable="box")
    ax.set_xlabel("km east"), ax.set_ylabel("km north")
    ax.grid(alpha=0.2)
    if legend:
        ax.legend(handles=legend_handles(), loc="center left", bbox_to_anchor=(1.01, 0.5),
                  fontsize=label_size, frameon=False)
    if show_labels:
        if tighten:
            ax.figure.tight_layout()
        ax._node_labels = place_labels(ax, [(n.x, n.y, node_label(n)) for n in grid.nodes.values()],
                                       label_size)
    return positions


def legend_handles() -> List[Line2D]:
    dot = lambda c, text: Line2D([0], [0], marker="o", color="w", markerfacecolor=c,
                                 markersize=10, label=text)
    return [
        dot(COLORS["normal"], "zone: normal supply"),
        dot(COLORS["rerouted"], "zone: re-routed"),
        dot(COLORS["shed"], "zone: load-shed"),
        dot(COLORS["dark"], "no power / failed part (ringed)"),
        Line2D([0], [0], color=COLORS["dark"], linestyle=":", linewidth=2.5, label="failed line"),
        Line2D([0], [0], color=COLORS["rerouted"], linewidth=2.5, label="switch closed"),
        Line2D([0], [0], color="#bbbbbb", linestyle="--", label="open tie / backup"),
        Line2D([0], [0], marker="D", color="w", markerfacecolor=DEPOT_COLOR, markersize=8,
               label="repair depot"),
        Line2D([0], [0], marker="s", color="w", markerfacecolor=COLORS["shed"], markersize=9,
               label="derated grid station"),
        Line2D([0], [0], marker="P", color="w", markerfacecolor="#555555", markersize=8,
               label="white cross = hospital"),
    ]


def _draw_crew_paths(ax, grid, dispatch):
    """Dashed arrows depot -> first fault -> next fault ..., numbered per crew."""
    palette = ["#8a5bd6", "#c2185b", "#00897b", "#6d4c41"]
    for crew, (depot, visits) in enumerate(zip(dispatch.crews, dispatch.visits)):
        colour = palette[crew % len(palette)]
        here = grid.nodes[depot]
        for number, visit in enumerate(visits, 1):
            there = grid.nodes[visit.fault.site]
            ax.annotate("", xy=(there.x, there.y), xytext=(here.x, here.y), zorder=2,
                        arrowprops=dict(arrowstyle="->", color=colour, lw=2, linestyle="--",
                                        shrinkA=6, shrinkB=8))
            ax.annotate(f"crew {crew + 1}: #{number}", ((here.x + there.x) / 2, (here.y + there.y) / 2),
                        fontsize=9, color=colour, ha="center", zorder=5,
                        bbox=dict(boxstyle="round,pad=0.15", fc="white", ec=colour, lw=0.8))
            here = there


def _draw_worst_case(ax, grid, stress):
    """Mark what the adversary breaks (red X in a circle) and what the planner closes."""
    for action, ident in stress.line:
        if action == "fail" and ident in grid.nodes:
            n = grid.nodes[ident]
            ax.scatter(n.x, n.y, s=520, facecolors="none", edgecolors=COLORS["dark"],
                       linewidths=3, zorder=5)
            ax.scatter(n.x, n.y, s=120, c=COLORS["dark"], marker="x", linewidths=3, zorder=5)
        elif action == "fail" and ident in grid.lines:
            mx, my = _midpoint(grid, grid.lines[ident])
            ax.scatter(mx, my, s=420, facecolors="none", edgecolors=COLORS["dark"],
                       linewidths=3, zorder=5)
            ax.scatter(mx, my, s=120, c=COLORS["dark"], marker="x", linewidths=3, zorder=5)
        elif action == "close" and ident in grid.lines:
            a, b = grid.nodes[grid.lines[ident].a], grid.nodes[grid.lines[ident].b]
            ax.plot([a.x, b.x], [a.y, b.y], color=COLORS["rerouted"], linewidth=4,
                    zorder=2, linestyle="-")


# ---- label placement -------------------------------------------------------
_OFFSETS = [(8, 6), (8, -12), (-8, 6), (-8, -12), (0, 12), (0, -16), (14, 0), (-14, 0),
            (16, 14), (16, -20), (-16, 14), (-16, -20), (0, 24), (0, -28)]


def place_labels(ax, items: List[Tuple[float, float, str]], fontsize: float = 8.0) -> list:
    """Put each text label next to its point, avoiding other labels and markers.

    A simple greedy search: for every label try several offsets and keep the one that
    overlaps least with what has already been placed.
    """
    ax.apply_aspect()
    dpi = ax.figure.dpi
    char_w = fontsize * 0.58 * dpi / 72.0
    line_h = fontsize * 1.25 * dpi / 72.0
    pt = dpi / 72.0
    points = [(ax.transData.transform((x, y)), text) for x, y, text in items]
    markers = [(p[0] - 9 * pt, p[1] - 9 * pt, p[0] + 9 * pt, p[1] + 9 * pt) for p, _ in points]
    placed: List[Tuple[float, float, float, float]] = []
    artists = []
    box_area = ax.get_window_extent()
    bounds = (box_area.x0, box_area.y0, box_area.x1, box_area.y1)

    def overlap(a, b):
        w = min(a[2], b[2]) - max(a[0], b[0])
        h = min(a[3], b[3]) - max(a[1], b[1])
        return w * h if w > 0 and h > 0 else 0.0

    for index, ((px, py), text) in enumerate(points):
        width = len(text) * char_w
        best = None
        for dx, dy in _OFFSETS:
            x0 = px + dx * pt if dx >= 0 else px + dx * pt - width
            y0 = py + dy * pt
            box = (x0, y0, x0 + width, y0 + line_h)
            cost = sum(overlap(box, other) for other in placed)
            cost += sum(overlap(box, m) for i, m in enumerate(markers) if i != index) * 1.5
            cost += 4.0 * (width * line_h - overlap(box, bounds))   # keep inside the map
            cost += 0.05 * (abs(dx) + abs(dy))             # prefer close labels
            if best is None or cost < best[0]:
                best = (cost, dx, dy, box)
        _, dx, dy, box = best
        placed.append(box)
        ha = "left" if dx >= 0 else "right"
        artists.append(ax.annotate(text, items[index][:2], textcoords="offset points",
                    xytext=(dx, dy + 2), ha=ha, fontsize=fontsize, zorder=6,
                    bbox=dict(boxstyle="round,pad=0.12", fc="white", ec="none", alpha=0.75)))
    return artists
