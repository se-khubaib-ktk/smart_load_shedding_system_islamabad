"""Matplotlib pictures: grid map, shedding timetable and algorithm convergence."""
from typing import List

import matplotlib

matplotlib.use("Agg")                       # draw to files, no window needed
import matplotlib.pyplot as plt

from .. import config

from .map_drawing import COLORS, draw_grid_map, short_name, zone_status

def save_scenario_plots(grid, result) -> List[str]:
    config.OUTPUT_DIR.mkdir(exist_ok=True)
    prefix = config.OUTPUT_DIR / f"scenario_{result.scenario.id}"
    paths = [draw_map(grid, result, f"{prefix}_map.png")]
    if result.shedding.sa_schedule:
        paths.append(draw_timetable(grid, result.shedding, f"{prefix}_timetable.png"))
    paths.append(draw_convergence(result, f"{prefix}_convergence.png"))
    return [str(p) for p in paths]


def _zone_status(result, zone_id):
    return zone_status(result, zone_id)          # same rule the GUI uses


def draw_map(grid, result, filename):
    fig, ax = plt.subplots(figsize=(14, 8))
    draw_grid_map(ax, grid, result)                # shared with the desktop GUI
    ax.set_title(f"{grid.city} - scenario {result.scenario.id}: {result.scenario.name}")
    fig.savefig(filename, dpi=130, bbox_inches="tight"); plt.close(fig)
    return filename


def draw_timetable(grid, plan, filename):
    hours = config.HOURS_PER_SLOT
    pool = plan.pool
    fig, axes = plt.subplots(1, 2, figsize=(12, 0.45 * len(pool) + 2.2), sharey=True)
    for ax, schedule, title in ((axes[0], plan.csp_schedule, "CSP timetable"),
                                (axes[1], plan.sa_schedule, "After Simulated Annealing")):
        grid_values = [[1 if z in slot else 0 for slot in schedule] for z in pool]
        ax.imshow(grid_values, cmap="Oranges", aspect="auto", vmin=0, vmax=1.4)
        ax.set_xticks(range(len(schedule)))
        ax.set_xticklabels([f"{t * hours:02d}" for t in range(len(schedule))], fontsize=8)
        ax.set_yticks(range(len(pool)))
        ax.set_yticklabels([f"{z} {short_name(grid.nodes[z].name)}" for z in pool], fontsize=9)
        ax.set_xlabel("hour of day (orange = power cut)")
        ax.set_title(title, fontsize=10)
    fig.tight_layout(); fig.savefig(filename, dpi=130); plt.close(fig)
    return filename


def draw_convergence(result, filename):
    fig, axes = plt.subplots(1, 2, figsize=(10, 3.6))
    if result.dispatch:
        axes[0].plot(result.dispatch.history, color="#2b7bd6")
        axes[0].set_title("Genetic Algorithm: crew dispatch cost")
        axes[0].set_xlabel("generation"); axes[0].set_ylabel("weighted completion cost")
    else:
        axes[0].text(0.5, 0.5, "no repairs needed", ha="center"); axes[0].set_axis_off()
    if result.shedding.sa_history:
        axes[1].plot(result.shedding.sa_history, color="#f0a020")
        axes[1].set_title("Simulated Annealing: timetable energy")
        axes[1].set_xlabel("step"); axes[1].set_ylabel("best energy")
    else:
        axes[1].text(0.5, 0.5, "no shedding needed", ha="center"); axes[1].set_axis_off()
    fig.tight_layout(); fig.savefig(filename, dpi=130); plt.close(fig)
    return filename
