"""Plain-text report for one scenario."""
from .. import config

LINE = "=" * 78
THIN = "-" * 78


def print_scenario(grid, result) -> None:
    sc = result.scenario
    print(f"\n{LINE}\nSCENARIO {sc.id}: {sc.name}\n{LINE}")
    print(sc.description)
    _detection(grid, result)
    _restoration(grid, result)
    _dispatch(grid, result)
    _shedding(grid, result)
    _stress(result)
    _summary(grid, result)


def _title(text):
    print(f"\n{text}\n{THIN}")


def _names(grid, ids):
    return ", ".join(f"{z} ({grid.nodes[z].name})" for z in ids) if ids else "none"


def _detection(grid, result):
    rep = result.restoration.report
    _title("1. FAULT DETECTION  [DFS finds dark zones, BFS finds nearest backup]")
    print(f"Energised nodes (DFS): {len(rep.energized)} of {len(grid.nodes) - len(grid.depots)}")
    print(f"Zones cut off:         {_names(grid, rep.dark_zones)}")
    print(f"Zones overloaded:      {_names(grid, rep.overload_zones)}")
    for zone, hops in rep.backup_hops.items():
        text = "no backup path (needs repair)" if hops is None else f"{hops} line(s) to a source"
        print(f"  BFS  {zone}: {text}")


def _restoration(grid, result):
    plan = result.restoration
    _title("2. SERVICE RESTORATION  [Uniform Cost Search, hospitals first]")
    base = result.baseline.routes
    print(f"{'Zone':<5}{'Name':<24}{'MW':>4}  {'Status':<22}Route")
    for zone in sorted(grid.zones, key=lambda z: (z.priority, z.id)):
        route = plan.loads.routes.get(zone.id)
        if route:
            changed = base.get(zone.id) is None or base[zone.id].lines != route.lines
            status = "RE-ROUTED" if changed else "normal supply"
            path = " > ".join(reversed(route.nodes))
            note = f"{path}  (close {', '.join(route.switches)})" if route.switches else path
        elif zone.id in plan.capacity_short:
            status, note = "SHED (no spare MW)", "reachable, but sources are full"
        else:
            status, note = "NO POWER (isolated)", "waiting for repair crew"
        print(f"{zone.id:<5}{zone.name[:23]:<24}{zone.demand_mw:>4.0f}  {status:<22}{note}")
    print(f"Switches to close: {', '.join(plan.switch_ops) or 'none'}")
    print(f"Served {plan.served_mw(grid):.0f} MW of {grid.total_demand():.0f} MW "
          f"({plan.unserved_mw(grid):.0f} MW not served)")


def _dispatch(grid, result):
    plan = result.dispatch
    _title("3. REPAIR CREW DISPATCH  [A* travel times + Genetic Algorithm]")
    if plan is None:
        print("No physical faults, so no repair crews are needed.")
        return
    for crew, (depot, visits) in enumerate(zip(plan.crews, plan.visits), 1):
        stops = " -> ".join(f"{v.fault.id} (arrive {v.arrive:.0f}, done {v.finish:.0f} min)"
                            for v in visits) or "stays at depot"
        print(f"Crew {crew} from {depot}: {stops}")
    print(f"Weighted completion cost  GA: {plan.cost:,.0f}   " +
          "   ".join(f"{k}: {v:,.0f}" for k, v in plan.baselines.items()))
    print(f"All repairs finished after {plan.makespan:.0f} minutes "
          f"(A* expanded {plan.astar_expanded} road nodes)")


def _shedding(grid, result):
    plan = result.shedding
    _title("4. LOAD-SHEDDING TIMETABLE  [CSP finds it, Simulated Annealing improves it]")
    print(f"Deficit to cover: {plan.deficit_mw:.0f} MW   -   {plan.message}")
    if not plan.csp_schedule:
        return
    if plan.exempt:
        print(f"Too large to rotate (never shed): {', '.join(plan.exempt)}")
    print(f"CSP: {plan.csp_stats.nodes} assignments, {plan.csp_stats.backtracks} backtracks, "
          f"max {plan.consecutive_limit} slots in a row")
    hours = config.HOURS_PER_SLOT
    header = "".join(f"{t * hours:02d} " for t in range(config.SLOTS_PER_DAY))
    print(f"\nTimetable after annealing (X = power cut, . = power on, one column per {hours} h)")
    print(f"{'Zone':<22}{header}  cut hours")
    for zone in plan.pool:
        row = "".join(f" {'X' if zone in s else '.'} " for s in plan.sa_schedule)
        print(f"{zone + ' ' + grid.nodes[zone].name[:17]:<22}{row}  {plan.sa_metrics.shed_hours[zone]:>3}")
    c, s = plan.csp_metrics, plan.sa_metrics
    print(f"\n{'':<20}{'CSP':>10}{'After SA':>12}")
    print(f"{'Fairness (Jain)':<20}{c.jain_fairness:>10.3f}{s.jain_fairness:>12.3f}")
    print(f"{'Breaker operations':<20}{c.breaker_operations:>10}{s.breaker_operations:>12}")
    print(f"{'Energy not served':<20}{c.unmet_mwh:>7.0f} MWh{s.unmet_mwh:>9.0f} MWh")


def _stress(result):
    st = result.stress
    _title("5. STRESS TEST  [Minimax with alpha-beta pruning, adversary vs planner]")
    steps = []
    for action, ident in st.line:
        steps.append({"fail": f"adversary fails {ident}", "close": f"planner closes {ident}",
                      "hold": "planner holds"}[action])
    print("Worst case: " + "; ".join(steps))
    print(f"Weighted load lost now: {st.current_value:.0f}   after worst case: {st.worst_value:.0f}"
          f"  (of {st.total_weighted:.0f})")
    print(f"Resilience score: {st.resilience * 100:.0f}%   "
          f"(search visited {st.stats.nodes} states, pruned {st.stats.pruned} branches)")


def _summary(grid, result):
    plan = result.restoration
    _title("SUMMARY")
    total = grid.total_demand()
    print(f"Supplied after restoration: {plan.served_mw(grid) / total * 100:.0f}% of demand | "
          f"rotating cuts cover {plan.deficit_mw(grid):.0f} MW | "
          f"isolated zones: {len(plan.isolated)} | run time {result.seconds:.2f}s")
