"""Small result object shared by all path-search algorithms."""
from dataclasses import dataclass, field
from typing import Any, List, Optional


@dataclass
class SearchResult:
    """Outcome of a path search.

    path      -- list of nodes from start to goal (None if no path exists)
    cost      -- total path cost (number of hops for BFS)
    expanded  -- how many nodes the algorithm expanded (for benchmarking)
    """
    path: Optional[List[Any]] = None
    cost: float = 0.0
    expanded: int = 0

    @property
    def found(self) -> bool:
        return self.path is not None
