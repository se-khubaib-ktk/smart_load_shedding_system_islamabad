"""Depth-First Search: find every node reachable from a start node."""
from typing import Callable, Hashable, Iterable, List


def dfs(start: Hashable,
        neighbors: Callable[[Hashable], Iterable[Hashable]]) -> List[Hashable]:
    """Return all nodes reachable from `start`, in the order DFS visits them."""
    visited = []
    seen = {start}
    stack = [start]

    while stack:
        node = stack.pop()
        visited.append(node)
        for nxt in neighbors(node):
            if nxt not in seen:
                seen.add(nxt)
                stack.append(nxt)

    return visited
