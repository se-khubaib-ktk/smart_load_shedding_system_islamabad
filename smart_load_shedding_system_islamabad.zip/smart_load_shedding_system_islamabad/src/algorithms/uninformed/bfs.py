"""Breadth-First Search: fewest-hops path in an unweighted graph."""
from collections import deque
from typing import Callable, Hashable, Iterable

from ..result import SearchResult


def bfs(start: Hashable,
        neighbors: Callable[[Hashable], Iterable[Hashable]],
        is_goal: Callable[[Hashable], bool]) -> SearchResult:
    """Return the path with the fewest edges from `start` to a goal node."""
    queue = deque([start])
    parent = {start: None}
    expanded = 0

    while queue:
        node = queue.popleft()
        expanded += 1
        if is_goal(node):
            path = []
            while node is not None:
                path.append(node)
                node = parent[node]
            path.reverse()
            return SearchResult(path, len(path) - 1, expanded)
        for nxt in neighbors(node):
            if nxt not in parent:
                parent[nxt] = node
                queue.append(nxt)

    return SearchResult(None, 0.0, expanded)
