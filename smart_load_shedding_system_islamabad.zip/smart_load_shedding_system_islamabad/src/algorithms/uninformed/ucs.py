"""Uniform Cost Search: cheapest path in a weighted graph (Dijkstra-style)."""
import heapq
from itertools import count
from typing import Callable, Hashable, Iterable, Tuple

from ..result import SearchResult


def ucs(start: Hashable,
        neighbors: Callable[[Hashable], Iterable[Tuple[Hashable, float]]],
        is_goal: Callable[[Hashable], bool]) -> SearchResult:
    """Return the cheapest path from `start` to the nearest goal node.

    `neighbors(node)` must yield (next_node, edge_cost) pairs.
    """
    tie = count()                      # keeps the heap from comparing nodes
    frontier = [(0.0, next(tie), start)]
    best_cost = {start: 0.0}
    parent = {start: None}
    expanded = 0

    while frontier:
        cost, _, node = heapq.heappop(frontier)
        if cost > best_cost.get(node, float("inf")):
            continue                   # stale entry
        expanded += 1
        if is_goal(node):
            path = []
            while node is not None:
                path.append(node)
                node = parent[node]
            path.reverse()
            return SearchResult(path, cost, expanded)
        for nxt, edge_cost in neighbors(node):
            new_cost = cost + edge_cost
            if new_cost < best_cost.get(nxt, float("inf")):
                best_cost[nxt] = new_cost
                parent[nxt] = node
                heapq.heappush(frontier, (new_cost, next(tie), nxt))

    return SearchResult(None, 0.0, expanded)
