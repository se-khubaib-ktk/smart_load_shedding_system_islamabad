"""Constraint Satisfaction: backtracking + MRV + forward checking."""
from dataclasses import dataclass
from typing import Any, Callable, Dict, Hashable, List, Optional


@dataclass
class CSPStats:
    nodes: int = 0          # assignments tried
    backtracks: int = 0     # times we had to undo an assignment


class _NodeLimit(Exception):
    """Raised internally when the search has used up its node budget."""


def solve_csp(domains: Dict[Hashable, List[Any]],
              consistent: Callable[[Dict[Hashable, Any]], bool],
              order_values: Optional[Callable[[Hashable, List[Any], Dict], List[Any]]] = None,
              node_limit: Optional[int] = None):
    """Solve a CSP and return (assignment or None, CSPStats).

    domains      -- variable -> list of possible values
    consistent   -- True if a (partial) assignment breaks no constraint
    order_values -- optional heuristic that sorts a variable's values
    node_limit   -- give up (return None) after this many assignments
    """
    stats = CSPStats()

    def backtrack(assignment, current_domains):
        if len(assignment) == len(domains):
            return assignment
        # MRV: pick the unassigned variable with the fewest remaining values
        var = min((v for v in domains if v not in assignment),
                  key=lambda v: len(current_domains[v]))
        values = current_domains[var]
        if order_values:
            values = order_values(var, values, assignment)

        for value in values:
            stats.nodes += 1
            if node_limit is not None and stats.nodes > node_limit:
                raise _NodeLimit()
            assignment[var] = value
            if consistent(assignment):
                pruned = _forward_check(assignment, current_domains, domains, consistent)
                if pruned is not None:
                    result = backtrack(assignment, pruned)
                    if result is not None:
                        return result
            del assignment[var]
            stats.backtracks += 1
        return None

    try:
        solution = backtrack({}, {v: list(vals) for v, vals in domains.items()})
    except _NodeLimit:
        solution = None
    return solution, stats


def _forward_check(assignment, current_domains, domains, consistent):
    """Remove values that can no longer work; None means a domain became empty."""
    pruned = {}
    for var in domains:
        if var in assignment:
            pruned[var] = current_domains[var]
            continue
        remaining = []
        for value in current_domains[var]:
            assignment[var] = value
            if consistent(assignment):
                remaining.append(value)
            del assignment[var]
        if not remaining:
            return None
        pruned[var] = remaining
    return pruned
