"""Minimax search with optional alpha-beta pruning."""
from dataclasses import dataclass
from typing import Any, Callable, Iterable, List, Tuple


@dataclass
class MinimaxStats:
    nodes: int = 0      # game states visited
    pruned: int = 0     # branches skipped by alpha-beta


def minimax(state: Any,
            depth: int,
            maximizing: bool,
            moves: Callable[[Any, bool], Iterable[Any]],
            apply_move: Callable[[Any, Any, bool], Any],
            evaluate: Callable[[Any], float],
            use_pruning: bool = True) -> Tuple[float, List[Any], MinimaxStats]:
    """Return (value, best_move_sequence, stats).

    The MAX player maximises `evaluate`, the MIN player minimises it.
    `moves(state, maximizing)` lists legal moves, `apply_move` returns the
    new state.
    """
    stats = MinimaxStats()

    def search(node, d, is_max, alpha, beta):
        stats.nodes += 1
        if d == 0:
            return evaluate(node), []
        options = list(moves(node, is_max))
        if not options:
            return evaluate(node), []

        best_value = float("-inf") if is_max else float("inf")
        best_line: List[Any] = []
        for index, move in enumerate(options):
            child = apply_move(node, move, is_max)
            value, line = search(child, d - 1, not is_max, alpha, beta)
            if (is_max and value > best_value) or (not is_max and value < best_value):
                best_value, best_line = value, [move] + line
            if use_pruning:
                if is_max:
                    alpha = max(alpha, best_value)
                else:
                    beta = min(beta, best_value)
                if beta <= alpha:
                    stats.pruned += len(options) - index - 1
                    break
        return best_value, best_line

    value, line = search(state, depth, maximizing, float("-inf"), float("inf"))
    return value, line, stats
