"""Genetic Algorithm (minimisation) plus helpers for permutation problems."""
import random
from typing import Callable, List, Sequence, Tuple, TypeVar

T = TypeVar("T")


def genetic_algorithm(random_individual: Callable[[], T],
                      fitness: Callable[[T], float],
                      crossover: Callable[[T, T], T],
                      mutate: Callable[[T], T],
                      population_size: int = 60,
                      generations: int = 80,
                      tournament: int = 3,
                      crossover_rate: float = 0.9,
                      mutation_rate: float = 0.25,
                      elite: int = 2,
                      rng: random.Random = None) -> Tuple[T, List[float]]:
    """Evolve a population and return (best_individual, best_fitness_history).

    Lower fitness is better.
    """
    rng = rng or random.Random()
    population = [random_individual() for _ in range(population_size)]
    scores = [fitness(ind) for ind in population]
    history = []

    for _ in range(generations):
        ranked = sorted(zip(scores, range(len(population))))
        history.append(ranked[0][0])
        # elitism: the best individuals survive unchanged
        next_pop = [population[i] for _, i in ranked[:elite]]

        while len(next_pop) < population_size:
            parent_a = _tournament_pick(population, scores, tournament, rng)
            parent_b = _tournament_pick(population, scores, tournament, rng)
            child = crossover(parent_a, parent_b) if rng.random() < crossover_rate else list(parent_a)
            if rng.random() < mutation_rate:
                child = mutate(child)
            next_pop.append(child)

        population = next_pop
        scores = [fitness(ind) for ind in population]

    best_index = min(range(len(population)), key=lambda i: scores[i])
    history.append(scores[best_index])
    return population[best_index], history


def _tournament_pick(population, scores, size, rng):
    contenders = rng.sample(range(len(population)), min(size, len(population)))
    return population[min(contenders, key=lambda i: scores[i])]


# ---- operators for permutations (order of repair jobs) -----------------
def order_crossover(parent_a: Sequence, parent_b: Sequence, rng: random.Random) -> List:
    """OX: copy a slice from parent A, fill the rest in parent B's order."""
    size = len(parent_a)
    if size < 2:
        return list(parent_a)
    i, j = sorted(rng.sample(range(size), 2))
    child = [None] * size
    child[i:j + 1] = parent_a[i:j + 1]
    kept = set(child[i:j + 1])
    fill = [gene for gene in parent_b if gene not in kept]
    position = 0
    for k in range(size):
        if child[k] is None:
            child[k] = fill[position]
            position += 1
    return child


def swap_mutation(individual: Sequence, rng: random.Random) -> List:
    """Swap two random genes."""
    child = list(individual)
    if len(child) >= 2:
        i, j = rng.sample(range(len(child)), 2)
        child[i], child[j] = child[j], child[i]
    return child
