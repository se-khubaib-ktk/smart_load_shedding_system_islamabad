"""Simulated Annealing (minimisation)."""
import math
import random
from typing import Callable, List, Optional, Tuple, TypeVar

T = TypeVar("T")


def simulated_annealing(initial: T,
                        neighbor: Callable[[T], Optional[T]],
                        energy: Callable[[T], float],
                        start_temp: float = 1.0,
                        cooling: float = 0.995,
                        steps: int = 5000,
                        rng: random.Random = None) -> Tuple[T, List[float]]:
    """Return (best_state, best_energy_history).

    `neighbor(state)` returns a modified copy, or None if no valid move was
    found (that step is simply skipped).
    """
    rng = rng or random.Random()
    current = initial
    current_energy = energy(current)
    best, best_energy = current, current_energy
    temp = start_temp
    history = [best_energy]

    for _ in range(steps):
        candidate = neighbor(current)
        if candidate is not None:
            delta = energy(candidate) - current_energy
            # always accept better moves; accept worse ones with probability e^(-d/T)
            if delta < 0 or rng.random() < math.exp(-delta / max(temp, 1e-9)):
                current, current_energy = candidate, current_energy + delta
                if current_energy < best_energy:
                    best, best_energy = current, current_energy
        temp *= cooling
        history.append(best_energy)

    return best, history
