"""A* Search: cheapest path guided by an admissible heuristic."""
import heapq
from itertools import count
from typing import Callable, Hashable, Iterable, Tuple

from ..result import SearchResult


def astar(start: Hashable,
          goal: Hashable,
          neighbors: Callable[[Hashable], Iterable[Tuple[Hashable, float]]],
          heuristic: Callable[[Hashable, Hashable], float]) -> SearchResult:
    """Return the cheapest path from `start` to `goal`.

    `heuristic(node, goal)` must never overestimate the true remaining cost,
    otherwise the result may not be optimal.
    """
    tie = count()
    frontier = [(heuristic(start, goal), next(tie), 0.0, start)]
    best_cost = {start: 0.0}
    parent = {start: None}
    expanded = 0

    while frontier:
        _, _, cost, node = heapq.heappop(frontier)
        if cost > best_cost.get(node, float("inf")):
            continue
        expanded += 1
        if node == goal:
            path = []
            while node is not None:
                path.append(node)
                node = parent[node]
            path.reverse()
            return SearchResult(path, cost, expanded)
        for nxt, edge_cost in neighbors(node):
            new_cost = cost + edge_cost
            if new_cost < best_cost.get(nxt, float("inf")):
                best_cost[nxt] = new_cost
                parent[nxt] = node
                f_score = new_cost + heuristic(nxt, goal)
                heapq.heappush(frontier, (f_score, next(tie), new_cost, nxt))

    return SearchResult(None, 0.0, expanded)
