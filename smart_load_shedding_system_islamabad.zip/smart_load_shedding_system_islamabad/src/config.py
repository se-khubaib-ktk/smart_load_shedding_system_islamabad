"""Central settings for the Smart Load-Shedding and Restoration System."""
from pathlib import Path

# ---- paths -------------------------------------------------------------
ROOT_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = ROOT_DIR / "data"
OUTPUT_DIR = ROOT_DIR / "outputs"
GRID_FILE = DATA_DIR / "grid.json"
SCENARIO_FILE = DATA_DIR / "scenarios.json"

# ---- grid model --------------------------------------------------------
# Priority of a zone: 1 = hospital (never shed), 2 = industrial,
# 3 = market, 4 = residential.
CRITICAL_PRIORITY = 1
PRIORITY_NAMES = {1: "hospital", 2: "industrial", 3: "market", 4: "residential"}

# How much a megawatt of each priority class "matters" when we rank damage.
PRIORITY_WEIGHT = {1: 10.0, 2: 3.0, 3: 2.0, 4: 1.0}

# Extra cost (km-equivalent) for closing a normally-open tie switch.
SWITCH_PENALTY = 1.0
# Road length is longer than the straight-line distance.
ROAD_DETOUR_FACTOR = 1.25
# Line length is longer than the straight-line distance.
LINE_DETOUR_FACTOR = 1.10

# ---- crew dispatch (A* + Genetic Algorithm) ----------------------------
ROAD_SPEED_KMH = 30.0          # average urban speed
MAX_SPEED_KMH = 50.0           # used by the A* heuristic (never overestimates)
REPAIR_MINUTES = {"line": 90, "transformer": 180}

GA_POPULATION = 60
GA_GENERATIONS = 80
GA_TOURNAMENT = 3
GA_CROSSOVER_RATE = 0.9
GA_MUTATION_RATE = 0.25
GA_ELITE = 2

# ---- load-shedding schedule (CSP + Simulated Annealing) ----------------
SLOTS_PER_DAY = 12             # 12 slots x 2 hours = 24 hours
HOURS_PER_SLOT = 24 // SLOTS_PER_DAY
MAX_CONSECUTIVE_SHED = 2       # no zone is cut for more than 2 slots in a row
BAND_MARGIN_MW = 10.0          # shed MW per slot must be in [deficit, deficit+margin]

# Fairness: how much shedding a zone class can tolerate (relative).
SHED_TOLERANCE = {2: 0.6, 3: 0.8, 4: 1.0}

SA_START_TEMP = 1.0
SA_COOLING = 0.995
SA_STEPS = 6000
FAIRNESS_WEIGHT = 10.0         # SA energy = this * (1 - Jain index) + switch penalty
SWITCH_WEIGHT = 0.02           # penalty for each breaker operation in a schedule

# ---- stress test (Minimax + alpha-beta) --------------------------------
STRESS_DEPTH = 4               # adversary, planner, adversary, planner

DEFAULT_SEED = 42
