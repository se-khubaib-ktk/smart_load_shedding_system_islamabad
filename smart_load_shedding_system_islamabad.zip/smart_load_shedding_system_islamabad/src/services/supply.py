"""Supply routing: which source feeds which zone, found with UCS (or BFS)."""
from dataclasses import dataclass, field
from typing import Dict, List, Optional

from ..algorithms.uninformed.bfs import bfs
from ..algorithms.uninformed.ucs import ucs
from ..models.grid import Grid
from ..models.state import GridState


@dataclass
class Route:
    zone: str
    source: str
    nodes: List[str]               # zone -> ... -> source
    lines: List[str]               # power lines used
    cost: float
    hops: int
    switches: List[str]            # normally-open lines that must be closed


@dataclass
class SupplyLoads:
    """How much power each line and source is already carrying."""
    line_load: Dict[str, float] = field(default_factory=dict)
    source_load: Dict[str, float] = field(default_factory=dict)
    routes: Dict[str, Route] = field(default_factory=dict)

    def add(self, grid: Grid, route: Route) -> None:
        demand = grid.nodes[route.zone].demand_mw
        for line_id in route.lines:
            self.line_load[line_id] = self.line_load.get(line_id, 0.0) + demand
        self.source_load[route.source] = self.source_load.get(route.source, 0.0) + demand
        self.routes[route.zone] = route


def zones_by_priority(grid: Grid, zone_ids=None) -> List[str]:
    """Most important zones first; bigger loads first inside a priority class."""
    zones = grid.zones if zone_ids is None else [grid.nodes[z] for z in zone_ids]
    return [z.id for z in sorted(zones, key=lambda z: (z.priority, -z.demand_mw))]


def route_zone(grid: Grid, state: GridState, loads: SupplyLoads, zone_id: str,
               allow_open: bool, check_capacity: bool = True,
               algorithm: str = "ucs") -> Optional[Route]:
    """Find a path from a zone to a source that can carry its demand.

    algorithm  "ucs" = cheapest path, "bfs" = fewest-hops path.
    allow_open lets the route close normally-open tie switches.
    """
    if not state.node_ok(zone_id):
        return None
    demand = grid.nodes[zone_id].demand_mw

    def usable_lines(node):
        # Zones are end points: power never flows *through* a zone.
        if node != zone_id and grid.nodes[node].type == "zone":
            return
        for line in grid.lines_at[node]:
            if not state.line_ok(line.id):
                continue
            if line.normally_open and not allow_open:
                continue
            if check_capacity and loads.line_load.get(line.id, 0.0) + demand > line.capacity_mw:
                continue
            nxt = line.other(node)
            if state.node_ok(nxt):
                yield nxt, line

    def is_goal(node):
        if grid.nodes[node].type != "source":
            return False
        capacity = state.capacity_of(grid, node)
        if capacity <= 0:
            return False
        return (not check_capacity) or loads.source_load.get(node, 0.0) + demand <= capacity

    if algorithm == "bfs":
        result = bfs(zone_id, lambda n: [nxt for nxt, _ in usable_lines(n)], is_goal)
    else:
        result = ucs(zone_id, lambda n: [(nxt, l.cost) for nxt, l in usable_lines(n)], is_goal)
    if not result.found:
        return None

    line_ids = [_line_between(grid, a, b).id for a, b in zip(result.path, result.path[1:])]
    switches = [lid for lid in line_ids if grid.lines[lid].normally_open]
    cost = sum(grid.lines[lid].cost for lid in line_ids)
    return Route(zone_id, result.path[-1], result.path, line_ids, cost,
                 len(line_ids), switches)


def assign_supply(grid: Grid, state: GridState, zone_ids=None,
                  allow_open: bool = False) -> SupplyLoads:
    """Route every zone (most important first) to a source with spare capacity."""
    loads = SupplyLoads()
    for zone_id in zones_by_priority(grid, zone_ids):
        route = route_zone(grid, state, loads, zone_id, allow_open)
        if route:
            loads.add(grid, route)
    return loads


def _line_between(grid: Grid, a: str, b: str):
    for line in grid.lines_at[a]:
        if line.other(a) == b:
            return line
    raise KeyError(f"no line between {a} and {b}")
