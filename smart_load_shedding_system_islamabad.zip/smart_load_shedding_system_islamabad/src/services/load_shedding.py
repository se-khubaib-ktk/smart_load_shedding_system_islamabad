"""Fair load-shedding timetable: CSP finds a valid one, Simulated Annealing improves it."""
import math
import random
from dataclasses import dataclass, field
from itertools import combinations
from typing import Dict, FrozenSet, List, Optional, Sequence

from .. import config
from ..algorithms.csp.backtracking import CSPStats, solve_csp
from ..algorithms.optimization.annealing import simulated_annealing
from ..models.grid import Grid

CSP_NODE_LIMIT = 4000
Schedule = List[FrozenSet[str]]          # one set of shed zones per time slot


@dataclass
class ScheduleMetrics:
    shed_hours: Dict[str, int]
    jain_fairness: float               # 1.0 = perfectly fair
    unmet_mwh: float
    breaker_operations: int
    max_consecutive_hours: int


@dataclass
class SheddingPlan:
    deficit_mw: float
    pool: List[str]
    feasible: bool
    message: str = ""
    csp_schedule: Schedule = field(default_factory=list)
    sa_schedule: Schedule = field(default_factory=list)
    csp_metrics: Optional[ScheduleMetrics] = None
    sa_metrics: Optional[ScheduleMetrics] = None
    csp_stats: Optional[CSPStats] = None
    cap_relaxations: int = 0
    consecutive_limit: int = config.MAX_CONSECUTIVE_SHED
    exempt: List[str] = field(default_factory=list)   # zones too big to rotate
    sa_history: List[float] = field(default_factory=list)


# ------------------------------------------------------------------------
def plan_shedding(grid: Grid, deficit_mw: float, pool: Sequence[str],
                  rng: random.Random) -> SheddingPlan:
    pool = sorted(pool)
    plan = SheddingPlan(deficit_mw, pool, feasible=True)
    if deficit_mw <= 0:
        plan.message = "No supply deficit - load-shedding is not needed."
        return plan

    if not pool:
        plan.feasible = False
        plan.message = "Supply deficit remains, but no eligible zones can be voluntarily shed."
        return plan

    demand = {z: grid.nodes[z].demand_mw for z in pool}
    pool_total = sum(demand.values())
    if deficit_mw > pool_total:
        plan.feasible = False
        plan.message = "Deficit is larger than all sheddable load; critical zones would be hit."
        return plan

    slots = config.SLOTS_PER_DAY
    low, high, domain = _build_domain(pool, demand, deficit_mw)

    # Zones that never fit inside any valid shed set (too large) are exempt.
    rotating = sorted({z for subset in domain for z in subset})
    plan.exempt = [z for z in pool if z not in rotating]
    pool = plan.pool = rotating
    pool_total = sum(demand[z] for z in pool)
    tolerance = {z: config.SHED_TOLERANCE[grid.nodes[z].priority] for z in pool}

    # Try the fairest rules first; loosen them step by step if the CSP fails.
    base_cap = math.ceil(slots * deficit_mw / pool_total) + 1
    solved = False
    for extra_run in range(3):
        limit = config.MAX_CONSECUTIVE_SHED + extra_run
        longest_possible = slots - slots // (limit + 1)    # e.g. 8 of 12 for limit 2
        for relax in range(4):
            caps = {z: min(longest_possible, max(1, round((base_cap + relax) * tolerance[z])))
                    for z in pool}
            # cheap necessary check: the caps must be able to cover the deficit
            if sum(caps[z] * demand[z] for z in pool) < deficit_mw * slots:
                continue
            consistent = _make_consistency_check(pool, caps, limit)
            domains = {t: list(domain) for t in range(slots)}
            solution, stats = solve_csp(domains, consistent,
                                        _make_value_order(pool, tolerance),
                                        node_limit=CSP_NODE_LIMIT)
            if solution is not None:
                solved = True
                break
        if solved:
            break
    if not solved:
        plan.feasible = False
        plan.message = "CSP found no valid timetable within the search limit."
        return plan
    plan.csp_stats = stats
    plan.cap_relaxations = relax
    plan.consecutive_limit = limit
    plan.csp_schedule = [solution[t] for t in range(slots)]

    plan.csp_metrics = evaluate_schedule(grid, plan.csp_schedule, pool)
    plan.sa_schedule, plan.sa_history = _improve_with_annealing(
        plan.csp_schedule, pool, demand, tolerance, caps, limit, low, high, rng)
    plan.sa_metrics = evaluate_schedule(grid, plan.sa_schedule, pool)
    plan.message = "Timetable found."
    return plan


# ---- CSP pieces ---------------------------------------------------------
def _build_domain(pool, demand, deficit):
    """All zone sets whose total load lies in [deficit, deficit + margin]."""
    margin = config.BAND_MARGIN_MW
    total = sum(demand.values())
    while True:
        low, high = deficit, deficit + margin
        domain = [frozenset(combo)
                  for size in range(1, len(pool) + 1)
                  for combo in combinations(pool, size)
                  if low <= sum(demand[z] for z in combo) <= high]
        if domain or high >= total:
            return low, high, domain
        margin += 5.0


def _make_consistency_check(pool, caps, limit):
    slots = config.SLOTS_PER_DAY

    def consistent(assignment):
        for zone in pool:
            total = run = 0
            for t in range(slots):
                if t in assignment and zone in assignment[t]:
                    total += 1
                    run += 1
                    if run > limit:
                        return False
                else:
                    run = 0
            if total > caps[zone]:
                return False
        return True

    return consistent


def _make_value_order(pool, tolerance):
    def order(_slot, values, assignment):
        used = {z: sum(1 for s in assignment.values() if z in s) for z in pool}
        return sorted(values, key=lambda s: sum(used[z] / tolerance[z] for z in s))
    return order


# ---- Simulated Annealing ------------------------------------------------
def _improve_with_annealing(initial, pool, demand, tolerance, caps, limit, low, high, rng):
    consistent = _make_consistency_check(pool, caps, limit)

    def energy(schedule):
        unfairness = 1.0 - _jain(_scaled_counts(schedule, pool, tolerance))
        return config.FAIRNESS_WEIGHT * unfairness + \
            config.SWITCH_WEIGHT * _breaker_operations(schedule)

    def neighbor(schedule):
        t = rng.randrange(len(schedule))
        inside = [z for z in pool if z in schedule[t]]
        outside = [z for z in pool if z not in schedule[t]]
        if not inside or not outside:
            return None
        swapped = (schedule[t] - {rng.choice(inside)}) | {rng.choice(outside)}
        if not low <= sum(demand[z] for z in swapped) <= high:
            return None
        candidate = list(schedule)
        candidate[t] = frozenset(swapped)
        if not consistent(dict(enumerate(candidate))):
            return None
        return candidate

    best, history = simulated_annealing(
        list(initial), neighbor, energy,
        start_temp=config.SA_START_TEMP, cooling=config.SA_COOLING,
        steps=config.SA_STEPS, rng=rng)
    return best, history


def _scaled_counts(schedule, pool, tolerance):
    return [sum(1 for s in schedule if z in s) / tolerance[z] for z in pool]


def _jain(values) -> float:
    """Jain's fairness index: 1.0 means everybody carries the same burden."""
    squares = sum(v * v for v in values)
    return (sum(values) ** 2) / (len(values) * squares) if squares else 1.0


def _breaker_operations(schedule) -> int:
    return sum(len(a ^ b) for a, b in zip(schedule, schedule[1:])) + len(schedule[0])


# ---- reporting ------------------------------------------------------------
def evaluate_schedule(grid: Grid, schedule: Schedule, pool: Sequence[str]) -> ScheduleMetrics:
    tolerance = {z: config.SHED_TOLERANCE[grid.nodes[z].priority] for z in pool}
    counts = {z: sum(1 for s in schedule if z in s) for z in pool}
    jain = _jain(_scaled_counts(schedule, pool, tolerance))
    unmet = sum(grid.nodes[z].demand_mw for s in schedule for z in s) * config.HOURS_PER_SLOT

    longest = 0
    for zone in pool:
        run = 0
        for s in schedule:
            run = run + 1 if zone in s else 0
            longest = max(longest, run)
    return ScheduleMetrics(
        shed_hours={z: counts[z] * config.HOURS_PER_SLOT for z in pool},
        jain_fairness=jain, unmet_mwh=unmet,
        breaker_operations=_breaker_operations(schedule),
        max_consecutive_hours=longest * config.HOURS_PER_SLOT)
