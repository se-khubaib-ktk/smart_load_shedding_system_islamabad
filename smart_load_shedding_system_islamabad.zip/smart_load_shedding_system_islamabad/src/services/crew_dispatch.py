"""Repair-crew dispatch: A* for travel times, Genetic Algorithm for the visiting order."""
import random
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

from .. import config
from ..algorithms.informed.astar import astar
from ..algorithms.optimization.genetic import genetic_algorithm, order_crossover, swap_mutation
from ..models.grid import Grid
from ..models.state import GridState
from .supply import SupplyLoads


@dataclass
class Fault:
    id: str
    kind: str                      # line | transformer | source
    component: str                 # line id or node id
    site: str                      # node where the crew must go
    repair_min: float
    weight: float                  # how much power/priority depends on this repair


@dataclass
class Visit:
    fault: Fault
    travel_min: float
    arrive: float
    finish: float


@dataclass
class DispatchPlan:
    faults: List[Fault]
    crews: List[str]                                   # depot of each crew
    visits: List[List[Visit]]                          # per crew, in order
    cost: float                                        # sum(weight * finish time)
    makespan: float
    baselines: Dict[str, float] = field(default_factory=dict)
    history: List[float] = field(default_factory=list)
    astar_expanded: int = 0


class TravelTimes:
    """Travel minutes between two nodes on the road network (A*, cached)."""

    def __init__(self, grid: Grid):
        self.grid = grid
        self.cache: Dict[Tuple[str, str], float] = {}
        self.expanded = 0

    def minutes(self, a: str, b: str) -> float:
        if a == b:
            return 0.0
        key = (a, b) if a < b else (b, a)
        if key not in self.cache:
            result = astar(a, b, lambda n: self.grid.roads[n], self._heuristic)
            self.expanded += result.expanded
            self.cache[key] = result.cost if result.found else float("inf")
        return self.cache[key]

    def _heuristic(self, node: str, goal: str) -> float:
        # straight line at top speed: can never be more than the real time
        return self.grid.distance_km(node, goal) / config.MAX_SPEED_KMH * 60.0


# ---- building the list of repair jobs ----------------------------------
def build_faults(grid: Grid, state: GridState, baseline: SupplyLoads) -> List[Fault]:
    """One repair job per failed line or failed node."""
    faults = []
    for line_id in sorted(state.failed_lines):
        line = grid.lines[line_id]
        weight = _dependent_weight(grid, baseline, line_id=line_id)
        faults.append(Fault(f"line {line_id}", "line", line_id, line.a,
                            config.REPAIR_MINUTES["line"], weight))
    for node_id in sorted(state.failed_nodes):
        kind = grid.nodes[node_id].type
        weight = _dependent_weight(grid, baseline, node_id=node_id)
        faults.append(Fault(f"{kind} {node_id}", kind, node_id, node_id,
                            config.REPAIR_MINUTES.get(kind, 120), weight))
    return faults


def _dependent_weight(grid, baseline, line_id=None, node_id=None) -> float:
    """Priority-weighted MW that normally flows through the failed part."""
    total = 0.0
    for zone_id, route in baseline.routes.items():
        hit = (line_id in route.lines) if line_id else (node_id in route.nodes)
        if hit:
            zone = grid.nodes[zone_id]
            total += zone.demand_mw * config.PRIORITY_WEIGHT[zone.priority]
    return max(total, 1.0)


# ---- scheduling ---------------------------------------------------------
def simulate(order: List[int], faults: List[Fault], crews: List[str],
             travel: TravelTimes) -> Tuple[float, List[List[Visit]]]:
    """Give each job (in this order) to the crew that can finish it first."""
    free_at = [0.0] * len(crews)
    where = list(crews)
    visits: List[List[Visit]] = [[] for _ in crews]
    cost = 0.0
    for index in order:
        fault = faults[index]
        best = min(range(len(crews)),
                   key=lambda c: free_at[c] + travel.minutes(where[c], fault.site))
        drive = travel.minutes(where[best], fault.site)
        arrive = free_at[best] + drive
        finish = arrive + fault.repair_min
        visits[best].append(Visit(fault, drive, arrive, finish))
        free_at[best], where[best] = finish, fault.site
        cost += fault.weight * finish
    return cost, visits


def plan_dispatch(grid: Grid, state: GridState, baseline: SupplyLoads,
                  crews: List[str], rng: random.Random) -> Optional[DispatchPlan]:
    faults = build_faults(grid, state, baseline)
    if not faults:
        return None
    travel = TravelTimes(grid)
    indexes = list(range(len(faults)))

    def fitness(order):
        return simulate(order, faults, crews, travel)[0]

    def random_order():
        order = indexes[:]
        rng.shuffle(order)
        return order

    best, history = genetic_algorithm(
        random_individual=random_order,
        fitness=fitness,
        crossover=lambda a, b: order_crossover(a, b, rng),
        mutate=lambda ind: swap_mutation(ind, rng),
        population_size=config.GA_POPULATION,
        generations=config.GA_GENERATIONS,
        tournament=config.GA_TOURNAMENT,
        crossover_rate=config.GA_CROSSOVER_RATE,
        mutation_rate=config.GA_MUTATION_RATE,
        elite=config.GA_ELITE,
        rng=rng,
    )
    cost, visits = simulate(best, faults, crews, travel)

    # Simple baselines for comparison.
    nearest = sorted(indexes, key=lambda i: min(travel.minutes(c, faults[i].site) for c in crews))
    heaviest = sorted(indexes, key=lambda i: -faults[i].weight)
    baselines = {
        "nearest-first": simulate(nearest, faults, crews, travel)[0],
        "heaviest-first": simulate(heaviest, faults, crews, travel)[0],
        "random order": simulate(random_order(), faults, crews, travel)[0],
    }
    makespan = max((v[-1].finish for v in visits if v), default=0.0)
    return DispatchPlan(faults, crews, visits, cost, makespan, baselines,
                        history, travel.expanded)
