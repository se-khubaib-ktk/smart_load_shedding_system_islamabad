"""Worst-case stress test: Minimax with alpha-beta pruning.

The adversary (MAX) knocks out grid components; the planner (MIN) answers by
closing a backup switch. The score is the priority-weighted power left unserved.
"""
from dataclasses import dataclass
from typing import FrozenSet, List, Optional, Tuple

from .. import config
from ..algorithms.adversarial.minimax import MinimaxStats, minimax
from ..algorithms.uninformed.dfs import dfs
from ..models.grid import Grid
from ..models.state import GridState

# (failed_lines, failed_nodes, closed_switches)
Position = Tuple[FrozenSet[str], FrozenSet[str], FrozenSet[str]]


@dataclass
class StressResult:
    worst_value: float                 # weighted MW unserved in the worst case
    current_value: float               # weighted MW unserved right now
    total_weighted: float
    line: List[Tuple[str, str]]        # principal variation, e.g. ("fail", "T4")
    stats: MinimaxStats
    unpruned_stats: Optional[MinimaxStats] = None
    unpruned_value: Optional[float] = None

    @property
    def resilience(self) -> float:
        """Share of the load that is served right now and still survives the worst case."""
        at_risk = self.total_weighted - self.current_value
        if at_risk <= 0:
            return 1.0
        return 1.0 - (self.worst_value - self.current_value) / at_risk


class GridGame:
    """Game rules + a fast evaluation function for the minimax search."""

    def __init__(self, grid: Grid, state: GridState):
        self.grid = grid
        self.state = state
        self.zone_order = sorted(grid.zones, key=lambda z: (z.priority, -z.demand_mw))
        self.total_weighted = sum(z.demand_mw * config.PRIORITY_WEIGHT[z.priority]
                                  for z in grid.zones)
        # The adversary attacks transformers and the feeders that supply them.
        self.attackable = ([("node", n.id) for n in grid.of_type("transformer")] +
                           [("line", l.id) for l in grid.lines.values()
                            if not l.normally_open and
                            {grid.nodes[l.a].type, grid.nodes[l.b].type} == {"source", "transformer"}])
        self.switchable = [l.id for l in grid.lines.values() if l.normally_open]
        self._cache = {}

    # -- game moves --
    def moves(self, position: Position, adversary_turn: bool):
        failed_lines, failed_nodes, closed = position
        if adversary_turn:
            for kind, ident in self.attackable:
                if (kind == "line" and ident not in failed_lines) or \
                   (kind == "node" and ident not in failed_nodes):
                    yield ("fail", ident, kind)
        else:
            yield ("hold", "", "")
            for line_id in self.switchable:
                if line_id not in closed and line_id not in failed_lines:
                    yield ("close", line_id, "line")

    def apply(self, position: Position, move, adversary_turn: bool) -> Position:
        failed_lines, failed_nodes, closed = position
        action, ident, kind = move
        if action == "fail":
            if kind == "line":
                failed_lines = failed_lines | {ident}
            else:
                failed_nodes = failed_nodes | {ident}
        elif action == "close":
            closed = closed | {ident}
        return failed_lines, failed_nodes, closed

    # -- evaluation: weighted MW that cannot be served --
    def unserved(self, position: Position) -> float:
        if position in self._cache:
            return self._cache[position]
        failed_lines, failed_nodes, closed = position
        grid = self.grid

        def neighbors_from(node):
            if grid.nodes[node].type == "zone":
                return
            for line in grid.lines_at[node]:
                if line.id in failed_lines or (line.normally_open and line.id not in closed):
                    continue
                nxt = line.other(node)
                if nxt not in failed_nodes:
                    yield nxt

        reach = {}
        spare = {}
        for source in grid.sources:
            capacity = 0.0 if source.id in failed_nodes else \
                self.state.source_capacity.get(source.id, source.capacity_mw)
            if capacity > 0:
                reach[source.id] = {n for n in dfs(source.id, neighbors_from)
                                    if grid.nodes[n].type == "zone"}
                spare[source.id] = capacity

        lost = 0.0
        for zone in self.zone_order:
            options = [s for s in reach if zone.id in reach[s] and spare[s] >= zone.demand_mw]
            if options:
                spare[max(options, key=lambda s: spare[s])] -= zone.demand_mw
            else:
                lost += zone.demand_mw * config.PRIORITY_WEIGHT[zone.priority]
        self._cache[position] = lost
        return lost


def run_stress_test(grid: Grid, state: GridState, closed_switches,
                    compare_unpruned: bool = False,
                    depth: int = config.STRESS_DEPTH) -> StressResult:
    game = GridGame(grid, state)
    start: Position = (frozenset(state.failed_lines), frozenset(state.failed_nodes),
                       frozenset(closed_switches))

    def search(use_pruning):
        return minimax(start, depth, True, game.moves, game.apply, game.unserved,
                       use_pruning=use_pruning)

    value, line, stats = search(True)
    unpruned_value, _, unpruned = search(False) if compare_unpruned else (None, None, None)
    return StressResult(value, game.unserved(start), game.total_weighted,
                        [(m[0], m[1]) for m in line], stats, unpruned, unpruned_value)
