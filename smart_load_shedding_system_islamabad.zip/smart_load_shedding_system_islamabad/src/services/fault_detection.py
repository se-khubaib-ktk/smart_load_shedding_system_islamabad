"""Fault detection: which zones lost power, and which backups exist?

DFS finds everything still energised from the working sources.
BFS finds the fewest-edge backup path for each zone that went dark.
"""
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Set

from ..algorithms.uninformed.dfs import dfs
from ..models.grid import Grid
from ..models.state import GridState
from .supply import SupplyLoads, SupplyLoads as _Loads, route_zone, zones_by_priority


@dataclass
class FaultReport:
    energized: Set[str]                      # all energised node ids
    dark_zones: List[str]                    # cut off by a fault (no path)
    overload_zones: List[str]                # dropped because a source is derated
    backup_hops: Dict[str, Optional[int]] = field(default_factory=dict)

    @property
    def affected(self) -> List[str]:
        return self.dark_zones + self.overload_zones


def find_energized(grid: Grid, state: GridState) -> Set[str]:
    """DFS from every working source across closed, healthy lines."""
    def neighbors(node):
        # power does not flow through a zone
        if grid.nodes[node].type == "zone":
            return
        for line in grid.lines_at[node]:
            if line.normally_open or not state.line_ok(line.id):
                continue
            nxt = line.other(node)
            if state.node_ok(nxt):
                yield nxt

    energized: Set[str] = set()
    for source in grid.sources:
        if state.capacity_of(grid, source.id) > 0 and source.id not in energized:
            energized.update(dfs(source.id, neighbors))
    return energized


def detect_faults(grid: Grid, state: GridState, baseline: SupplyLoads) -> FaultReport:
    energized = find_energized(grid, state)
    dark = [z for z in zones_by_priority(grid) if z not in energized]

    # A derated source cannot carry all its zones: drop the least important ones.
    overload = []
    for source in grid.sources:
        served = [z for z in zones_by_priority(grid)
                  if z in energized and baseline.routes.get(z) and baseline.routes[z].source == source.id]
        load = sum(grid.nodes[z].demand_mw for z in served)
        capacity = state.capacity_of(grid, source.id)
        for zone_id in reversed(served):          # least important first
            if load <= capacity:
                break
            load -= grid.nodes[zone_id].demand_mw
            overload.append(zone_id)

    # BFS: how many line hops away is the nearest backup source?
    hops: Dict[str, Optional[int]] = {}
    empty = _Loads()
    for zone_id in dark + overload:
        route = route_zone(grid, state, empty, zone_id, allow_open=True,
                           check_capacity=False, algorithm="bfs")
        hops[zone_id] = route.hops if route else None

    return FaultReport(energized, dark, overload, hops)
