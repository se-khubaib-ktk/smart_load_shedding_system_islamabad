"""Service restoration: re-route power to affected zones with UCS."""
from dataclasses import dataclass, field
from typing import Dict, List

from ..models.grid import Grid
from ..models.state import GridState
from .fault_detection import FaultReport, detect_faults
from .supply import Route, SupplyLoads, route_zone


@dataclass
class RestorationPlan:
    report: FaultReport
    loads: SupplyLoads                       # final routing of every served zone
    restored: List[Route] = field(default_factory=list)
    switch_ops: List[str] = field(default_factory=list)       # tie lines to close
    capacity_short: List[str] = field(default_factory=list)   # reachable, no spare MW
    isolated: List[str] = field(default_factory=list)         # no path: wait for repair

    @property
    def served(self) -> List[str]:
        return list(self.loads.routes)

    def served_mw(self, grid: Grid) -> float:
        return sum(grid.nodes[z].demand_mw for z in self.served)

    def unserved_mw(self, grid: Grid) -> float:
        return grid.total_demand() - self.served_mw(grid)

    def deficit_mw(self, grid: Grid) -> float:
        """Load of zones that are connected but cannot be supplied (needs shedding)."""
        return sum(grid.nodes[z].demand_mw for z in self.capacity_short)


def plan_restoration(grid: Grid, state: GridState, baseline: SupplyLoads) -> RestorationPlan:
    """Re-route every zone in priority order on the damaged grid.

    Hospitals get first pick of the remaining capacity, then industry, markets
    and homes. Inside one priority class, zones that were not affected keep
    their supply first so we do not switch things around for no reason.
    """
    report = detect_faults(grid, state, baseline)
    affected = set(report.affected)
    order = sorted(grid.zones,
                   key=lambda z: (z.priority, z.id in affected, -z.demand_mw))

    loads = SupplyLoads()
    plan = RestorationPlan(report, loads)
    for zone in order:
        route = route_zone(grid, state, loads, zone.id, allow_open=True)
        if route:
            loads.add(grid, route)
            old = baseline.routes.get(zone.id)
            if old is None or old.lines != route.lines:
                plan.restored.append(route)
            for line_id in route.switches:
                if line_id not in plan.switch_ops:
                    plan.switch_ops.append(line_id)
        elif route_zone(grid, state, loads, zone.id, allow_open=True,
                        check_capacity=False):
            plan.capacity_short.append(zone.id)
        else:
            plan.isolated.append(zone.id)
    return plan
