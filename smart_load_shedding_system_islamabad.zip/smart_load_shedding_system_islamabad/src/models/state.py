"""The condition of the grid: which parts are broken or derated."""
import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional, Set

from .. import config
from .grid import Grid


@dataclass
class GridState:
    failed_lines: Set[str] = field(default_factory=set)
    failed_nodes: Set[str] = field(default_factory=set)
    source_capacity: Dict[str, float] = field(default_factory=dict)   # overrides

    def line_ok(self, line_id: str) -> bool:
        return line_id not in self.failed_lines

    def node_ok(self, node_id: str) -> bool:
        return node_id not in self.failed_nodes

    def capacity_of(self, grid: Grid, source_id: str) -> float:
        """Usable MW of a source (0 if the source itself has failed)."""
        if not self.node_ok(source_id):
            return 0.0
        return self.source_capacity.get(source_id, grid.nodes[source_id].capacity_mw)

    def copy(self) -> "GridState":
        return GridState(set(self.failed_lines), set(self.failed_nodes),
                         dict(self.source_capacity))


@dataclass
class Scenario:
    id: int
    name: str
    description: str
    state: GridState
    crews: List[str]               # depot id for each repair crew


def load_scenarios(path: Optional[Path] = None) -> List[Scenario]:
    with open(path or config.SCENARIO_FILE, "r", encoding="utf-8") as handle:
        raw = json.load(handle)
    scenarios = []
    for item in raw:
        state = GridState(set(item.get("failed_lines", [])),
                          set(item.get("failed_nodes", [])),
                          dict(item.get("source_derate", {})))
        scenarios.append(Scenario(item["id"], item["name"], item["description"],
                                  state, item.get("crews", ["D1"])))
    return scenarios
