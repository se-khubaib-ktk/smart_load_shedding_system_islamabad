"""The power grid and road network, loaded from data/grid.json."""
import json
import math
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Optional, Tuple

from .. import config


@dataclass
class Node:
    id: str
    name: str
    type: str                      # source | transformer | zone | depot
    x: float
    y: float
    capacity_mw: float = 0.0       # sources only
    demand_mw: float = 0.0         # zones only
    priority: int = 4              # zones only (1 = hospital ... 4 = residential)


@dataclass
class Line:
    id: str
    a: str
    b: str
    capacity_mw: float
    normally_open: bool            # True for tie switches / backup feeders
    km: float

    @property
    def cost(self) -> float:
        """Cost used by Uniform Cost Search: length plus a switching penalty."""
        return self.km + (config.SWITCH_PENALTY if self.normally_open else 0.0)

    def other(self, node_id: str) -> str:
        return self.b if node_id == self.a else self.a


class Grid:
    """Holds nodes, power lines and the road graph used by repair crews."""

    def __init__(self, nodes: Dict[str, Node], lines: Dict[str, Line],
                 roads: Dict[str, List[Tuple[str, float]]], city: str = ""):
        self.nodes = nodes
        self.lines = lines
        self.roads = roads                       # node -> [(neighbour, minutes)]
        self.city = city
        self.lines_at: Dict[str, List[Line]] = {n: [] for n in nodes}
        for line in lines.values():
            self.lines_at[line.a].append(line)
            self.lines_at[line.b].append(line)

    # ---- convenient views ---------------------------------------------
    def of_type(self, kind: str) -> List[Node]:
        return [n for n in self.nodes.values() if n.type == kind]

    @property
    def sources(self) -> List[Node]:
        return self.of_type("source")

    @property
    def zones(self) -> List[Node]:
        return self.of_type("zone")

    @property
    def depots(self) -> List[Node]:
        return self.of_type("depot")

    def distance_km(self, a: str, b: str) -> float:
        na, nb = self.nodes[a], self.nodes[b]
        return math.hypot(na.x - nb.x, na.y - nb.y)

    def total_demand(self) -> float:
        return sum(z.demand_mw for z in self.zones)


def load_grid(path: Optional[Path] = None) -> Grid:
    """Read grid.json and build a Grid (line lengths come from coordinates)."""
    with open(path or config.GRID_FILE, "r", encoding="utf-8") as handle:
        raw = json.load(handle)

    nodes = {}
    for node_id, info in raw["nodes"].items():
        nodes[node_id] = Node(
            id=node_id, name=info["name"], type=info["type"],
            x=info["x"], y=info["y"],
            capacity_mw=info.get("capacity_mw", 0.0),
            demand_mw=info.get("demand_mw", 0.0),
            priority=info.get("priority", 4),
        )

    lines = {}
    for item in raw["lines"]:
        a, b = item["from"], item["to"]
        for end in (a, b):
            if end not in nodes:
                raise ValueError(f"Line {item['id']} refers to unknown node {end}")
        km = _euclid(nodes[a], nodes[b]) * config.LINE_DETOUR_FACTOR
        lines[item["id"]] = Line(item["id"], a, b, item["capacity_mw"],
                                 item["normally_open"], km)

    # Roads follow every power line, plus the extra roads listed in the file.
    pairs = {tuple(sorted((l.a, l.b))) for l in lines.values()}
    pairs |= {tuple(sorted(p)) for p in raw.get("extra_roads", [])}
    roads: Dict[str, List[Tuple[str, float]]] = {n: [] for n in nodes}
    for a, b in sorted(pairs):
        km = _euclid(nodes[a], nodes[b]) * config.ROAD_DETOUR_FACTOR
        minutes = km / config.ROAD_SPEED_KMH * 60.0
        roads[a].append((b, minutes))
        roads[b].append((a, minutes))

    return Grid(nodes, lines, roads, raw.get("city", ""))


def _euclid(a: Node, b: Node) -> float:
    return math.hypot(a.x - b.x, a.y - b.y)
