"""Desktop GUI (tkinter + embedded matplotlib), a thin layer on top of src/pipeline.py.

Layers (the first four never import tkinter, so they can be tested without a display):
    glossary.py    plain-language help texts and the algorithm cards
    controller.py  runs scenarios / the benchmark in a background thread
    viewmodel.py   turns results into table rows, cards and plain-English text
    figures.py     builds matplotlib Figures (shared with the screenshot script)
    theme.py, widgets.py, map_view.py, sidebar.py, statusbar.py, *_tab.py, app.py
                   the tkinter screens and widgets
Start it with:  python gui.py
"""
