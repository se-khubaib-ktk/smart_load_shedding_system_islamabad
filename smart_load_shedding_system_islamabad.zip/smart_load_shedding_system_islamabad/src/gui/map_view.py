"""The interactive grid map: hover or click a node to see its name, demand and priority."""
import tkinter as tk
from tkinter import ttk
from typing import Callable, Optional

from ..utils.map_drawing import COLORS, DEPOT_COLOR, STATUS_TEXT, node_label, place_labels
from . import figures, viewmodel as vm
from .theme import PALETTE
from .widgets import FigureFrame

PICK_RADIUS_PX = 16


class MapView(ttk.Frame):
    def __init__(self, parent, theme, on_select_node: Optional[Callable[[str], None]] = None,
                 toolbar: bool = True):
        super().__init__(parent)
        self.theme = theme
        self.on_select_node = on_select_node
        self.grid_model = None
        self.analysis = None
        self.ax = None
        self.positions = {}
        self.annotation = None
        self.sticky_id: Optional[str] = None
        self._relabel_job = None

        self.frame = FigureFrame(self, toolbar=toolbar)
        self.frame.pack(fill="both", expand=True)
        legend = ttk.Frame(self)
        legend.pack(fill="x", pady=(4, 0))
        for key in ("normal", "rerouted", "shed", "dark"):
            self._legend_item(legend, COLORS[key], STATUS_TEXT[key])
        self._legend_item(legend, DEPOT_COLOR, "Repair depot")
        self.info = tk.Label(self, text="Hover over a node for details, click to select it.",
                             anchor="w", justify="left", bg=PALETTE["surface"], fg=PALETTE["muted"],
                             font=theme.fonts["base"], padx=10, pady=6, relief="solid", borderwidth=1)
        self.info.pack(fill="x", pady=(6, 0))

    def _legend_item(self, parent, colour, text):
        box = ttk.Frame(parent)
        box.pack(side="left", padx=(0, 14))
        tk.Label(box, text="\u25CF", fg=colour, bg=PALETTE["bg"], font=self.theme.fonts["heading"]).pack(side="left")
        ttk.Label(box, text=text).pack(side="left")

    # ---- drawing --------------------------------------------------------------
    def render(self, grid, analysis, stage=None, focus_zone=None):
        self.grid_model, self.analysis = grid, analysis
        fig, self.ax, self.positions = figures.map_figure(
            grid, analysis, stage=stage, focus_zone=focus_zone, scale=self.theme.scale)
        canvas = self.frame.show(fig)
        self.annotation = self.ax.annotate(
            "", xy=(0, 0), xytext=(16, 16), textcoords="offset points", fontsize=10 * self.theme.scale,
            zorder=20, bbox=dict(boxstyle="round,pad=0.4", fc="#fffbe6", ec="#999999"),
            arrowprops=dict(arrowstyle="-", color="#999999"))
        self.annotation.set_visible(False)
        canvas.mpl_connect("motion_notify_event", self._on_move)
        canvas.mpl_connect("button_press_event", self._on_click)
        canvas.mpl_connect("resize_event", self._on_resize)
        if focus_zone:
            self.sticky_id = focus_zone
            self.info.configure(text=vm.node_info(grid, analysis, focus_zone).replace("\n", "   |   "))

    def figure(self):
        return self.frame.figure

    def _on_resize(self, _event):
        # the real canvas size differs from the nominal figure size: place the labels again
        if self._relabel_job:
            self.after_cancel(self._relabel_job)
        self._relabel_job = self.after(250, self._relabel)

    def _relabel(self):
        self._relabel_job = None
        if self.ax is None or self.frame.canvas is None:
            return
        for artist in getattr(self.ax, "_node_labels", []):
            artist.remove()
        items = [(n.x, n.y, node_label(n)) for n in self.grid_model.nodes.values()]
        self.ax._node_labels = place_labels(self.ax, items, 9.5 * self.theme.scale)
        self.frame.canvas.draw_idle()

    # ---- interaction --------------------------------------------------------------
    def _nearest(self, event) -> Optional[str]:
        if self.ax is None or event.inaxes is not self.ax:
            return None
        best, best_d = None, PICK_RADIUS_PX * self.theme.scale
        for node_id, (x, y) in self.positions.items():
            px, py = self.ax.transData.transform((x, y))
            d = ((px - event.x) ** 2 + (py - event.y) ** 2) ** 0.5
            if d < best_d:
                best, best_d = node_id, d
        return best

    def _on_move(self, event):
        node_id = self._nearest(event)
        if node_id is None:
            if self.annotation.get_visible():
                self.annotation.set_visible(False)
                self.frame.canvas.draw_idle()
            return
        text = vm.node_info(self.grid_model, self.analysis, node_id)
        self.annotation.set_text(text)
        self.annotation.xy = self.positions[node_id]
        self.annotation.set_visible(True)
        self.frame.canvas.draw_idle()

    def _on_click(self, event):
        node_id = self._nearest(event)
        if node_id is None:
            return
        self.sticky_id = node_id
        self.info.configure(text=vm.node_info(self.grid_model, self.analysis, node_id).replace("\n", "   |   "))
        if self.on_select_node:
            self.on_select_node(node_id)
