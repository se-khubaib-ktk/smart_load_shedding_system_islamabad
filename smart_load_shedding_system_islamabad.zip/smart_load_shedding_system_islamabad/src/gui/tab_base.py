"""Common base class for the tabs, plus a helper for read-only text boxes."""
import tkinter as tk
from tkinter import ttk

from .theme import PALETTE


class TabBase(ttk.Frame):
    """Every tab can redraw itself for a new analysis and report its current figure."""

    def __init__(self, parent, theme, grid):
        super().__init__(parent, padding=10)
        self.theme, self.grid_model = theme, grid
        self.analysis = None

    def update_view(self, analysis) -> None:          # called after every run
        self.analysis = analysis
        self.redraw()

    def redraw(self) -> None:                        # called after run or font-size change
        raise NotImplementedError

    def current_figure(self):                        # used by "Export report"
        return None


def read_only_text(parent, theme, height=6) -> tk.Text:
    box = tk.Text(parent, wrap="word", height=height, font=theme.fonts["base"], relief="solid",
                  borderwidth=1, bg=PALETTE["surface"], fg=PALETTE["text"], padx=10, pady=8,
                  state="disabled", cursor="arrow")
    return box


def set_text(box: tk.Text, text: str) -> None:
    box.configure(state="normal")
    box.delete("1.0", "end")
    box.insert("1.0", text)
    box.configure(state="disabled")
