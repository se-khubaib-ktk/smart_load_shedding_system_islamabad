"""Tab 4 - Load-shedding timetable: heat-map (CSP / after Simulated Annealing) and metrics."""
import tkinter as tk
from tkinter import ttk

from . import figures, viewmodel as vm
from .glossary import GLOSSARY
from .tab_base import TabBase
from .theme import PALETTE
from .widgets import DataTable, FigureFrame, help_icon

METRIC_COLUMNS = [("metric", "Measure", 230, "w"), ("before", "CSP result", 100, "e"),
                  ("after", "After annealing", 120, "e")]
ZONE_COLUMNS = [("zone", "Zone", 200, "w"), ("csp", "Cut hours (CSP)", 120, "e"),
                ("sa", "Cut hours (after SA)", 150, "e")]


class SheddingTab(TabBase):
    def __init__(self, parent, theme, grid):
        super().__init__(parent, theme, grid)
        self.columnconfigure(0, weight=1)
        self.rowconfigure(2, weight=1)
        bar = ttk.Frame(self)
        bar.grid(row=0, column=0, sticky="ew")
        ttk.Label(bar, text="Show:", style="Heading.TLabel").pack(side="left", padx=(0, 8))
        self.view = tk.StringVar(value="both")
        for value, text in (("both", "Side by side"), ("csp", "CSP result"), ("sa", "After Simulated Annealing")):
            ttk.Radiobutton(bar, text=text, variable=self.view, value=value, command=self.redraw).pack(side="left", padx=6)
        help_icon(bar, GLOSSARY["jain"], theme, PALETTE["bg"]).pack(side="right")
        ttk.Label(bar, text="Fairness (Jain index)").pack(side="right", padx=6)
        help_icon(bar, GLOSSARY["breaker"], theme, PALETTE["bg"]).pack(side="right", padx=(0, 16))
        ttk.Label(bar, text="Breaker operations").pack(side="right", padx=6)

        self.note = ttk.Label(self, text="", style="Muted.TLabel", wraplength=1000, justify="left")
        self.note.grid(row=1, column=0, sticky="ew", pady=(6, 6))
        self.heat = FigureFrame(self)
        self.heat.grid(row=2, column=0, sticky="nsew")
        tables = ttk.Frame(self)
        tables.grid(row=3, column=0, sticky="ew", pady=(8, 0))
        tables.columnconfigure(0, weight=1)
        tables.columnconfigure(1, weight=1)
        self.metrics = DataTable(tables, METRIC_COLUMNS, height=4)
        self.metrics.grid(row=0, column=0, sticky="ew", padx=(0, 8))
        self.zones = DataTable(tables, ZONE_COLUMNS, height=4)
        self.zones.grid(row=0, column=1, sticky="ew")

    def redraw(self):
        if not self.analysis:
            return
        a = self.analysis
        self.note.configure(text=vm.shedding_note(self.grid_model, a))
        self.heat.show(figures.heatmap_figure(self.grid_model, a, self.view.get(), self.theme.scale))
        self.metrics.set_rows(vm.shedding_metric_rows(a))
        self.zones.set_rows(vm.shedding_rows(self.grid_model, a))

    def current_figure(self):
        return self.heat.figure
