"""Presentation workspace with deterministic, reversible decision frames.

Layout priority: the schematic takes every spare pixel; the controls are one slim row of small buttons.
"""
import tkinter as tk
from tkinter import ttk, filedialog
import json
from dataclasses import asdict
from matplotlib.figure import Figure
from .tab_base import TabBase, read_only_text, set_text
from .widgets import FigureFrame
from .theme import PALETTE
from .demo_trace import build_trace
from .demo_map import schematic, inspect


class DemoTab(TabBase):
    def __init__(self,parent,theme,grid):
        super().__init__(parent,theme,grid)
        self.configure(padding=(6,4))
        self.frames=[];self.index=0;self.job=None;self.selected='';self.stage=None;self.drawing=False;self.render_job=None
        self.artists={}
        self.backups=tk.BooleanVar(value=False)
        self.columnconfigure(0,weight=1);self.rowconfigure(1,weight=1)
        top=ttk.Frame(self);top.grid(row=0,column=0,sticky='ew',pady=(0,3))
        self.metrics=ttk.Label(top,text='Preparing analysis…',style='SmallHeading.TLabel')
        self.metrics.pack(side='left')
        ttk.Checkbutton(top,text='All ties',variable=self.backups,command=self.redraw,style='Small.TCheckbutton').pack(side='right')
        ttk.Button(top,text='Export replay',style='Small.TButton',command=self.export_trace).pack(side='right',padx=8)
        self.frame=FigureFrame(self,toolbar=False);self.frame.grid(row=1,column=0,sticky='nsew')
        self.canvas=self.frame.show(Figure(figsize=(15,6),dpi=100,facecolor='#ffffff'))
        self.canvas.mpl_connect('pick_event',self.picked)
        self.canvas.mpl_connect('resize_event',lambda e:self.render())
        self.inspector=tk.Label(self,text='',anchor='nw',justify='left',height=2,bg=PALETTE['bg'],
                                fg='#5f6b7a',font=theme.fonts['small'],wraplength=1000)
        self.inspector.grid(row=2,column=0,sticky='ew',pady=(2,2))
        controls=ttk.Frame(self);controls.grid(row=3,column=0,sticky='ew',pady=(0,2))
        ttk.Button(controls,text='|< Reset',style='Small.TButton',width=7,command=lambda:self.go(0)).pack(side='left')
        self.prev=ttk.Button(controls,text='< Back',style='Small.TButton',width=7,command=lambda:self.go(self.index-1));self.prev.pack(side='left',padx=3)
        self.play=ttk.Button(controls,text='Play',style='Small.TButton',width=7,command=self.toggle_play);self.play.pack(side='left')
        self.next=ttk.Button(controls,text='Next >',style='SmallAccent.TButton',width=8,command=lambda:self.go(self.index+1));self.next.pack(side='left',padx=3)
        self.counter=ttk.Label(controls,text='0 / 0',style='Small.TLabel',width=8);self.counter.pack(side='left',padx=4)
        self.jump=ttk.Combobox(controls,state='readonly',width=11,font=theme.fonts['small'])
        self.jump.pack(side='right');self.jump.bind('<<ComboboxSelected>>',self.jump_stage)
        ttk.Label(controls,text='Jump to stage ',style='Small.TLabel').pack(side='right')
        self.slider=ttk.Scale(controls,from_=0,to=1,command=self.seek);self.slider.pack(side='left',fill='x',expand=True,padx=8)
        self.heading=ttk.Label(self,text='',style='SmallHeading.TLabel');self.heading.grid(row=4,column=0,sticky='ew',pady=(2,1))
        self.caption=read_only_text(self,theme,height=3);self.caption.configure(font=theme.fonts['small'],pady=4)
        self.caption.grid(row=5,column=0,sticky='ew')
        self.bind('<Destroy>',lambda e:self.cleanup() if e.widget is self else None)
        self.bind('<Configure>',self.resize_text)
        # Bind at the window; only consume navigation keys when this tab is visible.
        self.winfo_toplevel().bind('<Left>',lambda e:self.key_step(e,-1),add='+')
        self.winfo_toplevel().bind('<Right>',lambda e:self.key_step(e,1),add='+')

    def resize_text(self,event):
        self.inspector.configure(wraplength=max(300,event.width-30))

    def key_step(self,event,direction):
        if self.winfo_ismapped() and event.widget.winfo_class() not in ('TEntry','TCombobox','Text','TSpinbox'):
            self.go(self.index+direction);return 'break'

    def update_view(self,analysis):
        self.stop();self.analysis=analysis;self.frames=build_trace(self.grid_model,analysis)
        self.index=0;self.selected=''
        self.jump.configure(values=list(dict.fromkeys(f.stage for f in self.frames)))
        self.slider.configure(to=max(1,len(self.frames)-1));self.redraw()

    def cleanup(self):
        self.stop()
        if self.render_job is not None:
            self.after_cancel(self.render_job);self.render_job=None

    def stop(self):
        if self.job is not None:
            self.after_cancel(self.job);self.job=None
        if hasattr(self,'play') and self.play.winfo_exists():self.play.configure(text='Play')

    def go(self,index,automatic=False):
        if not automatic:self.stop()
        if not self.frames:return
        self.index=max(0,min(len(self.frames)-1,index));self.selected='';self.redraw()

    def seek(self,value):
        index=int(round(float(value)))
        if index!=self.index:self.go(index)

    def jump_stage(self,_event=None):
        self.go(next(i for i,f in enumerate(self.frames) if f.stage==self.jump.get()))

    def toggle_play(self):
        if self.job is not None:self.stop();return
        if self.index==len(self.frames)-1:self.go(0)
        self.play.configure(text='Pause');self.job=self.after(2400,self.tick)

    def tick(self):
        self.job=None
        if not self.winfo_ismapped() or self.index>=len(self.frames)-1:self.stop();return
        self.go(self.index+1,automatic=True)
        if self.index<len(self.frames)-1:self.job=self.after(2400,self.tick)
        else:self.stop()

    def picked(self,event):
        ident=self.artists.get(event.artist)
        if ident and self.frames:
            self.selected=ident;self.inspector.configure(text=inspect(self.grid_model,self.frames[self.index],ident))
            if self.render_job is None:self.render_job=self.after_idle(self.render)

    def render(self):
        """Draw the current frame at the canvas' real pixel size (also called on every resize)."""
        self.render_job=None
        if not self.frames or self.drawing:return
        self.drawing=True
        try:
            ui=max(.6,self.winfo_fpixels('1i')/96)
            _,self.artists=schematic(self.grid_model,self.frames[self.index],self.backups.get(),self.selected,
                                      self.theme.scale,fig=self.canvas.figure,ui=ui)
            self.canvas.draw_idle()
        finally:
            self.drawing=False

    def redraw(self):
        if not self.frames:return
        f=self.frames[self.index];g=self.grid_model
        mw=sum(g.nodes[z].demand_mw for z in f.loads.routes)
        self.metrics.configure(text=f'{mw:g} / {g.total_demand():g} MW allocated    ·    {len(f.loads.routes)}/{len(g.zones)} zones    ·    {len(f.state.failed_lines)+len(f.state.failed_nodes)} faults')
        self.render()
        self.inspector.configure(text=inspect(g,f,self.selected))
        self.counter.configure(text=f'{self.index+1} / {len(self.frames)}')
        self.jump.set(f.stage);self.slider.set(self.index)
        self.prev.configure(state='disabled' if self.index==0 else 'normal')
        self.next.configure(state='disabled' if self.index==len(self.frames)-1 else 'normal')
        self.heading.configure(text=f'{f.stage.upper()}   /   {f.title}   ·   {f.algorithm}')
        set_text(self.caption,f.explanation)

    def current_figure(self):return self.canvas.figure

    def export_trace(self):
        if not self.frames:return
        path=filedialog.asksaveasfilename(defaultextension='.json',initialfile='decision_replay.json',filetypes=[('JSON replay','*.json')])
        if path:
            from pathlib import Path
            data={'scenario':self.analysis.scenario.name,'seed':self.analysis.seed,
                  'frames':[asdict(f) for f in self.frames]}
            Path(path).write_text(json.dumps(data,indent=2,default=lambda x:sorted(x) if isinstance(x,set) else str(x)),encoding='utf-8')
