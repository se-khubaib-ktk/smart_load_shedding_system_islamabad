"""Tab 6 - How it works: the pipeline diagram and one card per algorithm (for presentations)."""
import tkinter as tk
from tkinter import ttk
from typing import Callable

from . import figures
from .glossary import ALGORITHMS, PIPELINE, STAGE_TITLES
from .tab_base import TabBase
from .theme import PALETTE
from .widgets import FigureFrame, ScrollFrame

TAB_NAMES = ["Overview", "Fault detection and restoration", "Repair crews", "Load-shedding timetable",
             "Stress test", "How it works", "Benchmark"]


class HowItWorksTab(TabBase):
    def __init__(self, parent, theme, grid, goto: Callable[[int], None]):
        super().__init__(parent, theme, grid)
        self.goto = goto
        self.columnconfigure(0, weight=1)
        self.rowconfigure(2, weight=1)
        ttk.Label(self, text="The decision pipeline", style="Heading.TLabel").grid(row=0, column=0, sticky="w")
        self.diagram = FigureFrame(self)
        self.diagram.grid(row=1, column=0, sticky="ew", pady=(4, 8))
        self.scroll = ScrollFrame(self)
        self.scroll.grid(row=2, column=0, sticky="nsew")
        self.scroll.inner.columnconfigure(0, weight=1, uniform="algo")
        self.scroll.inner.columnconfigure(1, weight=1, uniform="algo")
        self.cards = []
        self._build_cards()
        self.redraw()

    def _build_cards(self):
        fonts = self.theme.fonts
        for index, algo in enumerate(ALGORITHMS):
            card = tk.Frame(self.scroll.inner, bg=PALETTE["surface"], highlightbackground=PALETTE["border"],
                            highlightthickness=1)
            card.grid(row=index // 2, column=index % 2, sticky="nsew", padx=6, pady=6)
            tk.Label(card, text=algo["name"], bg=PALETTE["surface"], fg=PALETTE["primary"],
                     font=fonts["heading"], anchor="w").pack(fill="x", padx=14, pady=(10, 2))
            wrap = {"wraplength": 420, "justify": "left", "anchor": "w", "bg": PALETTE["surface"],
                    "fg": PALETTE["text"], "font": fonts["base"]}
            tk.Label(card, text=algo["what"], **wrap).pack(fill="x", padx=14)
            tk.Label(card, text="Used here: " + algo["where"], **{**wrap, "fg": PALETTE["muted"]}).pack(
                fill="x", padx=14, pady=(6, 0))
            stage = STAGE_TITLES[algo["stage"]]
            tk.Label(card, text=f"Pipeline stage: {stage}", **{**wrap, "fg": PALETTE["muted"]}).pack(fill="x", padx=14)
            link = tk.Label(card, text="Show in the current run \u2192", bg=PALETTE["surface"],
                            fg=PALETTE["primary"], cursor="hand2", font=fonts["bold"], anchor="w")
            link.pack(fill="x", padx=14, pady=(6, 12))
            link.bind("<Button-1>", lambda _e, t=algo["tab"], s=algo["stage"]: self._open(t, s))
            self.cards.append(card)

    def _open(self, tab_index: int, stage: str):
        self.diagram.show(figures.pipeline_figure(stage, self.theme.scale))
        self.goto(tab_index)

    def redraw(self):
        self.diagram.show(figures.pipeline_figure(None, self.theme.scale))
        for card in self.cards:                       # keep wrapping sensible after font changes
            for child in card.winfo_children():
                if isinstance(child, tk.Label) and child.cget("wraplength"):
                    child.configure(wraplength=int(420 * self.theme.scale))

    def current_figure(self):
        return self.diagram.figure
