"""Legible electrical schematic, laid out in real canvas pixels.

The drawing is computed from the size of the canvas it is shown on, so boxes, text and lines keep their
proportions at any window size or screen scaling (nothing is squashed, nothing overlaps). Coordinates are
layout-only, never search inputs.
"""
import math
from matplotlib.figure import Figure
from matplotlib.patches import FancyBboxPatch
from .viewmodel import name_of

INK='#172d43'; MUTED='#62758a'; GREEN='#087f70'; BLUE='#2563eb'; RED='#cf4255'; AMBER='#bf7c13'; PURPLE='#8255ba'
GREY='#8b9bb0'; N_COLS=6


def _fit(text, px, width_px, minimum, weight_factor=0.60):
    """Largest font size (px) <= px whose text still fits width_px; truncate only as a last resort."""
    size=px
    while size>minimum and len(text)*size*weight_factor>width_px: size-=0.5
    room=int(width_px/(size*weight_factor))
    if len(text)>room: text=text[:max(3,room-1)].rstrip()+'…'
    return text,size


def _edge(c,other,w,h):
    """Point where the straight line from box centre `c` towards `other` leaves the box (w x h)."""
    dx,dy=other[0]-c[0],other[1]-c[1]
    if dx==0 and dy==0: return c
    t=min((w/2)/abs(dx) if dx else 1e9,(h/2)/abs(dy) if dy else 1e9)
    return (c[0]+dx*t,c[1]+dy*t)


def _bezier(p0,p1,bend):
    """Quadratic curve from p0 to p1 bent sideways by `bend` px; returns points and the curve midpoint."""
    mx,my=(p0[0]+p1[0])/2,(p0[1]+p1[1])/2; dx,dy=p1[0]-p0[0],p1[1]-p0[1]
    n=math.hypot(dx,dy) or 1; cx,cy=mx-dy/n*bend*2,my+dx/n*bend*2
    pts=[((1-t)**2*p0[0]+2*(1-t)*t*cx+t*t*p1[0],(1-t)**2*p0[1]+2*(1-t)*t*cy+t*t*p1[1]) for t in [i/24 for i in range(25)]]
    return pts,((p0[0]+2*cx+p1[0])/4,(p0[1]+2*cy+p1[1])/4)


def layout(grid,W,H,k=1.0):
    """Pixel positions for every node plus the box size. Row order: depots, sources, transformers, zones."""
    top,bottom,side=44*k,34*k,14*k
    Hc=H-top-bottom; u=Hc/7.0; cp=(W-2*side)/N_COLS
    gt=max(46*k,min(66*k,.2*cp))                 # left gutter of a column: holds the feeder drop and its label
    bw=cp-10*k-gt-4*k; bh=max(30*k,min(66*k,1.1*u-12*k))
    cx=lambda i:side+i*cp+gt+5*k+bw/2           # centre of a column's boxes
    ys={'depot':top+.45*u,'source':top+1.5*u,'transformer':top+3.05*u,'zone':[top+4.25*u,top+5.35*u,top+6.45*u]}
    pos={'S1':(cx(1),ys['source']),'S2':(cx(4),ys['source']),'D1':(cx(2),ys['depot']),'D2':(cx(3),ys['depot'])}
    children={f'T{i}':[] for i in range(1,N_COLS+1)}
    for line in grid.lines.values():
        if not line.normally_open and line.a in children and grid.nodes[line.b].type=='zone': children[line.a].append(line.b)
    cols={}
    for i,(t,zones) in enumerate(children.items()):
        pos[t]=(cx(i),ys['transformer']); cols[t]=(side+i*cp,cp-10*k)
        for j,z in enumerate(zones): pos[z]=(cx(i),ys['zone'][j])
    return pos,bw,bh,gt,cols


def schematic(grid, frame, show_backups=False, selected='', scale=1, fig=None, size=(1700,640), ui=1.0):
    """Draw `frame` into `fig` (created at `size` pixels when omitted). Returns (fig, {artist: id})."""
    if fig is None: fig=Figure(figsize=(size[0]/100,size[1]/100),dpi=100,facecolor='#ffffff')
    fig.clear(); fig.set_facecolor('#ffffff')
    W,H=fig.bbox.width,fig.bbox.height; k=max(.4,ui)*scale; pt=72/fig.dpi      # px -> points
    ax=fig.add_axes([0,0,1,1]); ax.set_xlim(0,W); ax.set_ylim(H,0); ax.axis('off')
    F=lambda px:px*k*pt                                                        # font px (scaled) -> points
    pos,bw,bh,gt,cols=layout(grid,W,H,k)
    ax.text(14*k,12*k,'ISLAMABAD / RAWALPINDI',color=INK,weight='bold',fontsize=F(16),va='top')
    ax.text(14*k+290*k,14*k,'Electrical schematic · not geographic scale',color=MUTED,fontsize=F(13),va='top')
    ax.text(W-14*k,13*k,frame.mode,ha='right',va='top',color=MUTED,fontsize=F(13))
    top=44*k
    for t,(gx,gw) in cols.items():
        ax.add_patch(FancyBboxPatch((gx,pos[t][1]-bh/2-8*k),gw,pos['Z1'][1]*0+(pos[t][1]*0)+ (H-34*k)-(pos[t][1]-bh/2-8*k),
            boxstyle='round,pad=0,rounding_size=%g'%(8*k),facecolor='#f4f7fb',edgecolor='none',zorder=0))
    highlights=set(frame.highlights); active=set(frame.loads.line_load); artists={}; direction={}
    for route in frame.loads.routes.values():
        rev=list(reversed(route.nodes))
        for a,b in zip(rev,rev[1:]):
            for line in grid.lines_at[a]:
                if line.other(a)==b: direction[line.id]=(a,b)
    zone_h=bh
    def draw_line(lid,line):
        failed=lid in frame.state.failed_lines or line.a in frame.state.failed_nodes or line.b in frame.state.failed_nodes
        is_open=line.normally_open
        if is_open and not (show_backups or lid in active or lid in highlights or lid==selected or failed): return
        focus=lid in highlights or lid==selected
        color=RED if failed else BLUE if focus else GREEN if lid in active else GREY
        lw=(2.6 if focus else 2.0 if lid in active else 1.2)*k
        a,b=direction.get(lid,(line.a,line.b)); flow=lid in active and not failed
        ls='--' if failed or (is_open and lid not in active) else '-'
        na,nb=grid.nodes[line.a],grid.nodes[line.b]
        if not is_open and nb.type=='zone':                  # transformer -> zone: orthogonal drop through the gutter
            tx,ty=pos[line.a]; zx,zy=pos[line.b]; gx=zx-bw/2-gt*.55
            pts=[(tx-bw/2,ty),(gx,ty),(gx,zy),(zx-bw/2,zy)]
            lx,ly=gx,zy-bh*.30
            label=f'{lid}\n{frame.loads.line_load.get(lid,0):g}/{line.capacity_mw:g}' if lid in active else f'{lid}\n'+('FAULT' if failed else '0 MW')
            if failed: label=f'{lid}\nFAULT ×'
            if ty==zy: pts=[(tx-bw/2,ty),(zx-bw/2,zy)]
        else:
            pa,pb=pos[a],pos[b]
            ba=(bw,bh); p0=_edge(pa,pb,*ba); p1=_edge(pb,pa,*ba)
            if is_open and na.type==nb.type=='transformer':
                if abs(pa[0]-pb[0])<1.5*(bw+gt):         # neighbouring columns: short straight tie in the gap
                    pts=[p0,p1]; lx,ly=(p0[0]+p1[0])/2,(p0[1]+p1[1])/2
                else:                                    # distant columns: arch over the transformer row
                    yt=pa[1]-bh/2; lift=.5*(yt-pos['S1'][1]-bh/2)
                    p0=(pa[0]+(bw*.25 if pb[0]>pa[0] else -bw*.25),yt); p1=(pb[0]+(-bw*.25 if pb[0]>pa[0] else bw*.25),yt)
                    pts,_=_bezier(p0,p1,lift); lx,ly=(p0[0]+p1[0])/2,yt-lift
            elif is_open:
                pts,(lx,ly)=_bezier(p0,p1,.10*math.hypot(p1[0]-p0[0],p1[1]-p0[1]))
            else:
                pts=[p0,p1]; t=.5; lx,ly=p0[0]+(p1[0]-p0[0])*t,p0[1]+(p1[1]-p0[1])*t
            load=frame.loads.line_load.get(lid,0)
            label=(f'{lid}  {load:g}/{line.capacity_mw:g}' if lid in active else
                   f'{lid}  FAULT ×' if failed else f'{lid}  open' if is_open else f'{lid}  0 MW')
        if flow and nb.type=='zone' and not is_open and len(pts)==4: pass
        art,=ax.plot([p[0] for p in pts],[p[1] for p in pts],color=color,lw=lw,ls=ls,zorder=1,picker=6,solid_capstyle='round')
        artists[art]=lid
        if flow:                                                   # arrow head in the direction of flow
            q0,q1=pts[-2],pts[-1]
            if direction.get(lid,(line.a,line.b))[0]!=line.a and not (not is_open and nb.type=='zone'): q0,q1=pts[1],pts[0]
            ax.annotate('',xy=q1,xytext=q0,arrowprops=dict(arrowstyle='-|>',color=color,lw=lw,mutation_scale=14*k,shrinkA=0,shrinkB=0),zorder=2)
        lab=min(12.5,(gt/k-8)/3.4) if (not is_open and nb.type=='zone') else (11.5 if is_open else 12.5)
        txt=ax.text(lx,ly,label,fontsize=F(lab),color=color,ha='center',va='center',zorder=4,weight='bold' if focus else 'normal',
            linespacing=1.05,bbox=dict(boxstyle='round,pad=.18',fc='white',ec='none',alpha=.97),picker=True)
        artists[txt]=lid
    for lid,line in grid.lines.items():
        draw_line(lid,line)
    for ident,node in grid.nodes.items():
        x,y=pos[ident]; failed=ident in frame.state.failed_nodes
        if node.type=='zone':
            supplied=ident in frame.loads.routes
            color=RED if failed else AMBER if ident in frame.cuts else GREEN if supplied else MUTED
            status='CUT' if ident in frame.cuts else 'ON' if supplied else 'OFF'
            detail=f'{node.demand_mw:g} MW · P{node.priority} · {status}'; symbol='●'
        elif node.type=='source':
            cap=frame.state.capacity_of(grid,ident); color=RED if cap<=0 else INK
            detail=f'{frame.loads.source_load.get(ident,0):g} / {cap:g} MW'; symbol='■'
        elif node.type=='depot':
            color=PURPLE; detail='Repair crew depot'; symbol='◆'
        else:
            color=RED if failed else INK; detail='FAILED' if failed else 'Transformer'; symbol='▲'
        focus=ident in (frame.focus,selected)
        ax.add_patch(FancyBboxPatch((x-bw/2,y-bh/2),bw,bh,boxstyle='round,pad=0,rounding_size=%g'%(7*k),
            facecolor='#fff5df' if ident in frame.cuts else '#fdecee' if failed else '#eaf3ff' if focus else 'white',
            edgecolor=BLUE if focus else color,linewidth=(2.8 if focus else 1.4)*k,
            zorder=5,picker=True))
        artists[ax.patches[-1]]=ident
        if ident in frame.cuts:                              # light hatch so the text stays readable
            ax.add_patch(FancyBboxPatch((x-bw/2,y-bh/2),bw,bh,boxstyle='round,pad=0,rounding_size=%g'%(7*k),
                fill=False,hatch='///',edgecolor=(.75,.49,.07,.28),linewidth=0,zorder=5.5))
        title,fs=_fit(f'{symbol} {ident} · {name_of(grid,ident)}',min(15,bh*.30/k),bw/k-14,10.5,.62)
        ax.text(x,y-bh*.17,title,ha='center',va='center',fontsize=F(fs),color=color,weight='bold',zorder=6)
        d,fd=_fit(detail,min(14,bh*.27/k),bw/k-14,10,.56)
        ax.text(x,y+bh*.22,d,ha='center',va='center',fontsize=F(fd),color=color,zorder=6,
                bbox=dict(boxstyle='square,pad=.1',fc='#fff5df' if ident in frame.cuts else '#fdecee' if failed else '#eaf3ff' if focus else 'white',ec='none'))
        if ident in frame.visited:
            ax.text(x+bw/2-7*k,y-bh/2+3*k,'✓',color=BLUE,fontsize=F(15),weight='bold',ha='center',va='center',zorder=7)
        if failed:
            ax.text(x+bw/2,y-bh/2,'×',color=RED,fontsize=F(26),weight='bold',ha='center',va='center',zorder=7)
    for a,b in zip(frame.road_path,frame.road_path[1:]):
        p0=_edge(pos[a],pos[b],bw,bh); p1=_edge(pos[b],pos[a],bw,bh)
        pts,_=_bezier(p0,p1,.1*math.hypot(p1[0]-p0[0],p1[1]-p0[1]))
        ax.plot([p[0] for p in pts],[p[1] for p in pts],color='#935bd0',ls=':',lw=3*k,zorder=8)
        ax.annotate('',xy=pts[-1],xytext=pts[-3],arrowprops=dict(arrowstyle='-|>',color='#935bd0',lw=3*k,mutation_scale=16*k),zorder=8)
    ax.text(14*k,H-12*k,'■ Source    ▲ Transformer    ● Demand zone    ◆ Depot       |       '
            'Green: allocated    Blue: focus    Red ×: failed    Amber hatch: planned cut    ✓ visited',
            fontsize=F(12.5),color=MUTED,va='center')
    return fig,artists


def inspect(grid,frame,ident):
    if ident in grid.lines:
        l=grid.lines[ident]; mw=frame.loads.line_load.get(ident,0)
        unavailable=ident in frame.state.failed_lines or l.a in frame.state.failed_nodes or l.b in frame.state.failed_nodes
        return (f'{ident} · {l.a} ↔ {l.b}   |   {mw:g}/{l.capacity_mw:g} MW allocated '
            f'({mw/l.capacity_mw*100:.0f}%)   |   '+('unavailable' if unavailable else 'backup line' if l.normally_open else 'normal feeder')+
            f'   |   UCS edge cost {l.cost:.2f}')
    if ident in grid.nodes:
        n=grid.nodes[ident]
        if n.type=='zone':
            r=frame.loads.routes.get(ident)
            return f'{ident} · {n.name}   |   {n.demand_mw:g} MW · priority {n.priority}   |   '+(' → '.join(reversed(r.nodes)) if r else 'No allocation in this frame')
        if n.type=='source':
            return f'{ident} · {n.name}   |   allocated {frame.loads.source_load.get(ident,0):g} MW / available {frame.state.capacity_of(grid,ident):g} MW'
        return f'{ident} · {n.name}   |   {n.type}   |   '+('Failed' if ident in frame.state.failed_nodes else 'Available')
    return 'Click a node or line to inspect it. Line labels show allocated / rated MW. Backup ties are hidden unless active; enable All ties to inspect the full network.'
