"""Plain-language explanations used for tooltips and the "How it works" tab."""

# Short help for technical terms (shown as tooltips next to the term).
GLOSSARY = {
    "supplied": "Share of the city's total demand (in MW) that is receiving power after the "
                "restoration step.",
    "shed": "Zones that can be reached by a working line but have no spare power. They get "
            "rotating cuts according to the load-shedding timetable.",
    "isolated": "Zones with no working path to any grid station. They stay dark until a repair "
                "crew fixes the broken part.",
    "repair": "Time until the last repair job is finished, counting travel and repair work for "
              "the crews working in parallel.",
    "jain": "Jain's fairness index measures how evenly the power cuts are shared. 1.00 means "
            "every zone carries its fair share; lower numbers mean some zones are cut much "
            "more than others.",
    "resilience": "Resilience score: how much of the load that is served right now would still "
                  "be served after the worst two further failures an adversary could cause. "
                  "100% = nothing more would be lost, 0% = everything could be lost.",
    "alpha_beta": "Alpha-beta pruning lets Minimax skip branches that cannot change the final "
                  "answer, so the same worst case is found after searching far fewer states.",
    "breaker": "A breaker operation is one switch being opened or closed to cut or restore a "
               "zone. Fewer operations means less wear and fewer chances of human error.",
    "deficit": "Deficit: megawatts of demand that can be reached but cannot be supplied "
               "because the working grid stations are full. Rotating cuts must cover it.",
    "weighted_cost": "Sum over all repair jobs of (priority-weighted MW that depend on the "
                     "job x minutes until it is finished). Lower is better: important loads "
                     "come back sooner.",
    "tie_switch": "A normally-open switch joining two feeders. Closing it lets power reach a "
                  "zone from a different transformer or grid station.",
    "priority": "Zone priority: 1 hospital (never cut), 2 industrial, 3 market, 4 residential.",
    "seed": "Random seed. The Genetic Algorithm and Simulated Annealing use random numbers; "
            "the same seed always gives the same answer, so a demonstration can be repeated.",
    "custom": "Build your own 'what if': tick lines or grid stations to fail and lower a grid "
              "station's output, then press Run analysis.",
}

# One card per algorithm: (name, explanation, where it is used, tab index, stage to show)
# Tab indexes: 0 Overview, 1 Detect & restore, 2 Repair crews, 3 Load-shedding,
#              4 Stress test, 5 How it works, 6 Benchmark
ALGORITHMS = [
    {"name": "Depth-First Search (DFS)",
     "what": "Follows one path as far as it can before backing up - a fast way to find "
             "everything that is still connected to a source.",
     "where": "Fault detection: finds every node still energised from the working grid "
              "stations, so the cut-off zones are known.",
     "tab": 1, "stage": "detect"},
    {"name": "Breadth-First Search (BFS)",
     "what": "Explores outward one step at a time, so it finds the route with the fewest steps.",
     "where": "Fault detection: counts how many lines away the nearest backup source is "
              "for every dark zone.",
     "tab": 1, "stage": "detect"},
    {"name": "Uniform Cost Search (UCS)",
     "what": "Always extends the cheapest path found so far, so it returns the lowest-cost "
             "route even when links have different costs.",
     "where": "Service restoration: cheapest re-route that respects line and station "
              "capacity, hospitals first.",
     "tab": 1, "stage": "restore"},
    {"name": "A* search",
     "what": "Like UCS, but it adds a straight-line-distance guess to head towards the goal, "
             "so it finds the same best route while looking at fewer places.",
     "where": "Repair crews: fastest road route from a depot to every fault site.",
     "tab": 2, "stage": "dispatch"},
    {"name": "Genetic Algorithm",
     "what": "Evolves a population of candidate answers with selection, crossover and "
             "mutation, keeping the best ones in every generation.",
     "where": "Repair crews: the order in which faults are repaired so that important loads "
              "wait the least.",
     "tab": 2, "stage": "dispatch"},
    {"name": "Constraint Satisfaction (CSP)",
     "what": "Assigns values to variables so that every rule holds; backtracking with MRV "
             "(most constrained first) and forward checking drops dead ends early.",
     "where": "Load-shedding: which zones to cut in each 2-hour slot (never a hospital, "
              "at most 2 slots in a row, enough MW to cover the deficit).",
     "tab": 3, "stage": "shed"},
    {"name": "Simulated Annealing",
     "what": "Makes small random changes to a solution and sometimes accepts a worse one "
             "early on, which helps it escape local optima as it 'cools down'.",
     "where": "Load-shedding: improves the timetable's fairness and cuts breaker "
              "operations while keeping every rule satisfied.",
     "tab": 3, "stage": "shed"},
    {"name": "Minimax with alpha-beta pruning",
     "what": "Plans against an opponent: the adversary picks the most damaging failure, the "
             "planner picks the best answer. Alpha-beta pruning skips branches that cannot "
             "change the result.",
     "where": "Stress test: finds the worst-case sequence of failures and the resilience "
              "score.",
     "tab": 4, "stage": "stress"},
]

# The pipeline, in order: (stage key, title, algorithms)
PIPELINE = [
    ("detect", "1  Detect", "DFS, BFS"),
    ("restore", "2  Restore", "Uniform Cost Search"),
    ("dispatch", "3  Dispatch", "A*, Genetic Algorithm"),
    ("shed", "4  Shed", "CSP, Simulated Annealing"),
    ("stress", "5  Stress test", "Minimax + alpha-beta"),
]

STAGE_TITLES = {key: title.strip() for key, title, _ in PIPELINE}
