"""Matplotlib figures for the GUI (and for the screenshot script).

Every function returns a `Figure` built without pyplot, so it can be embedded in tkinter
or saved with `fig.savefig`. `scale` enlarges all text for Presentation mode.
"""
from matplotlib.figure import Figure
from matplotlib.patches import FancyArrowPatch, FancyBboxPatch, Patch

from ..utils.map_drawing import COLORS, DEPOT_COLOR, draw_grid_map
from . import viewmodel as vm
from .glossary import PIPELINE

BLUE, GREEN, AMBER, RED, GREY = "#1f5fa8", "#2e9e5b", "#f0a020", "#d63a3a", "#8895a5"
TEXT = "#1f2933"


def _fig(width, height, scale=1.0, constrained=True):
    fig = Figure(figsize=(width, height), dpi=100, facecolor="white")
    if constrained:
        fig.set_layout_engine("constrained")
    return fig


def _axes_style(ax, scale, grid_axis=None):
    ax.tick_params(labelsize=10.5 * scale, colors=TEXT)
    for side in ("top", "right"):
        ax.spines[side].set_visible(False)
    if grid_axis:
        ax.grid(axis=grid_axis, alpha=0.25)
        ax.set_axisbelow(True)


def _title(ax, text, scale):
    ax.set_title(text, fontsize=12 * scale, fontweight="bold", color=TEXT, loc="left")


def _empty(message, scale=1.0, size=(6, 3)):
    fig = _fig(*size, scale)
    ax = fig.add_subplot(111)
    ax.axis("off")
    ax.text(0.5, 0.5, message, ha="center", va="center", fontsize=12 * scale, color=GREY,
            wrap=True, transform=ax.transAxes)
    return fig


# ---- map ---------------------------------------------------------------------
def map_figure(grid, analysis, stage=None, focus_zone=None, scale=1.0, size=(7.0, 6.2)):
    """Returns (figure, axes, positions). The legend is a Tk widget, so it is off here."""
    fig = _fig(*size, scale, constrained=False)
    ax = fig.add_subplot(111)
    fig.subplots_adjust(left=0.08, right=0.985, bottom=0.09, top=0.97)
    positions = draw_grid_map(ax, grid, analysis.result, stage=stage, focus_zone=focus_zone,
                              label_size=9.5 * scale, legend=False, tighten=False)
    ax.tick_params(labelsize=10 * scale)
    ax.set_xlabel("km east", fontsize=10.5 * scale)
    ax.set_ylabel("km north", fontsize=10.5 * scale)
    return fig, ax, positions


# ---- repair crews -----------------------------------------------------------------
def gantt_figure(grid, analysis, scale=1.0):
    dispatch = analysis.result.dispatch
    if not dispatch:
        return _empty("No physical faults - no repair crews needed.", scale)
    fig = _fig(8.5, 3.8, scale)
    ax = fig.add_subplot(111)
    rows = len(dispatch.crews)
    for crew, (depot, visits) in enumerate(zip(dispatch.crews, dispatch.visits)):
        y = rows - crew - 1
        for v in visits:
            start = v.arrive - v.travel_min
            ax.barh(y, v.travel_min / 60, left=start / 60, height=0.5, color="#d9c9f2",
                    edgecolor=DEPOT_COLOR, hatch="//")
            ax.barh(y, (v.finish - v.arrive) / 60, left=v.arrive / 60, height=0.5, color=BLUE,
                    edgecolor="white")
            ax.text((v.arrive + v.finish) / 120, y, v.fault.component, ha="center", va="center",
                    color="white", fontsize=10.5 * scale, fontweight="bold")
    ax.set_yticks(range(rows))
    ax.set_yticklabels([f"Crew {c + 1}\n{vm.name_of(grid, d)}" for c, d in
                        reversed(list(enumerate(dispatch.crews)))], fontsize=10.5 * scale)
    ax.set_xlabel("hours from the fault", fontsize=11 * scale)
    ax.legend(handles=[Patch(facecolor="#d9c9f2", edgecolor=DEPOT_COLOR, hatch="//", label="travel"),
                       Patch(facecolor=BLUE, label="repair work")],
              fontsize=10.5 * scale, loc="upper center", bbox_to_anchor=(0.5, -0.22), ncol=2,
              frameon=False)
    _axes_style(ax, scale, "x")
    _title(ax, "Repair crew timeline", scale)
    return fig


def crew_comparison_figure(analysis, scale=1.0):
    data = vm.crew_comparison(analysis)
    if not data:
        return _empty("No repair jobs to compare.", scale, (5, 3))
    fig = _fig(5.2, 3.4, scale)
    ax = fig.add_subplot(111)
    names, values = list(data), list(data.values())
    colors = [GREEN if n == "Genetic Algorithm" else GREY for n in names]
    bars = ax.bar(range(len(names)), values, color=colors)
    ax.set_xticks(range(len(names)))
    ax.set_xticklabels([n.replace(" ", "\n", 1) for n in names], fontsize=10.5 * scale)
    for bar, value in zip(bars, values):
        ax.text(bar.get_x() + bar.get_width() / 2, value, f"{value:,.0f}", ha="center",
                va="bottom", fontsize=10.5 * scale)
    ax.set_ylabel("weighted waiting cost", fontsize=11 * scale)
    ax.set_ylim(0, max(values) * 1.15 if max(values) else 1)
    _axes_style(ax, scale, "y")
    _title(ax, "Repair order: lower is better", scale)
    return fig


def convergence_figure(analysis, scale=1.0):
    history = analysis.result.dispatch.history if analysis.result.dispatch else []
    if not history:
        return _empty("No Genetic Algorithm run in this case.", scale, (5, 3))
    fig = _fig(5.2, 3.0, scale)
    ax = fig.add_subplot(111)
    ax.plot(range(len(history)), history, color=GREEN, linewidth=2.2)
    ax.annotate(f"{history[0]:,.0f}", (0, history[0]), textcoords="offset points", xytext=(6, -2),
                fontsize=10.5 * scale)
    ax.annotate(f"{history[-1]:,.0f}", (len(history) - 1, history[-1]), textcoords="offset points",
                xytext=(-8, 8), ha="right", fontsize=10.5 * scale)
    ax.set_xlabel("generation", fontsize=11 * scale)
    ax.set_ylabel("best cost so far", fontsize=11 * scale)
    _axes_style(ax, scale, "y")
    _title(ax, "Genetic Algorithm convergence", scale)
    return fig


# ---- load-shedding heat-map ---------------------------------------------------------
def heatmap_figure(grid, analysis, which="both", scale=1.0):
    plan = analysis.result.shedding
    if not plan.csp_schedule:
        return _empty(vm.shedding_note(grid, analysis), scale, (8, 3.4))
    panels = {"csp": ("CSP result", plan.csp_schedule), "sa": ("After Simulated Annealing", plan.sa_schedule)}
    keys = ["csp", "sa"] if which == "both" else [which]
    from matplotlib.colors import ListedColormap
    cmap = ListedColormap(["#e3f1e8", AMBER])
    zones = sorted(grid.zones, key=lambda z: (z.priority, int(z.id[1:])))
    slots = len(plan.sa_schedule)
    hours_per_slot = 24 // slots if slots else 2
    fig = _fig(5.6 * len(keys) + 2.0, 4.6, scale)
    axes = fig.subplots(1, len(keys), sharey=True)
    axes = [axes] if len(keys) == 1 else list(axes)
    for ax, key in zip(axes, keys):
        title, schedule = panels[key]
        matrix = [[1 if z.id in schedule[t] else 0 for t in range(slots)] for z in zones]
        ax.imshow(matrix, cmap=cmap, aspect="auto", vmin=0, vmax=1)
        ax.set_xticks(range(slots))
        ax.set_xticklabels([f"{t * hours_per_slot:02d}" for t in range(slots)], fontsize=10.5 * scale)
        ax.set_yticks(range(len(zones)))
        ax.set_yticklabels([f"{z.id} {vm.name_of(grid, z.id)}" for z in zones], fontsize=10.5 * scale)
        ax.set_xticks([i - 0.5 for i in range(slots + 1)], minor=True)
        ax.set_yticks([i - 0.5 for i in range(len(zones) + 1)], minor=True)
        ax.grid(which="minor", color="white", linewidth=1.5)
        ax.tick_params(which="minor", length=0)
        ax.set_xlabel("start hour of each slot", fontsize=11 * scale)
        _title(ax, title, scale)
        for r, z in enumerate(zones):
            cut = sum(1 for t in range(slots) if z.id in schedule[t]) * hours_per_slot
            if cut:
                ax.text(slots - 0.4, r, f"{cut} h", va="center", fontsize=10 * scale, color=TEXT)
    axes[-1].legend(handles=[Patch(facecolor=AMBER, label="power cut"),
                             Patch(facecolor="#e3f1e8", label="power on")],
                    fontsize=10.5 * scale, loc="upper left", bbox_to_anchor=(1.07, 1.0), frameon=False)
    return fig


# ---- stress test ------------------------------------------------------------------------
def stress_figure(analysis, scale=1.0):
    with_ab, without, pruned = vm.stress_search_numbers(analysis)
    fig = _fig(5.4, 3.6, scale)
    ax = fig.add_subplot(111)
    bars = ax.bar(["Plain\nMinimax", "With\nalpha-beta"], [without, with_ab], color=[GREY, GREEN], width=0.55)
    for bar, value in zip(bars, [without, with_ab]):
        ax.text(bar.get_x() + bar.get_width() / 2, value, f"{value:,}", ha="center", va="bottom",
                fontsize=11 * scale, fontweight="bold")
    saved = (1 - with_ab / without) * 100 if without else 0
    ax.set_ylim(0, max(without, 1) * 1.2)
    ax.set_ylabel("states searched", fontsize=11 * scale)
    ax.tick_params(axis="x", labelsize=11 * scale)
    _axes_style(ax, scale, "y")
    ax.set_xlabel(f"{pruned:,} branches skipped by alpha-beta pruning", fontsize=11 * scale)
    _title(ax, f"{saved:.0f}% fewer states searched", scale)
    return fig


# ---- pipeline diagram ----------------------------------------------------------------------
def pipeline_figure(active=None, scale=1.0):
    fig = _fig(11.5, 2.0, scale, constrained=False)
    ax = fig.add_axes([0.01, 0.02, 0.98, 0.96])
    ax.set_xlim(0, 5.6)
    ax.set_ylim(0, 1)
    ax.axis("off")
    for i, (key, title, algs) in enumerate(PIPELINE):
        x = 0.05 + i * 1.1
        on = key == active
        ax.add_patch(FancyBboxPatch((x, 0.15), 0.9, 0.7, boxstyle="round,pad=0.02,rounding_size=0.08",
                                    facecolor=BLUE if on else "#eef3f9", edgecolor=BLUE, linewidth=2))
        ax.text(x + 0.45, 0.63, title, ha="center", va="center", fontsize=12 * scale,
                fontweight="bold", color="white" if on else BLUE)
        ax.text(x + 0.45, 0.35, algs, ha="center", va="center", fontsize=10 * scale,
                color="white" if on else TEXT, wrap=True)
        if i < len(PIPELINE) - 1:
            ax.add_patch(FancyArrowPatch((x + 0.93, 0.5), (x + 1.12, 0.5), arrowstyle="-|>",
                                         mutation_scale=18, color=GREY, linewidth=2))
    return fig


# ---- benchmark ---------------------------------------------------------------------------------
def benchmark_figures(parsed, scale=1.0):
    """{sub-tab title: Figure}."""
    figs = {}
    path = parsed["path"]
    fig = _fig(6.5, 3.4, scale)
    a1, a2 = fig.subplots(1, 2)
    names = list(path)
    for ax, metric, title in ((a1, "avg nodes expanded", "Nodes expanded"),
                              (a2, "avg travel minutes", "Travel time (min)")):
        ax.bar(names, [path[n][metric] for n in names], color=[GREY, BLUE, GREEN][:len(names)])
        _axes_style(ax, scale, "y")
        _title(ax, title, scale)
    figs["Path search"] = fig

    crew = parsed["crew"]
    fig = _fig(6.0, 3.4, scale)
    ax = fig.add_subplot(111)
    ax.bar(list(crew), list(crew.values()), color=[GREEN if "Genetic" in k else GREY for k in crew])
    ax.tick_params(axis="x", labelsize=10 * scale)
    _axes_style(ax, scale, "y")
    _title(ax, "Average weighted repair cost (lower is better)", scale)
    figs["Crew ordering"] = fig

    shed = parsed["shedding"]
    fig = _fig(7.0, 3.4, scale)
    a1, a2 = fig.subplots(1, 2)
    labels = list(shed)
    xs = range(len(labels))
    for ax, metric, title in ((a1, "jain", "Fairness (higher is better)"),
                              (a2, "breaker ops", "Breaker ops (lower is better)")):
        ax.bar([x - 0.2 for x in xs], [shed[s][f"CSP|{metric}"] for s in labels], 0.4, label="CSP", color=GREY)
        ax.bar([x + 0.2 for x in xs], [shed[s][f"CSP+SA|{metric}"] for s in labels], 0.4, label="CSP + SA", color=GREEN)
        ax.set_xticks(list(xs))
        ax.set_xticklabels(labels, fontsize=10.5 * scale)
        _axes_style(ax, scale, "y")
        _title(ax, title, scale)
    a1.set_ylim(0, 1.25)
    a1.legend(fontsize=10.5 * scale, frameon=False, ncol=2, loc="upper center")
    figs["Load-shedding"] = fig

    mm = parsed["minimax"]
    fig = _fig(6.0, 3.4, scale)
    ax = fig.add_subplot(111)
    labels = list(mm)
    xs = range(len(labels))
    ax.bar([x - 0.2 for x in xs], [mm[s]["plain|nodes"] for s in labels], 0.4, label="plain", color=GREY)
    ax.bar([x + 0.2 for x in xs], [mm[s]["alpha-beta|nodes"] for s in labels], 0.4, label="alpha-beta", color=GREEN)
    ax.set_xticks(list(xs))
    ax.set_xticklabels(labels, fontsize=10.5 * scale)
    ax.legend(fontsize=10.5 * scale, frameon=False)
    _axes_style(ax, scale, "y")
    _title(ax, "States searched by Minimax", scale)
    figs["Minimax pruning"] = fig
    return figs
