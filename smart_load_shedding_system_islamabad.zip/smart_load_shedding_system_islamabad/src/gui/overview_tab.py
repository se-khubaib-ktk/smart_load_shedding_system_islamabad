"""Tab 1 - Overview: a large interactive map, six summary cards and the step-through control."""
import tkinter as tk
from tkinter import ttk

from . import viewmodel as vm
from .glossary import GLOSSARY, PIPELINE
from .map_view import MapView
from .tab_base import TabBase
from .theme import PALETTE
from .widgets import ScrollFrame, StatCard

PANEL_WIDTH = 440


class OverviewTab(TabBase):
    def __init__(self, parent, theme, grid):
        super().__init__(parent, theme, grid)
        self.stage = None
        panes = ttk.PanedWindow(self, orient="horizontal")
        panes.pack(fill="both", expand=True)

        # left: the map gets all the space it can have
        self.map = MapView(panes, theme)
        panes.add(self.map, weight=4)

        # right: cards, step-through, explanation
        scroll = ScrollFrame(panes, width=PANEL_WIDTH)
        panes.add(scroll, weight=1)
        panel = scroll.inner
        panel.columnconfigure(0, weight=1, uniform="col")
        panel.columnconfigure(1, weight=1, uniform="col")

        ttk.Label(panel, text="Summary of this run", style="Heading.TLabel").grid(
            row=0, column=0, columnspan=2, sticky="w", padx=6, pady=(0, 4))
        self.cards = {}
        keys = [("supplied", "Supplied"), ("shed", "Load-shed"), ("isolated", "Isolated"),
                ("repair", "Repair time"), ("fairness", "Fairness"), ("resilience", "Resilience")]
        helps = {"fairness": "jain"}
        for index, (key, title) in enumerate(keys):
            card = StatCard(panel, theme, title, GLOSSARY[helps.get(key, key)])
            card.grid(row=1 + index // 2, column=index % 2, sticky="nsew", padx=4, pady=4)
            self.cards[key] = card

        ttk.Label(panel, text="Step through the pipeline", style="Heading.TLabel").grid(
            row=4, column=0, columnspan=2, sticky="w", padx=6, pady=(12, 4))
        self.buttons = {}
        for index, (key, title, _algs) in enumerate(PIPELINE):
            button = ttk.Button(panel, text=title.strip(), style="Stage.TButton",
                                command=lambda k=key: self.set_stage(k))
            button.grid(row=5 + index // 2, column=index % 2, sticky="ew", padx=4, pady=2)
            self.buttons[key] = button
        ttk.Button(panel, text="Show all", style="Stage.TButton",
                   command=lambda: self.set_stage(None)).grid(row=7, column=1, sticky="ew", padx=4, pady=2)
        ttk.Button(panel, text="\u25C0 Back", style="Stage.TButton",
                   command=lambda: self.step(-1)).grid(row=8, column=0, sticky="ew", padx=4, pady=(8, 2))
        ttk.Button(panel, text="Next \u25B6", style="Stage.TButton",
                   command=lambda: self.step(1)).grid(row=8, column=1, sticky="ew", padx=4, pady=(8, 2))

        self.caption = tk.Label(panel, text="Run an analysis to begin.", anchor="nw", justify="left",
                                bg=PALETTE["surface"], fg=PALETTE["text"], font=theme.fonts["base"],
                                padx=10, pady=8, relief="solid", borderwidth=1, wraplength=PANEL_WIDTH - 50)
        self.caption.grid(row=9, column=0, columnspan=2, sticky="ew", padx=4, pady=(10, 4))
        ttk.Button(panel, text="Open the map in a big window", command=self.open_big_map).grid(
            row=10, column=0, columnspan=2, sticky="ew", padx=4, pady=(6, 10))
        panel.bind("<Configure>", lambda e: self.caption.configure(wraplength=max(200, e.width - 40)))

    # ---- stage control ----------------------------------------------------------
    def set_stage(self, stage):
        self.stage = stage
        if self.analysis:
            self.redraw()

    def step(self, direction: int):
        order = [key for key, _t, _a in PIPELINE]
        if self.stage is None:
            target = 0 if direction > 0 else len(order) - 1
        else:
            target = min(len(order) - 1, max(0, order.index(self.stage) + direction))
        self.set_stage(order[target])

    def redraw(self):
        if not self.analysis:
            return
        for data in vm.build_cards(self.grid_model, self.analysis):
            self.cards[data.key].set(data.value, data.detail, data.tone)
        for key, button in self.buttons.items():
            button.configure(style="StageActive.TButton" if key == self.stage else "Stage.TButton")
        self.caption.configure(text=vm.stage_caption(self.grid_model, self.analysis, self.stage))
        self.map.render(self.grid_model, self.analysis, stage=self.stage)

    def open_big_map(self):
        """The same map in its own maximised window (useful on a projector)."""
        if not self.analysis:
            return
        window = tk.Toplevel(self)
        window.title("Grid map - press Esc to close")
        try:
            window.state("zoomed")
        except tk.TclError:
            window.geometry("1200x850")
        view = MapView(window, self.theme)
        view.pack(fill="both", expand=True, padx=8, pady=8)
        view.render(self.grid_model, self.analysis, stage=self.stage)
        window.bind("<Escape>", lambda _e: window.destroy())

    def current_figure(self):
        return self.map.figure()
