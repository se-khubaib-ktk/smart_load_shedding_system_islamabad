"""Left sidebar: scenario choice, custom fault builder, seed, Run and Export buttons."""
import tkinter as tk
from tkinter import ttk
from typing import Callable

from .. import config
from ..utils.map_drawing import short_name
from .glossary import GLOSSARY
from .theme import PALETTE
from .widgets import ScrollFrame, help_icon

WIDTH = 320


class Sidebar(ttk.Frame):
    def __init__(self, parent, theme, controller, on_run: Callable[[], None],
                 on_export: Callable[[], None]):
        super().__init__(parent, width=WIDTH)
        self.pack_propagate(False)                  # keep the sidebar a fixed width
        self.theme, self.controller = theme, controller
        self.grid_model = controller.grid
        self._resetting = False
        scroll = ScrollFrame(self)
        scroll.pack(fill="both", expand=True)
        body = scroll.inner
        body.columnconfigure(0, weight=1)

        # -- scenario
        box = ttk.LabelFrame(body, text="Scenario", padding=10)
        box.grid(row=0, column=0, sticky="ew", padx=8, pady=(8, 6))
        box.columnconfigure(0, weight=1)
        self.mode = tk.StringVar(value="preset")
        self.scenario_var = tk.StringVar()
        names = [f"{s.id}. {s.name}" for s in controller.scenarios]
        self.combo = ttk.Combobox(box, textvariable=self.scenario_var, values=names, state="readonly")
        self.combo.current(0)
        self.combo.grid(row=0, column=0, sticky="ew")
        self.combo.bind("<<ComboboxSelected>>", self._on_combo)
        self.description = ttk.Label(box, wraplength=WIDTH - 60, style="Muted.TLabel", justify="left")
        self.description.grid(row=1, column=0, sticky="ew", pady=(8, 4))
        ttk.Radiobutton(box, text="Run the preset scenario", variable=self.mode,
                        value="preset").grid(row=2, column=0, sticky="w")
        ttk.Radiobutton(box, text="Run my custom fault", variable=self.mode,
                        value="custom").grid(row=3, column=0, sticky="w")
        self._show_description()

        # -- custom fault builder (secondary: hidden in presentation mode)
        self.advanced = ttk.Frame(body)
        self.advanced.grid(row=1, column=0, sticky="ew")
        self.advanced.columnconfigure(0, weight=1)
        custom = ttk.LabelFrame(self.advanced, text="Custom fault builder", padding=10)
        custom.grid(row=0, column=0, sticky="ew", padx=8, pady=6)
        custom.columnconfigure(0, weight=1)
        head = ttk.Frame(custom)
        head.grid(row=0, column=0, sticky="ew")
        ttk.Label(head, text="Click to tick lines or stations to fail:", style="Muted.TLabel").pack(side="left")
        help_icon(head, GLOSSARY["custom"], theme, PALETTE["bg"]).pack(side="right")
        ttk.Label(custom, text="Power lines", style="Heading.TLabel").grid(row=1, column=0, sticky="w", pady=(6, 0))
        self.line_ids = list(self.grid_model.lines)
        self.lines_box = self._listbox(custom, 2, [
            self._line_text(self.grid_model.lines[i]) for i in self.line_ids], 4)
        ttk.Label(custom, text="Transformers / stations", style="Heading.TLabel").grid(row=3, column=0, sticky="w", pady=(6, 0))
        self.node_ids = [n.id for n in self.grid_model.of_type("transformer")]
        self.nodes_box = self._listbox(custom, 4, [
            f"{i}  {short_name(self.grid_model.nodes[i].name)}" for i in self.node_ids], 3)
        ttk.Label(custom, text="Grid station output", style="Heading.TLabel").grid(row=5, column=0, sticky="w", pady=(6, 0))
        self.scales = {}
        self.scale_labels = {}
        row = 6
        for source in self.grid_model.sources:
            label = ttk.Label(custom, text="")
            label.grid(row=row, column=0, sticky="w")
            var = tk.DoubleVar(value=source.capacity_mw)
            scale = ttk.Scale(custom, from_=0, to=source.capacity_mw, variable=var, orient="horizontal",
                              command=lambda _v, sid=source.id: self._on_scale(sid))
            scale.grid(row=row + 1, column=0, sticky="ew", pady=(0, 4))
            self.scales[source.id], self.scale_labels[source.id] = var, label
            self._on_scale(source.id, user=False)
            row += 2
        ttk.Button(custom, text="Clear custom fault", command=self.reset_custom).grid(
            row=row, column=0, sticky="ew", pady=(6, 0))

        seed_box = ttk.Frame(self.advanced)
        seed_box.grid(row=1, column=0, sticky="ew", padx=8, pady=(0, 6))
        ttk.Label(seed_box, text="Random seed").pack(side="left")
        help_icon(seed_box, GLOSSARY["seed"], theme, PALETTE["bg"]).pack(side="left", padx=6)
        self.seed_var = tk.StringVar(value=str(config.DEFAULT_SEED))
        ttk.Entry(seed_box, textvariable=self.seed_var, width=8, justify="right").pack(side="right")

        # -- actions
        actions = ttk.Frame(body)
        actions.grid(row=2, column=0, sticky="ew", padx=8, pady=(6, 10))
        actions.columnconfigure(0, weight=1)
        self.run_button = ttk.Button(actions, text="Run analysis", style="Accent.TButton", command=on_run)
        self.run_button.grid(row=0, column=0, sticky="ew")
        self.progress = ttk.Progressbar(actions, mode="indeterminate")
        self.progress.grid(row=1, column=0, sticky="ew", pady=(8, 0))
        self.message = ttk.Label(actions, text="Ready.", style="Muted.TLabel", wraplength=WIDTH - 40)
        self.message.grid(row=2, column=0, sticky="w", pady=(4, 8))
        self.export_button = ttk.Button(actions, text="Export report...", command=on_export)
        self.export_button.grid(row=3, column=0, sticky="ew")

    # ---- helpers --------------------------------------------------------------------
    def _line_text(self, line) -> str:
        names = self.grid_model.nodes
        tag = " (normally open)" if line.normally_open else ""
        return f"{line.id}  {short_name(names[line.a].name)} - {short_name(names[line.b].name)}{tag}"

    def _listbox(self, parent, row, items, height):
        frame = ttk.Frame(parent)
        frame.grid(row=row, column=0, sticky="ew")
        frame.columnconfigure(0, weight=1)
        box = tk.Listbox(frame, selectmode="multiple", height=height, exportselection=False,
                         activestyle="none", font=self.theme.fonts["base"], relief="solid",
                         borderwidth=1, selectbackground=PALETTE["primary"], selectforeground="white")
        bar = ttk.Scrollbar(frame, orient="vertical", command=box.yview)
        box.configure(yscrollcommand=bar.set)
        box.grid(row=0, column=0, sticky="ew")
        bar.grid(row=0, column=1, sticky="ns")
        for item in items:
            box.insert("end", item)
        box.bind("<<ListboxSelect>>", lambda _e: self.mode.set("custom"))
        return box

    def _on_combo(self, _event=None):
        self.mode.set("preset")
        self._show_description()

    def _show_description(self):
        self.description.configure(text=self.selected_scenario().description)

    def _on_scale(self, source_id, user=True):
        source = self.grid_model.nodes[source_id]
        value = round(self.scales[source_id].get())
        self.scale_labels[source_id].configure(
            text=f"{short_name(source.name)}: {value} of {source.capacity_mw:.0f} MW")
        if user and not self._resetting:
            self.mode.set("custom")

    def selected_scenario(self):
        return self.controller.scenarios[self.combo.current()]

    # ---- what the Run button needs ------------------------------------------------------
    def build_scenario(self):
        if self.mode.get() == "preset":
            return self.selected_scenario()
        failed_lines = {self.line_ids[i] for i in self.lines_box.curselection()}
        failed_nodes = {self.node_ids[i] for i in self.nodes_box.curselection()}
        derate = {}
        for source in self.grid_model.sources:
            value = round(self.scales[source.id].get())
            if value < source.capacity_mw - 0.5:
                derate[source.id] = float(value)
        return self.controller.custom_scenario(failed_lines, failed_nodes, derate)

    def get_seed(self) -> int:
        try:
            return int(self.seed_var.get().strip())
        except ValueError:
            raise ValueError("Please type a whole number (for example 42) in the random seed box.")

    def reset_custom(self):
        self._resetting = True
        self.lines_box.selection_clear(0, "end")
        self.nodes_box.selection_clear(0, "end")
        for source in self.grid_model.sources:
            self.scales[source.id].set(source.capacity_mw)
            self._on_scale(source.id, user=False)
        self._resetting = False

    def set_busy(self, busy: bool, text: str = ""):
        self.run_button.configure(state="disabled" if busy else "normal")
        self.export_button.configure(state="disabled" if busy else "normal")
        if busy:
            self.progress.start(12)
        else:
            self.progress.stop()
        self.message.configure(text=text or ("Working..." if busy else "Ready."))

    def set_presentation(self, on: bool):
        if on:
            self.advanced.grid_remove()
        else:
            self.advanced.grid()
        self.description.configure(wraplength=int(WIDTH * 0.8) if not on else int(WIDTH * 0.9))
