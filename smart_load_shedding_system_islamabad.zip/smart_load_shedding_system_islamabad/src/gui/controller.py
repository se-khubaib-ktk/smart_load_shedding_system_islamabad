"""Thin controller: runs the pipeline in a background thread and hands results to the views.

It never imports tkinter. The window passes in a `schedule(ms, callback)` function
(Tk's `root.after`) so results are delivered on the GUI thread.
"""
import contextlib
import io
import logging
import queue
import threading
import time
from dataclasses import dataclass
from typing import Callable, Dict, List, Optional, Set

from .. import config
from ..models.grid import load_grid
from ..models.state import GridState, Scenario, load_scenarios
from ..pipeline import ScenarioResult, run_scenario
from ..services.stress_test import StressResult, run_stress_test
from ..utils import report

log = logging.getLogger("smart_grid_gui")


@dataclass
class Analysis:
    """Everything the views need for one run."""
    scenario: Scenario
    result: ScenarioResult
    stress_compare: StressResult          # same stress test, also run without pruning
    seed: int
    seconds: float


@dataclass
class BenchmarkData:
    rows: list                            # (test, algorithm, metric, value)
    text: str                             # the printed tables
    seconds: float
    scenario_names: List[str]


class AnalysisController:
    def __init__(self, schedule: Callable[[int, Callable], object]):
        self.grid = load_grid()
        self.scenarios: List[Scenario] = load_scenarios()
        self._schedule = schedule
        self._queue: "queue.Queue" = queue.Queue()
        self.busy = False

    # ---- building scenarios ------------------------------------------------
    def custom_scenario(self, failed_lines: Set[str], failed_nodes: Set[str],
                        source_mw: Dict[str, float]) -> Scenario:
        """A 'what if' case. source_mw only lists stations that are derated."""
        parts = []
        if failed_lines:
            parts.append("lines " + ", ".join(sorted(failed_lines)))
        if failed_nodes:
            parts.append("stations " + ", ".join(sorted(failed_nodes)))
        for source_id, mw in sorted(source_mw.items()):
            parts.append(f"{self.grid.nodes[source_id].name} limited to {mw:.0f} MW")
        text = "Custom what-if: " + ("; ".join(parts) if parts else "no faults (healthy grid)") + "."
        state = GridState(set(failed_lines), set(failed_nodes), dict(source_mw))
        depots = [d.id for d in self.grid.depots][:2] or ["D1"]
        return Scenario(0, "Custom what-if", text, state, depots)

    # ---- analysis ----------------------------------------------------------
    def analyze(self, scenario: Scenario, seed: int) -> Analysis:
        """Blocking version (also used by tests)."""
        started = time.perf_counter()
        result = run_scenario(self.grid, scenario, seed, verbose=False, plot=False)
        compare = run_stress_test(self.grid, scenario.state, result.restoration.switch_ops,
                                  compare_unpruned=True)
        return Analysis(scenario, result, compare, seed, time.perf_counter() - started)

    def run_async(self, scenario: Scenario, seed: int,
                  on_done: Callable[[Analysis], None], on_error: Callable[[str], None]) -> bool:
        return self._start(lambda: self.analyze(scenario, seed), on_done, on_error)

    def run_benchmark_async(self, on_done: Callable[[BenchmarkData], None],
                            on_error: Callable[[str], None], seed: int) -> bool:
        return self._start(lambda: self.benchmark(seed), on_done, on_error)

    def benchmark(self, seed: int) -> BenchmarkData:
        from benchmarks.benchmark import run_benchmark       # prints tables, returns rows
        started = time.perf_counter()
        buffer = io.StringIO()
        with contextlib.redirect_stdout(buffer):
            rows = run_benchmark(self.grid, self.scenarios, seed)
        return BenchmarkData(rows, buffer.getvalue(), time.perf_counter() - started,
                             [s.name for s in self.scenarios])

    def report_text(self, analysis: Analysis) -> str:
        buffer = io.StringIO()
        with contextlib.redirect_stdout(buffer):
            report.print_scenario(self.grid, analysis.result)
        return buffer.getvalue()

    # ---- background thread plumbing -----------------------------------------
    def _start(self, job, on_done, on_error) -> bool:
        if self.busy:
            return False
        self.busy = True

        def worker():
            try:
                self._queue.put(("ok", job(), on_done))
            except Exception as error:                        # shown as a friendly message
                log.exception("analysis failed")
                self._queue.put(("error", error, on_error))

        threading.Thread(target=worker, daemon=True).start()
        self._schedule(80, self._poll)
        return True

    def _poll(self):
        try:
            kind, payload, callback = self._queue.get_nowait()
        except queue.Empty:
            self._schedule(80, self._poll)
            return
        self.busy = False
        if kind == "ok":
            callback(payload)
        else:
            callback("The analysis could not be completed for this combination of faults. "
                     "Please try a different case.")
