"""Colours, fonts and ttk styles. One place to change the look of the whole application."""
import tkinter as tk
from tkinter import font as tkfont
from tkinter import ttk

PALETTE = {
    "bg": "#f0f4f8", "surface": "#ffffff", "primary": "#126c78", "primary_dark": "#104e59",
    "text": "#1f2933", "muted": "#5f6b7a", "border": "#d5dbe3", "stripe": "#f7f9fb",
    "select": "#d8e6f7", "tip": "#fffbe6",
    "good": "#2e9e5b", "warn": "#e69a1c", "bad": "#d63a3a", "neutral": "#8895a5",
}
BASE_SIZE = 11                    # smallest text anywhere in the application (points)
PRESENTATION_SCALE = 1.2

# name -> (size, weight)
FONT_SPECS = {"base": (11, "normal"), "bold": (11, "bold"), "heading": (13, "bold"),
              "title": (16, "bold"), "card_value": (20, "bold"), "mono": (11, "normal"),
              "small": (10, "normal"), "small_bold": (10, "bold")}


class Theme:
    def __init__(self, root: tk.Misc):
        self.root = root
        self.scale = 1.0
        families = set(tkfont.families(root))
        family = next((f for f in ("Segoe UI", "Helvetica Neue", "Noto Sans", "DejaVu Sans", "Arial")
                       if f in families), tkfont.nametofont("TkDefaultFont").actual("family"))
        self.fonts = {}
        for name, (size, weight) in FONT_SPECS.items():
            fam = "Courier New" if name == "mono" and "Courier New" in families else family
            self.fonts[name] = tkfont.Font(root=root, family=fam, size=size, weight=weight)
        self.style = ttk.Style(root)
        try:
            self.style.theme_use("clam")          # the same look on every platform
        except tk.TclError:
            pass
        root.configure(bg=PALETTE["bg"])
        root.option_add("*Font", self.fonts["base"])
        root.option_add("*TCombobox*Listbox.font", self.fonts["base"])
        self._apply_styles()

    def set_scale(self, scale: float) -> None:
        """Presentation mode: every named font grows, then row heights are recomputed."""
        self.scale = scale
        for name, (size, _weight) in FONT_SPECS.items():
            self.fonts[name].configure(size=int(round(size * scale)))
        self._apply_styles()

    def _apply_styles(self) -> None:
        p, f, st = PALETTE, self.fonts, self.style
        row = f["base"].metrics("linespace") + 10
        st.configure(".", background=p["bg"], foreground=p["text"], font=f["base"],
                     bordercolor=p["border"], focuscolor=p["bg"])
        st.configure("TFrame", background=p["bg"])
        st.configure("Surface.TFrame", background=p["surface"])
        st.configure("TLabel", background=p["bg"], foreground=p["text"], font=f["base"])
        st.configure("Surface.TLabel", background=p["surface"])
        st.configure("Muted.TLabel", foreground=p["muted"])
        st.configure("Heading.TLabel", font=f["heading"])
        st.configure("Title.TLabel", font=f["title"], foreground=p["primary"])
        st.configure("TLabelframe", background=p["bg"], bordercolor=p["border"])
        st.configure("TLabelframe.Label", background=p["bg"], font=f["bold"], foreground=p["primary"])
        st.configure("TButton", font=f["base"], padding=(10, 4), background=p["surface"],
                     bordercolor=p["border"])
        st.map("TButton", background=[("active", p["select"]), ("disabled", p["bg"])])
        st.configure("Accent.TButton", font=f["heading"], padding=(12, 8), background=p["primary"],
                     foreground="white", bordercolor=p["primary_dark"])
        st.map("Accent.TButton", background=[("active", p["primary_dark"]), ("disabled", p["neutral"])],
               foreground=[("disabled", "white")])
        # compact controls for the Demonstration tab: small buttons leave the room to the schematic
        st.configure("Small.TButton", font=f["small"], padding=(8, 2), background=p["surface"], bordercolor=p["border"])
        st.map("Small.TButton", background=[("active", p["select"]), ("disabled", p["bg"])])
        st.configure("SmallAccent.TButton", font=f["small_bold"], padding=(12, 2), background=p["primary"],
                     foreground="white", bordercolor=p["primary_dark"])
        st.map("SmallAccent.TButton", background=[("active", p["primary_dark"]), ("disabled", p["neutral"])],
               foreground=[("disabled", "white")])
        st.configure("Small.TCheckbutton", background=p["bg"], font=f["small"])
        st.configure("Small.TLabel", font=f["small"])
        st.configure("SmallMuted.TLabel", font=f["small"], foreground=p["muted"])
        st.configure("SmallHeading.TLabel", font=f["small_bold"], foreground=p["primary"])
        st.configure("Stage.TButton", padding=(8, 4))
        st.configure("StageActive.TButton", padding=(8, 4), background=p["primary"], foreground="white",
                     font=f["bold"])
        st.map("StageActive.TButton", background=[("active", p["primary_dark"])])
        st.configure("TNotebook", background=p["bg"], borderwidth=0, tabmargins=(0, 4, 0, 0))
        st.configure("TNotebook.Tab", padding=(12, 6), font=f["base"], background=p["border"])
        st.map("TNotebook.Tab", background=[("selected", p["surface"])],
               foreground=[("selected", p["primary"])])
        st.configure("Treeview", font=f["base"], rowheight=row, background=p["surface"],
                     fieldbackground=p["surface"], bordercolor=p["border"])
        st.configure("Treeview.Heading", font=f["bold"], padding=(6, 6), background=p["select"])
        st.map("Treeview", background=[("selected", p["primary"])], foreground=[("selected", "white")])
        st.configure("TCheckbutton", background=p["bg"], font=f["base"])
        st.configure("TRadiobutton", background=p["bg"], font=f["base"])
        st.configure("TCombobox", padding=6, font=f["base"])
        st.configure("Horizontal.TProgressbar", background=p["primary"], troughcolor=p["border"])
        st.configure("TEntry", padding=5)
        st.configure("TSpinbox", padding=5)
