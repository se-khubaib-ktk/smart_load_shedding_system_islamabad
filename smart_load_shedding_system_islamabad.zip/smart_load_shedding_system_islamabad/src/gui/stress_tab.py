"""Tab 5 - Stress test: worst case in plain English, resilience score, pruning chart."""
import tkinter as tk
from tkinter import ttk

from . import figures, viewmodel as vm
from .glossary import GLOSSARY
from .map_view import MapView
from .tab_base import TabBase, read_only_text, set_text
from .theme import PALETTE
from .widgets import FigureFrame, help_icon


class StressTab(TabBase):
    def __init__(self, parent, theme, grid):
        super().__init__(parent, theme, grid)
        self.columnconfigure(0, weight=2, uniform="s")
        self.columnconfigure(1, weight=3, uniform="s")
        self.rowconfigure(0, weight=1)

        left = ttk.Frame(self)
        left.grid(row=0, column=0, sticky="nsew", padx=(0, 10))
        left.columnconfigure(0, weight=1)
        left.rowconfigure(3, weight=1)
        top = ttk.Frame(left)
        top.grid(row=0, column=0, sticky="ew")
        ttk.Label(top, text="Resilience score", style="Heading.TLabel").pack(side="left")
        help_icon(top, GLOSSARY["resilience"], theme, PALETTE["bg"]).pack(side="left", padx=8)
        self.score = tk.Label(left, text="-", font=theme.fonts["card_value"], anchor="w", bg=PALETTE["bg"])
        self.score.grid(row=1, column=0, sticky="w")
        ttk.Label(left, text="The worst case, step by step", style="Heading.TLabel").grid(row=2, column=0, sticky="w", pady=(10, 4))
        self.story = read_only_text(left, theme, height=10)
        self.story.grid(row=3, column=0, sticky="nsew")
        self.summary = ttk.Label(left, text="", wraplength=420, justify="left", style="Muted.TLabel")
        self.summary.grid(row=4, column=0, sticky="ew", pady=(8, 0))

        right = ttk.Frame(self)
        right.grid(row=0, column=1, sticky="nsew")
        right.columnconfigure(0, weight=1)
        right.rowconfigure(1, weight=1)
        right.rowconfigure(2, weight=2)
        head = ttk.Frame(right)
        head.grid(row=0, column=0, sticky="ew")
        ttk.Label(head, text="Alpha-beta pruning: same answer, less searching", style="Heading.TLabel").pack(side="left")
        help_icon(head, GLOSSARY["alpha_beta"], theme, PALETTE["bg"]).pack(side="left", padx=8)
        self.chart = FigureFrame(right)
        self.chart.grid(row=1, column=0, sticky="nsew")
        self.map = MapView(right, theme, toolbar=False)
        self.map.grid(row=2, column=0, sticky="nsew", pady=(8, 0))

    def redraw(self):
        if not self.analysis:
            return
        a = self.analysis
        value = a.result.stress.resilience * 100
        tone = "good" if value >= 70 else ("warn" if value >= 40 else "bad")
        self.score.configure(text=f"{value:.0f}%", fg=PALETTE[tone])
        steps = vm.stress_sentences(self.grid_model, a)
        set_text(self.story, "\n".join(f"{i}. {s}" for i, s in enumerate(steps, 1)) or "No further failure can hurt.")
        self.summary.configure(text=vm.stress_summary(self.grid_model, a))
        self.chart.show(figures.stress_figure(a, self.theme.scale))
        self.map.render(self.grid_model, a, stage="stress")

    def current_figure(self):
        return self.chart.figure
