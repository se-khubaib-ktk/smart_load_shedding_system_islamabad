"""Tab 2 - Fault detection and restoration: every zone with its status, source and route."""
import tkinter as tk
from tkinter import ttk

from . import viewmodel as vm
from .map_view import MapView
from .tab_base import TabBase
from .theme import PALETTE
from .widgets import DataTable

COLUMNS = [("zone", "Zone", 170, "w"), ("mw", "MW", 45, "e"), ("status", "Status", 140, "w"),
           ("source", "Source", 110, "w"), ("route", "Route (source to zone)", 230, "w"),
           ("switches", "Switches", 80, "w")]


class RestorationTab(TabBase):
    def __init__(self, parent, theme, grid):
        super().__init__(parent, theme, grid)
        self.rows = {}
        self.focus = None
        self._syncing = False
        self.columnconfigure(0, weight=1)
        self.rowconfigure(1, weight=1)
        self.summary = ttk.Label(self, text="", style="Heading.TLabel", wraplength=1000, justify="left")
        self.summary.grid(row=0, column=0, sticky="ew", pady=(0, 8))
        panes = ttk.PanedWindow(self, orient="horizontal")
        panes.grid(row=1, column=0, sticky="nsew")

        left = ttk.Frame(panes)
        left.columnconfigure(0, weight=1)
        left.rowconfigure(0, weight=1)
        self.table = DataTable(left, COLUMNS, height=12, on_select=self._on_row)
        self.table.grid(row=0, column=0, sticky="nsew")
        self.detail = tk.Label(left, text="Select a zone to see its route on the map.", anchor="w",
                               justify="left", bg=PALETTE["surface"], font=theme.fonts["base"], padx=10,
                               pady=8, relief="solid", borderwidth=1, wraplength=700)
        self.detail.grid(row=1, column=0, sticky="ew", pady=(8, 0))
        panes.add(left, weight=1)

        self.map = MapView(panes, theme, on_select_node=self._on_map_click, toolbar=False)
        panes.add(self.map, weight=1)

    def redraw(self):
        if not self.analysis:
            return
        self.focus = None
        rows = vm.zone_rows(self.grid_model, self.analysis)
        self.rows = {r["id"]: r for r in rows}
        self.summary.configure(text=vm.restoration_summary(self.grid_model, self.analysis))
        self.table.set_rows(rows, tag_key="status_key", id_key="id")
        self.detail.configure(text="Select a zone to see its route on the map.")
        self.map.render(self.grid_model, self.analysis, stage="restore")

    def _on_row(self, zone_id: str):
        if self._syncing or not zone_id or not self.analysis:
            return
        self.focus = zone_id
        row = self.rows[zone_id]
        self.detail.configure(text=f"{row['name']} ({row['type']}, {row['mw']} MW): {row['note']}.   Route: {row['route']}")
        self.map.render(self.grid_model, self.analysis, stage="restore", focus_zone=zone_id)

    def _on_map_click(self, node_id: str):
        # redraw after the click handler has finished (the old canvas is replaced)
        self.after(30, lambda: self._select_zone(node_id))

    def _select_zone(self, node_id: str):
        if node_id in self.rows:
            self._syncing = True
            self.table.tree.selection_set(node_id)
            self.table.tree.see(node_id)
            self._syncing = False
            self._on_row(node_id)

    def current_figure(self):
        return self.map.figure()
