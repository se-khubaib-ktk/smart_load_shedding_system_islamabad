"""Turns an Analysis into plain data (cards, table rows, sentences) for the screens.

No tkinter and no matplotlib here, so everything can be unit-tested without a display.
"""
from dataclasses import dataclass
from typing import Dict, List, Optional

from .. import config
from ..utils.map_drawing import STATUS_TEXT, short_name, zone_status
from .glossary import STAGE_TITLES

PRIORITY_LABEL = {1: "Hospital", 2: "Industrial", 3: "Market", 4: "Residential"}


@dataclass
class CardData:
    key: str
    title: str
    value: str
    detail: str
    tone: str            # good | warn | bad | neutral
    help_key: str


def fmt_minutes(minutes: float) -> str:
    if minutes <= 0:
        return "none needed"
    hours, mins = divmod(int(round(minutes)), 60)
    return f"{hours} h {mins:02d} min" if hours else f"{mins} min"


def fmt_short(minutes: float) -> str:
    """Compact form for the dashboard cards: '3h 04m'."""
    if minutes <= 0:
        return "none"
    hours, mins = divmod(int(round(minutes)), 60)
    return f"{hours}h {mins:02d}m" if hours else f"{mins}m"


def name_of(grid, node_id: str) -> str:
    return short_name(grid.nodes[node_id].name)


def names_of(grid, ids) -> str:
    return ", ".join(name_of(grid, i) for i in ids) or "none"


# ---- overview cards ----------------------------------------------------------
def build_cards(grid, analysis) -> List[CardData]:
    result = analysis.result
    plan, shed = result.restoration, result.shedding
    total = grid.total_demand()
    served = plan.served_mw(grid)
    pct = served / total * 100 if total else 100.0
    tone = lambda good, warn, value: "good" if value >= good else ("warn" if value >= warn else "bad")

    n_shed, n_iso = len(plan.capacity_short), len(plan.isolated)
    makespan = result.dispatch.makespan if result.dispatch else 0.0
    if shed.sa_metrics:
        jain = shed.sa_metrics.jain_fairness
        fairness = CardData("fairness", "Fairness", f"{jain:.2f}",
                            "1.00 = cuts shared perfectly evenly", tone(0.9, 0.75, jain), "jain")
    else:
        fairness = CardData("fairness", "Fairness", "n/a",
                            "no rotating cuts were needed", "neutral", "jain")
    resilience = result.stress.resilience * 100
    return [
        CardData("supplied", "Supplied", f"{pct:.0f}%",
                 f"{served:.0f} of {total:.0f} MW", tone(95, 70, pct), "supplied"),
        CardData("shed", "Load-shed", str(n_shed),
                 names_of(grid, plan.capacity_short) if n_shed else "none",
                 "good" if n_shed == 0 else "warn", "shed"),
        CardData("isolated", "Isolated", str(n_iso),
                 names_of(grid, plan.isolated) if n_iso else "none",
                 "good" if n_iso == 0 else "bad", "isolated"),
        CardData("repair", "Repair time", fmt_short(makespan),
                 f"{len(result.dispatch.faults)} fault(s), {len(result.dispatch.crews)} crews"
                 if result.dispatch else "no physical faults", "neutral", "repair"),
        fairness,
        CardData("resilience", "Resilience", f"{resilience:.0f}%",
                 "survives the worst 2 further failures", tone(70, 40, resilience), "resilience"),
    ]


# ---- restoration table ---------------------------------------------------------
def zone_rows(grid, analysis) -> List[Dict[str, str]]:
    """One row per zone, most important first."""
    plan = analysis.result.restoration
    rows = []
    for zone in sorted(grid.zones, key=lambda z: (z.priority, int(z.id[1:]))):
        status = zone_status(analysis.result, zone.id)
        route = plan.loads.routes.get(zone.id)
        if route:
            path = " > ".join(name_of(grid, n) for n in reversed(route.nodes))
            source = name_of(grid, route.source)
            switches = ", ".join(l for l in route.lines if grid.lines[l].normally_open) or "-"
            if status == "normal":
                note = "unchanged"
        else:
            path = source = switches = "-"
        if zone.id in plan.isolated:
            note = "no working path - waits for a repair crew"
        elif zone.id in plan.capacity_short:
            note = "reachable, but sources are full - rotating cuts"
        elif status == "rerouted":
            note = f"{route.hops} line(s) from its source"
        else:
            note = "normal feed"
        rows.append({"id": zone.id, "name": zone.name, "zone": f"{zone.id}  {name_of(grid, zone.id)}", "type": PRIORITY_LABEL[zone.priority],
                     "mw": f"{zone.demand_mw:.0f}", "status": STATUS_TEXT[status],
                     "status_key": status, "source": source, "route": path,
                     "switches": switches, "note": note})
    return rows


def restoration_summary(grid, analysis) -> str:
    plan = analysis.result.restoration
    closed = ", ".join(plan.switch_ops) or "none"
    return (f"Switches to close: {closed}.   Re-routed zones: {len(plan.restored)}.   "
            f"Load-shed: {len(plan.capacity_short)}.   Isolated: {len(plan.isolated)}.")


# ---- crews -----------------------------------------------------------------------
def crew_rows(grid, analysis) -> List[Dict[str, str]]:
    dispatch = analysis.result.dispatch
    rows = []
    if not dispatch:
        return rows
    for crew, (depot, visits) in enumerate(zip(dispatch.crews, dispatch.visits), 1):
        for number, v in enumerate(visits, 1):
            rows.append({"crew": f"Crew {crew}", "depot": name_of(grid, depot), "stop": str(number),
                         "job": f"{v.fault.kind}: {v.fault.component} at {name_of(grid, v.fault.site)}",
                         "travel": fmt_minutes(v.travel_min), "arrive": fmt_minutes(v.arrive),
                         "repair": fmt_minutes(v.fault.repair_min), "done": fmt_minutes(v.finish)})
    return rows


def crew_comparison(analysis) -> Optional[Dict[str, float]]:
    """Weighted waiting cost of the GA plan versus the simple orders (lower is better)."""
    dispatch = analysis.result.dispatch
    if not dispatch:
        return None
    data = {"Genetic Algorithm": dispatch.cost}
    names = {"nearest-first": "Nearest-first", "heaviest-first": "Heaviest-first",
             "random order": "Random order"}
    for key, label in names.items():
        data[label] = dispatch.baselines[key]
    return data


# ---- load-shedding --------------------------------------------------------------------
def shedding_rows(grid, analysis) -> List[Dict[str, str]]:
    plan = analysis.result.shedding
    rows = []
    for zone_id in plan.pool:
        before = plan.csp_metrics.shed_hours.get(zone_id, 0) if plan.csp_metrics else 0
        after = plan.sa_metrics.shed_hours.get(zone_id, 0) if plan.sa_metrics else 0
        rows.append({"zone": name_of(grid, zone_id), "csp": f"{before} h", "sa": f"{after} h"})
    return rows


def shedding_metric_rows(analysis) -> List[Dict[str, str]]:
    plan = analysis.result.shedding
    if not (plan.csp_metrics and plan.sa_metrics):
        return []
    a, b = plan.csp_metrics, plan.sa_metrics
    return [
        {"metric": "Fairness (Jain index)", "before": f"{a.jain_fairness:.3f}", "after": f"{b.jain_fairness:.3f}"},
        {"metric": "Breaker operations", "before": str(a.breaker_operations), "after": str(b.breaker_operations)},
        {"metric": "Energy not served (MWh)", "before": f"{a.unmet_mwh:.1f}", "after": f"{b.unmet_mwh:.1f}"},
        {"metric": "Longest cut in a row (h)", "before": str(a.max_consecutive_hours), "after": str(b.max_consecutive_hours)},
    ]


def shedding_note(grid, analysis) -> str:
    plan = analysis.result.shedding
    if not plan.csp_schedule:
        return plan.message or "No rotating cuts are needed in this case."
    text = (f"Deficit to cover: {plan.deficit_mw:.0f} MW, shared between {len(plan.pool)} zones "
            f"(hospitals are never cut).")
    if plan.exempt:
        text += f" Too large to rotate: {names_of(grid, plan.exempt)}."
    return text


# ---- stress test -------------------------------------------------------------------------
def _describe(grid, ident: str) -> str:
    if ident in grid.nodes:
        return f"the {name_of(grid, ident)} ({grid.nodes[ident].type})"
    if ident in grid.lines:
        line = grid.lines[ident]
        return f"line {ident} ({name_of(grid, line.a)} - {name_of(grid, line.b)})"
    return ident


def stress_sentences(grid, analysis) -> List[str]:
    """The worst-case sequence as numbered plain-English steps."""
    out = []
    for action, ident in analysis.result.stress.line:
        if action == "fail":
            out.append(f"The adversary breaks {_describe(grid, ident)}.")
        elif action == "close":
            out.append(f"The planner answers by closing tie switch {_describe(grid, ident)}.")
        else:
            out.append("The planner has no useful switch left to close and holds.")
    return out


def stress_summary(grid, analysis) -> str:
    st = analysis.result.stress
    now = st.current_value / st.total_weighted * 100 if st.total_weighted else 0
    worst = st.worst_value / st.total_weighted * 100 if st.total_weighted else 0
    return (f"Right now {now:.0f}% of the priority-weighted load is unserved in the simplified stress model "
            f"(line limits and rotating cuts not modelled). In the worst case it would rise to {worst:.0f}%. Resilience score: {st.resilience * 100:.0f}%.")


def stress_search_numbers(analysis):
    """(states with alpha-beta, states without, branches pruned) for the bar chart."""
    cmp = analysis.stress_compare
    with_ab = cmp.stats.nodes
    without = cmp.unpruned_stats.nodes if cmp.unpruned_stats else with_ab
    return with_ab, without, cmp.stats.pruned


# ---- hover / click ---------------------------------------------------------------------------
def node_info(grid, analysis, node_id: str) -> str:
    node = grid.nodes[node_id]
    state = analysis.scenario.state
    lines = [node.name, f"ID {node.id}  |  {node.type}"]
    if node.type == "zone":
        status = zone_status(analysis.result, node.id)
        lines.append(f"Demand {node.demand_mw:.0f} MW  |  priority {node.priority} "
                     f"({PRIORITY_LABEL[node.priority]})")
        lines.append(f"Status: {STATUS_TEXT[status]}")
    elif node.type == "source":
        cap = state.capacity_of(grid, node.id)
        lines.append(f"Capacity {cap:.0f} of {node.capacity_mw:.0f} MW available")
        lines.append(f"Load {analysis.result.restoration.loads.source_load.get(node.id, 0):.0f} MW")
    elif node.type == "transformer":
        lines.append("FAILED" if node.id in state.failed_nodes else "In service")
    return "\n".join(lines)


# ---- step-through captions ---------------------------------------------------------------------
def stage_caption(grid, analysis, stage: Optional[str]) -> str:
    result = analysis.result
    plan, shed = result.restoration, result.shedding
    rep = plan.report
    if stage is None:
        return ("All stages shown. Use the buttons above to step through the pipeline "
                "one stage at a time.")
    if stage == "detect":
        return (f"DETECT - a depth-first search from the working grid stations found "
                f"{len(rep.energized)} energised nodes. Cut off by faults: {names_of(grid, rep.dark_zones)}. "
                f"Dropped because a grid station is limited: {names_of(grid, rep.overload_zones)}.")
    if stage == "restore":
        return (f"RESTORE - uniform cost search re-routed {len(plan.restored)} zone(s), closing "
                f"{', '.join(plan.switch_ops) or 'no switches'}. Hospitals were served first. "
                f"{len(plan.capacity_short)} zone(s) still lack capacity and {len(plan.isolated)} are isolated.")
    if stage == "dispatch":
        d = result.dispatch
        if not d:
            return "DISPATCH - there are no physical faults, so no repair crew is needed."
        return (f"DISPATCH - A* found road travel times and a genetic algorithm ordered the "
                f"{len(d.faults)} repair job(s) for {len(d.crews)} crews. Everything is repaired "
                f"after {fmt_minutes(d.makespan)}.")
    if stage == "shed":
        if not shed.csp_schedule:
            return "SHED - " + (shed.message or "no rotating cuts are needed.")
        return (f"SHED - the CSP solver built a 24-hour timetable to cover {shed.deficit_mw:.0f} MW; "
                f"simulated annealing then changed fairness from {shed.csp_metrics.jain_fairness:.2f} to "
                f"{shed.sa_metrics.jain_fairness:.2f} and breaker operations from "
                f"{shed.csp_metrics.breaker_operations} to {shed.sa_metrics.breaker_operations}.")
    if stage == "stress":
        return "STRESS TEST - " + " ".join(stress_sentences(grid, analysis)) + " " + stress_summary(grid, analysis)
    return STAGE_TITLES.get(stage, "")


# ---- benchmark rows -> chart data -----------------------------------------------------------------
def parse_benchmark(rows, scenario_names: List[str]) -> Dict[str, dict]:
    """Group the benchmark CSV rows by test."""
    label = {name: f"S{i}" for i, name in enumerate(scenario_names, 1)}
    path, crew, shedding, minimax = {}, {}, {}, {}
    for test, algorithm, metric, value in rows:
        if test == "path search":
            path.setdefault(algorithm, {})[metric] = value
        elif test == "crew ordering":
            crew[algorithm] = value
        elif test in ("shedding", "minimax"):
            method, name = algorithm.split(" / ", 1)
            target = shedding if test == "shedding" else minimax
            target.setdefault(label.get(name, name), {})[f"{method}|{metric}"] = value
    return {"path": path, "crew": crew, "shedding": shedding, "minimax": minimax,
            "labels": {v: k for k, v in label.items()}}


def benchmark_tables(parsed: Dict[str, dict]) -> Dict[str, dict]:
    """(columns, rows) per sub-tab, ready for a table widget."""
    tables = {}
    tables["Path search"] = (["Algorithm", "Avg nodes expanded", "Avg travel (min)"],
        [[a, f"{m['avg nodes expanded']:.1f}", f"{m['avg travel minutes']:.1f}"] for a, m in parsed["path"].items()])
    tables["Crew ordering"] = (["Method", "Avg weighted cost (lower is better)"],
        [[k, f"{v:,.0f}"] for k, v in parsed["crew"].items()])
    tables["Load-shedding"] = (["Scenario", "Jain CSP", "Jain CSP+SA", "Ops CSP", "Ops CSP+SA"],
        [[s, f"{d['CSP|jain']:.3f}", f"{d['CSP+SA|jain']:.3f}", d["CSP|breaker ops"], d["CSP+SA|breaker ops"]]
         for s, d in parsed["shedding"].items()])
    tables["Minimax pruning"] = (["Scenario", "States (plain)", "States (alpha-beta)", "Saved"],
        [[s, d["plain|nodes"], d["alpha-beta|nodes"],
          f"{(1 - d['alpha-beta|nodes'] / d['plain|nodes']) * 100:.0f}%"] for s, d in parsed["minimax"].items()])
    return tables
