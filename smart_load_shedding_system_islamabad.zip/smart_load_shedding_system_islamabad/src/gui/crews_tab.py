"""Tab 3 - Repair crews: timeline, job table, GA versus simple orders, GA convergence."""
from tkinter import ttk

from . import figures, viewmodel as vm
from .glossary import GLOSSARY
from .tab_base import TabBase
from .widgets import DataTable, FigureFrame, help_icon

COLUMNS = [("crew", "Crew", 60, "w"), ("job", "Job", 250, "w"), ("travel", "Travel", 80, "e"),
           ("arrive", "Arrives", 80, "e"), ("repair", "Repair", 80, "e"), ("done", "Done at", 80, "e")]


class CrewsTab(TabBase):
    def __init__(self, parent, theme, grid):
        super().__init__(parent, theme, grid)
        self.columnconfigure(0, weight=3)
        self.columnconfigure(1, weight=2)
        self.rowconfigure(1, weight=1)
        head = ttk.Frame(self)
        head.grid(row=0, column=0, columnspan=2, sticky="ew", pady=(0, 6))
        self.title = ttk.Label(head, text="", style="Heading.TLabel")
        self.title.pack(side="left")
        help_icon(head, GLOSSARY["weighted_cost"], theme, "#f3f5f8").pack(side="left", padx=8)

        left = ttk.Frame(self)
        left.grid(row=1, column=0, sticky="nsew", padx=(0, 8))
        left.columnconfigure(0, weight=1)
        left.rowconfigure(0, weight=3)
        left.rowconfigure(1, weight=2)
        self.gantt = FigureFrame(left)
        self.gantt.grid(row=0, column=0, sticky="nsew")
        self.table = DataTable(left, COLUMNS, height=6)
        self.table.grid(row=1, column=0, sticky="nsew", pady=(8, 0))

        right = ttk.Frame(self)
        right.grid(row=1, column=1, sticky="nsew")
        right.columnconfigure(0, weight=1)
        right.rowconfigure(0, weight=1)
        right.rowconfigure(1, weight=1)
        self.compare = FigureFrame(right)
        self.compare.grid(row=0, column=0, sticky="nsew")
        self.converge = FigureFrame(right)
        self.converge.grid(row=1, column=0, sticky="nsew", pady=(8, 0))

    def redraw(self):
        if not self.analysis:
            return
        a, scale = self.analysis, self.theme.scale
        d = a.result.dispatch
        self.title.configure(text=(f"{len(d.faults)} repair job(s), {len(d.crews)} crews - all repaired after "
                                   f"{vm.fmt_minutes(d.makespan)}") if d else "No physical faults - no crews needed")
        self.gantt.show(figures.gantt_figure(self.grid_model, a, scale))
        self.table.set_rows(vm.crew_rows(self.grid_model, a))
        self.compare.show(figures.crew_comparison_figure(a, scale))
        self.converge.show(figures.convergence_figure(a, scale))

    def current_figure(self):
        return self.gantt.figure
