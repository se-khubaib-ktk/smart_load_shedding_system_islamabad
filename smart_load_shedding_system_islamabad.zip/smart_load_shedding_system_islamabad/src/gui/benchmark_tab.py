"""Tab 7 - Benchmark: run the algorithm comparison and show tables and charts."""
import tkinter as tk
from tkinter import ttk

from . import figures, viewmodel as vm
from .tab_base import TabBase, read_only_text, set_text
from .widgets import DataTable, FigureFrame


class BenchmarkTab(TabBase):
    def __init__(self, parent, theme, grid, on_run):
        super().__init__(parent, theme, grid)
        self.data = None
        self.parsed = None
        self.columnconfigure(0, weight=1)
        self.rowconfigure(1, weight=1)
        bar = ttk.Frame(self)
        bar.grid(row=0, column=0, sticky="ew", pady=(0, 8))
        self.button = ttk.Button(bar, text="Run benchmark", style="Accent.TButton", command=on_run)
        self.button.pack(side="left")
        self.progress = ttk.Progressbar(bar, mode="indeterminate", length=160)
        self.progress.pack(side="left", padx=12)
        self.label = ttk.Label(bar, text="Compares the algorithms on this network (takes a few seconds).",
                               style="Muted.TLabel")
        self.label.pack(side="left")
        self.book = ttk.Notebook(self)
        self.book.grid(row=1, column=0, sticky="nsew")
        self.pages = {}
        self.figure_frames = {}
        placeholder = ttk.Label(self.book, text="Press 'Run benchmark' to fill this page.", style="Muted.TLabel",
                                padding=20)
        self.book.add(placeholder, text="Results")

    def set_busy(self, busy: bool):
        self.button.configure(state="disabled" if busy else "normal")
        if busy:
            self.progress.start(12)
            self.label.configure(text="Running the benchmark...")
        else:
            self.progress.stop()

    def show_results(self, data):
        self.data = data
        self.parsed = vm.parse_benchmark(data.rows, data.scenario_names)
        self.label.configure(text=f"Finished in {data.seconds:.1f} s. S1-S5 are the five scenarios; "
                                  f"results were also saved to outputs/benchmark.csv.")
        self.redraw()

    def redraw(self):
        if not self.parsed:
            return
        for tab in self.book.tabs():
            self.book.forget(tab)
        tables = vm.benchmark_tables(self.parsed)
        figs = figures.benchmark_figures(self.parsed, self.theme.scale)
        self.figure_frames = {}
        for title, (headings, rows) in tables.items():
            page = ttk.Frame(self.book, padding=8)
            page.columnconfigure(0, weight=2, uniform="b")
            page.columnconfigure(1, weight=3, uniform="b")
            page.rowconfigure(0, weight=1)
            columns = [(f"c{i}", h, 140 if i else 190, "w" if i == 0 else "e") for i, h in enumerate(headings)]
            table = DataTable(page, columns, height=8)
            table.grid(row=0, column=0, sticky="nsew", padx=(0, 8))
            table.set_rows([{f"c{i}": str(v) for i, v in enumerate(r)} for r in rows])
            frame = FigureFrame(page)
            frame.grid(row=0, column=1, sticky="nsew")
            frame.show(figs[title])
            self.figure_frames[title] = frame
            self.book.add(page, text=title)
        raw = ttk.Frame(self.book, padding=8)
        raw.columnconfigure(0, weight=1)
        raw.rowconfigure(0, weight=1)
        box = read_only_text(raw, self.theme, height=20)
        box.configure(font=self.theme.fonts["mono"])
        box.grid(row=0, column=0, sticky="nsew")
        set_text(box, self.data.text)
        self.book.add(raw, text="Full text output")

    def current_figure(self):
        if not self.figure_frames:
            return None
        current = self.book.index(self.book.select())
        frames = list(self.figure_frames.values())
        return frames[current].figure if current < len(frames) else None
