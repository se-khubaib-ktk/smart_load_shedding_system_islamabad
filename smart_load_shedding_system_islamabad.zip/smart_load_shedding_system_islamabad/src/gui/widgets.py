"""Small reusable widgets: tooltip, help icon, statistic card, table, figure holder."""
import tkinter as tk
from tkinter import ttk
from typing import Callable, Dict, List, Optional, Sequence

from .theme import PALETTE


class Tooltip:
    """Plain-language help that appears when the pointer rests on a widget."""

    def __init__(self, widget: tk.Misc, text: str, theme, delay: int = 400, wrap: int = 380):
        self.widget, self.text, self.theme = widget, text, theme
        self.delay, self.wrap = delay, wrap
        self._job = None
        self._tip: Optional[tk.Toplevel] = None
        widget.bind("<Enter>", self._schedule, add="+")
        widget.bind("<Leave>", self._hide, add="+")
        widget.bind("<ButtonPress>", self._hide, add="+")

    def _schedule(self, _event=None):
        self._hide()
        if self.text:
            self._job = self.widget.after(self.delay, self._show)

    def _show(self):
        if self._tip or not self.text:
            return
        x = self.widget.winfo_rootx() + 14
        y = self.widget.winfo_rooty() + self.widget.winfo_height() + 6
        self._tip = tk.Toplevel(self.widget)
        self._tip.wm_overrideredirect(True)
        self._tip.wm_geometry(f"+{x}+{y}")
        tk.Label(self._tip, text=self.text, justify="left", wraplength=self.wrap, padx=10, pady=8,
                 bg=PALETTE["tip"], fg=PALETTE["text"], relief="solid", borderwidth=1,
                 font=self.theme.fonts["base"]).pack()

    def _hide(self, _event=None):
        if self._job:
            self.widget.after_cancel(self._job)
            self._job = None
        if self._tip:
            self._tip.destroy()
            self._tip = None


def help_icon(parent: tk.Misc, text: str, theme, bg: str = PALETTE["surface"]) -> tk.Label:
    """A small round '?' that explains a technical term when hovered."""
    icon = tk.Label(parent, text="?", bg=PALETTE["primary"], fg="white", font=theme.fonts["bold"],
                    width=2, cursor="question_arrow")
    Tooltip(icon, text, theme)
    return icon


class StatCard(tk.Frame):
    """A dashboard card: title, big value, one line of detail, coloured top stripe."""

    def __init__(self, parent, theme, title: str, help_text: str = ""):
        super().__init__(parent, bg=PALETTE["surface"], highlightbackground=PALETTE["border"],
                         highlightthickness=1)
        self.theme = theme
        self.stripe = tk.Frame(self, height=4, bg=PALETTE["neutral"])
        self.stripe.pack(fill="x")
        head = tk.Frame(self, bg=PALETTE["surface"])
        head.pack(fill="x", padx=10, pady=(4, 0))
        tk.Label(head, text=title, bg=PALETTE["surface"], fg=PALETTE["muted"],
                 font=theme.fonts["bold"]).pack(side="left")
        if help_text:
            help_icon(head, help_text, theme).pack(side="right")
        self.value = tk.Label(self, text="-", bg=PALETTE["surface"], fg=PALETTE["text"],
                              font=theme.fonts["card_value"], anchor="w")
        self.value.pack(fill="x", padx=10)
        self.detail = tk.Label(self, text="", bg=PALETTE["surface"], fg=PALETTE["muted"],
                               font=theme.fonts["base"], anchor="w", justify="left", wraplength=170)
        self.detail.pack(fill="x", padx=10, pady=(0, 6))
        self.bind("<Configure>", lambda e: self.detail.configure(wraplength=max(100, e.width - 28)))

    def set(self, value: str, detail: str, tone: str) -> None:
        self.value.configure(text=value)
        self.detail.configure(text=detail)
        self.stripe.configure(bg=PALETTE.get(tone, PALETTE["neutral"]))


class DataTable(ttk.Frame):
    """A ttk.Treeview with a scrollbar, zebra stripes and row colours by tag."""

    def __init__(self, parent, columns: Sequence[tuple], height: int = 8,
                 on_select: Optional[Callable[[str], None]] = None):
        """columns = [(key, heading, width_px, anchor), ...]"""
        super().__init__(parent)
        self.keys = [c[0] for c in columns]
        self.tree = ttk.Treeview(self, columns=self.keys, show="headings", height=height,
                                 selectmode="browse")
        for key, heading, width, anchor in columns:
            self.tree.heading(key, text=heading)
            self.tree.column(key, width=width, anchor=anchor, stretch=True)
        bar = ttk.Scrollbar(self, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=bar.set)
        self.tree.grid(row=0, column=0, sticky="nsew")
        bar.grid(row=0, column=1, sticky="ns")
        self.columnconfigure(0, weight=1)
        self.rowconfigure(0, weight=1)
        self.tree.tag_configure("odd", background=PALETTE["stripe"])
        for tag, colour in (("normal", "#e3f1e8"), ("rerouted", "#dce9f9"),
                            ("shed", "#fbebcf"), ("dark", "#f7dcdc")):
            self.tree.tag_configure(tag, background=colour)
        if on_select:
            self.tree.bind("<<TreeviewSelect>>", lambda _e: on_select(self.selected() or ""))

    def set_rows(self, rows: List[Dict[str, str]], tag_key: Optional[str] = None,
                 id_key: Optional[str] = None) -> None:
        self.tree.delete(*self.tree.get_children())
        for index, row in enumerate(rows):
            tags = [row[tag_key]] if tag_key else (["odd"] if index % 2 else [])
            iid = row[id_key] if id_key else str(index)
            self.tree.insert("", "end", iid=iid, values=[row.get(k, "") for k in self.keys], tags=tags)

    def selected(self) -> Optional[str]:
        chosen = self.tree.selection()
        return chosen[0] if chosen else None


class FigureFrame(ttk.Frame):
    """Holds one matplotlib Figure in a Tk canvas (replaced whenever show() is called)."""

    def __init__(self, parent, toolbar: bool = False):
        super().__init__(parent)
        self.use_toolbar = toolbar
        self.canvas = None
        self.toolbar = None
        self.figure = None

    def show(self, fig):
        # imported here so that the rest of the GUI package works without a Tk backend
        from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg, NavigationToolbar2Tk
        self.clear()
        self.figure = fig
        self.canvas = FigureCanvasTkAgg(fig, master=self)
        if self.use_toolbar:
            self.toolbar = NavigationToolbar2Tk(self.canvas, self, pack_toolbar=False)
            self.toolbar.update()
            self.toolbar.pack(side="bottom", fill="x")
        self.canvas.get_tk_widget().pack(side="top", fill="both", expand=True)
        self.canvas.draw_idle()
        return self.canvas

    def clear(self):
        # Replays replace figures frequently; cancel callbacks owned by the old canvas.
        if self.canvas is not None:
            widget = self.canvas.get_tk_widget()
            for attr in ('_idle_draw_id', '_event_loop_id'):
                job = getattr(self.canvas, attr, None)
                if job:
                    widget.after_cancel(job)
                    setattr(self.canvas, attr, None)
        for child in self.winfo_children():
            child.destroy()
        self.canvas = self.toolbar = self.figure = None


class ScrollFrame(ttk.Frame):
    """A vertically scrollable area; put children in `.inner`."""

    def __init__(self, parent, bg: str = PALETTE["bg"], width: int = 0):
        super().__init__(parent)
        self.canvas = tk.Canvas(self, bg=bg, highlightthickness=0, **({"width": width} if width else {}))
        bar = ttk.Scrollbar(self, orient="vertical", command=self.canvas.yview)
        self.canvas.configure(yscrollcommand=bar.set)
        bar.pack(side="right", fill="y")
        self.canvas.pack(side="left", fill="both", expand=True)
        self.inner = ttk.Frame(self.canvas)
        self._window = self.canvas.create_window((0, 0), window=self.inner, anchor="nw")
        self.inner.bind("<Configure>", lambda _e: self.canvas.configure(scrollregion=self.canvas.bbox("all")))
        self.canvas.bind("<Configure>", lambda e: self.canvas.itemconfigure(self._window, width=e.width))
        self.canvas.bind("<Enter>", self._bind_wheel)
        self.canvas.bind("<Leave>", self._unbind_wheel)

    def _bind_wheel(self, _event):
        self.canvas.bind_all("<MouseWheel>", self._on_wheel)
        self.canvas.bind_all("<Button-4>", lambda _e: self.canvas.yview_scroll(-2, "units"))
        self.canvas.bind_all("<Button-5>", lambda _e: self.canvas.yview_scroll(2, "units"))

    def _unbind_wheel(self, _event):
        for sequence in ("<MouseWheel>", "<Button-4>", "<Button-5>"):
            self.canvas.unbind_all(sequence)

    def _on_wheel(self, event):
        step = -1 if event.delta > 0 else 1
        self.canvas.yview_scroll(step * 2, "units")
