"""Deterministic decision replay. Frames own their state: Back never mutates a run."""
from copy import deepcopy
from dataclasses import dataclass, field
from ..models.state import GridState
from ..services.supply import SupplyLoads, assign_supply, route_zone
from ..services.crew_dispatch import TravelTimes
from ..algorithms.informed.astar import astar
from .. import config


@dataclass
class Frame:
    stage: str
    title: str
    explanation: str
    algorithm: str
    state: GridState
    loads: SupplyLoads
    focus: str = ''
    highlights: list = field(default_factory=list)
    visited: set = field(default_factory=set)
    cuts: set = field(default_factory=set)
    road_path: list = field(default_factory=list)
    mode: str = 'Allocated supply'


def build_trace(grid, analysis):
    result = analysis.result
    state = analysis.scenario.state.copy()
    frames = []
    def add(stage, title, explanation, algorithm, loads, **kw):
        frames.append(Frame(stage, title, explanation, algorithm,
                            deepcopy(kw.pop('state', state)), deepcopy(loads), **deepcopy(kw)))
    add('Baseline', 'Healthy network',
        'Start with the healthy reference network. Sources feed transformers and zones through normal feeders. '
        'Each card shows demand or allocated supply in MW. Backup ties are normally open.',
        'UCS · reference allocation', result.baseline, state=GridState())
    damaged = assign_supply(grid, state, allow_open=False)
    add('Detect', 'Apply the selected incident',
        analysis.scenario.description + ' Red crosses mark failed components. Amber zones have no allocation. '
        'Only normal closed feeders are available at this point.', 'Fault inputs', damaged)
    visited = set()
    for source in grid.sources:
        if state.capacity_of(grid, source.id) <= 0:
            continue
        stack = [source.id]
        while stack:
            node = stack.pop()
            if node in visited:
                continue
            visited.add(node)
            neighbors = []
            if grid.nodes[node].type != 'zone':
                for line in grid.lines_at[node]:
                    nxt = line.other(node)
                    if not line.normally_open and state.line_ok(line.id) and state.node_ok(nxt):
                        neighbors.append(nxt)
            stack.extend(n for n in neighbors if n not in visited)
            add('Detect', f'DFS visits {node}',
                f'Reachability check at {grid.nodes[node].name}. {len(visited)} nodes visited so far. '
                f'Frontier (next first): {", ".join(reversed(stack)) or "empty"}. '
                'A reachable node is not necessarily supplied: capacity is checked separately.',
                'Depth-first search · connectivity', damaged, focus=node, visited=visited,
                mode='Pre-restoration allocation')
    report = result.restoration.report
    for zone, hops in report.backup_hops.items():
        route = route_zone(grid, state, SupplyLoads(), zone, True, False, 'bfs')
        add('Detect', f'Backup check · {zone}',
            (f'BFS finds a {hops}-edge path to a working source. This minimizes edge count, not '
             'distance or the number of switches. Capacity is not checked in this diagnostic.'
             if route else 'BFS finds no backup path. A physical repair is needed.'),
            'Breadth-first search · diagnostic', damaged, focus=zone,
            highlights=route.lines if route else [], mode='Pre-restoration allocation')
    loads = SupplyLoads()
    affected = set(report.affected)
    order = sorted(grid.zones, key=lambda z: (z.priority, z.id in affected, -z.demand_mw))
    for z in order:
        route = route_zone(grid, state, loads, z.id, allow_open=True)
        if route:
            loads.add(grid, route)
            explanation = (f'Allocate {z.demand_mw:g} MW to {z.name} (priority {z.priority}). '
                f'Path: {" → ".join(reversed(route.nodes))}. Cost = {route.cost:.2f} km-equivalent '
                '(line length + penalty for each normally-open line). '
                f'Required backup closures: {", ".join(route.switches) or "none"}. '
                'Source and line residual capacities are checked before allocation.')
        else:
            reachable = route_zone(grid, state, loads, z.id, True, False)
            explanation = (f'{z.name}: ' + ('a path exists but residual capacity cannot carry the full demand.'
                if reachable else 'no healthy path to a working source exists.') +
                ' This greedy priority-order allocation is not a globally optimal power-flow solution.')
        add('Restore', f'UCS decision · {z.id}', explanation,
            'Uniform cost search · priority allocation', loads, focus=z.id,
            highlights=route.lines if route else [], mode='Allocation built so far')
    add('Restore', 'Restoration plan complete',
        f'{len(loads.routes)} of {len(grid.zones)} zones allocated. '
        f'Close ties: {", ".join(result.restoration.switch_ops) or "none"}. '
        'These are planned switching decisions; physical faults remain until repair.',
        'Capacity-constrained allocation', loads)
    d = result.dispatch
    if d:
        travel = TravelTimes(grid)
        for crew, (depot, visits) in enumerate(zip(d.crews, d.visits), 1):
            previous = depot
            for v in visits:
                path = astar(previous, v.fault.site, lambda n: grid.roads[n], travel._heuristic)
                add('Dispatch', f'Crew {crew} → {v.fault.component}',
                    f'Planned road path: {" → ".join(path.path)}. Travel {v.travel_min:.1f} min; '
                    f'arrive {v.arrive:.1f} min; finish {v.finish:.1f} min after incident. '
                    'Purple arrows are road travel, not electrical lines. GA selects job order to minimize '
                    'priority-weighted completion time. This is a dispatch plan, not a completed repair.',
                    'A* shortest travel + genetic job ordering', loads,
                    focus=v.fault.site, road_path=path.path)
                previous = v.fault.site
    else:
        add('Dispatch', 'No repair jobs', 'No physical line or node faults were entered. '
            'A source derating alone does not generate a repair job.', 'Dispatch skipped', loads)
    shed = result.shedding
    if shed.sa_schedule:
        add('Schedule', 'CSP → simulated annealing',
            f'CSP finds a timetable, then annealing searches feasible swaps. '
            f'Fairness: {shed.csp_metrics.jain_fairness:.3f} → {shed.sa_metrics.jain_fairness:.3f}; '
            f'breaker operations: {shed.csp_metrics.breaker_operations} → {shed.sa_metrics.breaker_operations}. '
            f'Consecutive limit used: {shed.consecutive_limit * config.HOURS_PER_SLOT} h; '
            f'cap relaxations: {shed.cap_relaxations}. This schedule covers aggregate MW; '
            'per-slot electrical routing is not validated.', 'CSP + simulated annealing', loads)
        for slot, cuts in enumerate(shed.sa_schedule):
            mw = sum(grid.nodes[z].demand_mw for z in cuts)
            add('Schedule', f'{slot*config.HOURS_PER_SLOT:02d}:00–{(slot+1)*config.HOURS_PER_SLOT:02d}:00 · planned cuts',
                f'Schedule cuts {", ".join(sorted(cuts)) or "none"}: {mw:g} MW against '
                f'{shed.deficit_mw:g} MW aggregate deficit. Hospitals are excluded from voluntary cuts. '
                'Hatched amber cards show planned cuts; electrical allocations remain the restoration '
                'reference, not a validated simulation of this time slot.',
                '24-hour schedule · aggregate feasibility only', loads, cuts=set(cuts),
                mode='Restoration reference / schedule overlay')
    else:
        add('Schedule', 'Schedule outcome', shed.message,
            'CSP · feasibility result', loads)
    hypothetical = state.copy()
    closed = set(result.restoration.switch_ops)
    for action, ident in result.stress.line:
        if action == 'fail':
            (hypothetical.failed_lines if ident in grid.lines else hypothetical.failed_nodes).add(ident)
        elif action == 'close':
            closed.add(ident)
        # Replay only the selected closures; no automatic extra restoration switches.
        stress_grid = deepcopy(grid)
        for lid in closed:
            stress_grid.lines[lid].normally_open = False
        stress_loads = assign_supply(stress_grid, hypothetical, allow_open=False)
        add('Stress', f'Hypothetical · {action} {ident}'.strip(),
            f'Minimax worst-case branch: {action} {ident or "(no additional switch)"}. '
            'This is a separate what-if branch, not an actual new fault. The displayed allocations '
            'are capacity-checked for this frame. The minimax score itself uses a simpler reachability '
            'and source-capacity approximation that ignores line limits.',
            'Minimax + alpha-beta · hypothetical branch', stress_loads,
            state=hypothetical, focus=ident, highlights=[ident] if ident in grid.lines else [],
            mode='Hypothetical allocation')
    add('Summary', 'Return to the actual plan',
        f'Actual scenario: {analysis.scenario.name}. Allocated '
        f'{result.restoration.served_mw(grid):g}/{grid.total_demand():g} MW. '
        f'{len(result.restoration.isolated)} isolated zones; '
        f'{len(result.restoration.capacity_short)} capacity-short zones. '
        'Open the Restore, Crews, Shedding and Benchmark tabs for supporting evidence. '
        'Replay is a decision explanation, not live grid control.', 'Decision support summary',
        result.restoration.loads)
    return frames
