"""Bottom status bar: current scenario, run time and seed."""
from tkinter import ttk


class StatusBar(ttk.Frame):
    def __init__(self, parent):
        super().__init__(parent, padding=(10, 5))
        self.scenario = ttk.Label(self, text="Scenario: -")
        self.runtime = ttk.Label(self, text="Run time: -")
        self.seed = ttk.Label(self, text="Seed: -")
        self.scenario.pack(side="left")
        ttk.Separator(self, orient="vertical").pack(side="left", fill="y", padx=14)
        self.runtime.pack(side="left")
        ttk.Separator(self, orient="vertical").pack(side="left", fill="y", padx=14)
        self.seed.pack(side="left")

    def show(self, analysis) -> None:
        self.scenario.configure(text=f"Scenario: {analysis.scenario.name}")
        self.runtime.configure(text=f"Run time: {analysis.seconds:.2f} s")
        self.seed.configure(text=f"Seed: {analysis.seed}")
