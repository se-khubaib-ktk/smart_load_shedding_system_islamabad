"""The main window: header, sidebar, tabs and status bar. Connects the controller to the views."""
import logging
import tkinter as tk
from pathlib import Path
from tkinter import filedialog, messagebox, ttk

from .. import config
from .benchmark_tab import BenchmarkTab
from .controller import AnalysisController
from .crews_tab import CrewsTab
from .howitworks_tab import HowItWorksTab
from .overview_tab import OverviewTab
from .demo_tab import DemoTab
from .restoration_tab import RestorationTab
from .shedding_tab import SheddingTab
from .sidebar import Sidebar
from .statusbar import StatusBar
from .stress_tab import StressTab
from .theme import PALETTE, PRESENTATION_SCALE, Theme

log = logging.getLogger("smart_grid_gui")
TAB_TITLES = ["1 Demonstration", "2 Restore", "3 Crews", "4 Shedding", "5 Stress test",
              "6 How it works", "7 Benchmark", "8 Geographic map"]


class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Smart Load-Shedding and Restoration System - Islamabad (IESCO area)")
        self.minsize(1000, 640)
        self.geometry("1400x840")
        try:
            self.state("zoomed")                      # start maximised on Windows
        except tk.TclError:
            pass
        self.theme = Theme(self)
        self.controller = AnalysisController(lambda ms, fn: self.after(ms, fn))
        self.grid_model = self.controller.grid
        self.analysis = None
        self.presentation = tk.BooleanVar(value=False)
        self.report_callback_exception = self._on_exception     # friendly dialog, no traceback

        self._build_header()
        self.status = StatusBar(self)
        self.status.pack(side="bottom", fill="x")
        ttk.Separator(self).pack(side="bottom", fill="x")
        self.sidebar = Sidebar(self, self.theme, self.controller, self.run_analysis, self.export_report)
        self.sidebar.pack(side="left", fill="y")
        self.notebook = ttk.Notebook(self)
        self.notebook.pack(side="left", fill="both", expand=True, padx=(0, 8), pady=(2, 4))

        g, t = self.grid_model, self.theme
        self.overview = DemoTab(self.notebook, t, g)
        self.geographic = OverviewTab(self.notebook, t, g)
        self.restoration = RestorationTab(self.notebook, t, g)
        self.crews = CrewsTab(self.notebook, t, g)
        self.shedding = SheddingTab(self.notebook, t, g)
        self.stress = StressTab(self.notebook, t, g)
        self.how = HowItWorksTab(self.notebook, t, g, goto=self.goto_tab)
        self.benchmark = BenchmarkTab(self.notebook, t, g, self.run_benchmark)
        self.tabs = [self.overview, self.restoration, self.crews, self.shedding, self.stress,
                     self.how, self.benchmark, self.geographic]
        for tab, title in zip(self.tabs, TAB_TITLES):
            self.notebook.add(tab, text=title)

        self.show_panel.set(False)
        self.toggle_panel()
        self.bind("<F5>", lambda _e: self.run_analysis())
        self.bind("<F11>", lambda _e: self.toggle_presentation(flip=True))
        self._startup_job = self.after(300, self.run_analysis)              # show something useful straight away

    # ---- layout ------------------------------------------------------------------
    def _build_header(self):
        header = ttk.Frame(self, padding=(12, 6, 12, 2))
        header.pack(side="top", fill="x")
        ttk.Label(header, text="GRID / IQ", style="Title.TLabel").pack(side="left")
        ttk.Label(header, text="   Islamabad · Load shedding & restoration lab",
                  style="Muted.TLabel").pack(side="left", pady=(6, 0))
        ttk.Checkbutton(header, text="Presentation mode (F11)", variable=self.presentation,
                        command=self.toggle_presentation).pack(side="right")
        self.show_panel = tk.BooleanVar(value=True)
        ttk.Checkbutton(header, text="Side panel", variable=self.show_panel,
                        command=self.toggle_panel).pack(side="right", padx=14)

    def toggle_panel(self):
        """Hide the sidebar to give the tabs the whole window."""
        if self.show_panel.get():
            self.sidebar.pack(side="left", fill="y", before=self.notebook)
        else:
            self.sidebar.pack_forget()

    def goto_tab(self, index: int):
        self.notebook.select(index)

    # ---- running ---------------------------------------------------------------------
    def run_analysis(self):
        if self.controller.busy:
            return
        try:
            seed = self.sidebar.get_seed()
        except ValueError as error:
            messagebox.showwarning("Check the random seed", str(error))
            return
        scenario = self.sidebar.build_scenario()
        self.sidebar.set_busy(True, f"Analysing: {scenario.name}")
        self.controller.run_async(scenario, seed, self._analysis_done, self._analysis_failed)

    def _analysis_done(self, analysis):
        self.sidebar.set_busy(False, f"Finished in {analysis.seconds:.2f} s.")
        self.show_analysis(analysis)

    def show_analysis(self, analysis):
        """Hand a finished analysis to every tab (also used directly by the smoke test)."""
        self.analysis = analysis
        for tab in self.tabs:
            if tab is self.benchmark:
                continue
            tab.update_view(analysis)
        self.status.show(analysis)

    def _analysis_failed(self, message: str):
        self.sidebar.set_busy(False, "The analysis could not be completed.")
        messagebox.showerror("Analysis not completed", message)

    def run_benchmark(self):
        if self.controller.busy:
            messagebox.showinfo("Please wait", "Another calculation is still running.")
            return
        try:
            seed = self.sidebar.get_seed()
        except ValueError:
            seed = config.DEFAULT_SEED
        self.benchmark.set_busy(True)
        self.sidebar.set_busy(True, "Running the benchmark...")
        self.controller.run_benchmark_async(self._benchmark_done, self._benchmark_failed, seed)

    def _benchmark_done(self, data):
        self.benchmark.set_busy(False)
        self.sidebar.set_busy(False, "Benchmark finished.")
        self.benchmark.show_results(data)

    def _benchmark_failed(self, message: str):
        self.benchmark.set_busy(False)
        self.sidebar.set_busy(False, "The benchmark could not be completed.")
        messagebox.showerror("Benchmark not completed", message)

    # ---- presentation mode ---------------------------------------------------------------
    def toggle_presentation(self, flip: bool = False):
        if flip:
            self.presentation.set(not self.presentation.get())
        on = self.presentation.get()
        self.theme.set_scale(PRESENTATION_SCALE if on else 1.0)
        self.sidebar.set_presentation(on)
        if self.analysis:
            for tab in self.tabs:
                tab.redraw()

    # ---- export --------------------------------------------------------------------------
    def export_report(self):
        if not self.analysis:
            messagebox.showinfo("Nothing to export", "Run an analysis first, then export its report.")
            return
        folder = filedialog.askdirectory(title="Choose a folder for the report")
        if not folder:
            return
        try:
            target = Path(folder)
            (target / "report.txt").write_text(self.controller.report_text(self.analysis), encoding="utf-8")
            saved = ["report.txt"]
            figure = self.overview.current_figure()
            if figure is not None:
                figure.savefig(target / "overview_map.png", dpi=150, bbox_inches="tight")
                saved.append("overview_map.png")
            current = self.tabs[self.notebook.index(self.notebook.select())]
            if current is not self.overview and current.current_figure() is not None:
                name = TAB_TITLES[self.tabs.index(current)][2:].strip().lower().replace(" ", "_")
                current.current_figure().savefig(target / f"{name}_figure.png", dpi=150, bbox_inches="tight")
                saved.append(f"{name}_figure.png")
        except OSError:
            messagebox.showerror("Could not save", "The files could not be saved in that folder. "
                                                   "Please choose a different folder.")
            return
        messagebox.showinfo("Export finished", "Saved in " + folder + ":\n" + "\n".join(saved))

    # ---- errors ----------------------------------------------------------------------------
    def _on_exception(self, exc, value, trace):
        log.error("unexpected GUI error", exc_info=(exc, value, trace))
        messagebox.showerror("Something went wrong",
                             "An unexpected problem occurred, but the program is still running. "
                             "Please try again or choose a different scenario.")


def main() -> None:
    logging.basicConfig(level=logging.WARNING)
    try:
        app = App()
    except tk.TclError as error:
        raise SystemExit(f"The window could not be opened (is a display available?): {error}")
    app.mainloop()
