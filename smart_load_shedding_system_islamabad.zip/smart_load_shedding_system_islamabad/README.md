# GRID / IQ — Demonstration edition

**Start with [the complete demonstration guide](docs/DEMONSTRATION_GUIDE.html)** (open locally in a browser), or read its [Markdown version](docs/DEMONSTRATION_GUIDE.md).

Run `python -m pip install -r requirements.txt`, then `python gui.py` from this folder. Python 3.10+ with Tk is recommended. Windows users can use `py` instead of `python`.

The new first tab offers a clean schematic, per-decision Back/Next replay, autoplay, stage jumps, a timeline slider, clickable component details and JSON export. MW values change with each allocation frame. The side panel is hidden initially; show it to select scenarios. Original detailed tabs remain; the geographic overview is now tab 8.

Read [validation](docs/VALIDATION.md) and [changes](docs/CHANGELOG.md). This is an educational model, with aggregate-only shedding schedules and a simplified stress evaluator, not operational power-grid software.

---

## Original project reference

# Smart Load-Shedding and Restoration System - Islamabad

An AI decision-support tool for a city power distribution network, modelled on
**Islamabad and the Rawalpindi side of the IESCO service area**. When a fault or a
generation shortfall hits the grid, the system answers four questions:

1. **Which zones lost power, and how can supply be restored?**
2. **Which repair crew should go where, and in what order?**
3. **If there is not enough power, who gets cut, when, and is it fair?**
4. **What is the worst thing that could happen next?**

It has a command-line interface and a desktop GUI. The algorithms need only the
Python standard library; `matplotlib` is needed for pictures and for the GUI.

> **Real vs modelled.** Place names (grid stations, sectors, hospitals, markets) and their
> approximate positions are real. The line topology, line and station capacities, zone
> demands and repair times are **illustrative estimates, not official IESCO or NTDC data**.
> See [Data sources and assumptions](#data-sources-and-assumptions).

## Quick start

```bash
pip install -r requirements.txt            # matplotlib
python gui.py                              # desktop GUI (tkinter ships with Python)
python main.py                             # command-line menu
python main.py --list                      # show the 5 scenarios
python main.py --scenario 4 --plot         # run one scenario and save pictures
python main.py --all --plot                # run every scenario
python main.py --benchmark                 # compare the algorithms
python -m unittest discover -s tests -t .  # run the tests
python tools/generate_islamabad_data.py    # rebuild data/*.json from real coordinates
```

On Debian/Ubuntu, tkinter may need `sudo apt install python3-tk`.
Pictures and `benchmark.csv` are written to `outputs/`.

## The desktop GUI

`python gui.py` opens a window with a collapsible sidebar and eight tabs, in pipeline order:

| Tab | What it shows |
|---|---|
| 1 Demonstration | Clean electrical schematic with per-decision Back/Next, playback, timeline scrubbing, stage jumps, synchronized MW values, component inspection and JSON replay export |
| 2 Restore | Table of every zone: status, source, route, switches to close. Selecting a row (or clicking a zone on the map) highlights its route |
| 3 Crews | Crew timeline (Gantt), job table, Genetic Algorithm vs nearest-first / heaviest-first / random, GA convergence curve |
| 4 Shedding | Zone-by-hour heat-map (CSP, after Simulated Annealing, or side by side) with fairness and breaker-operation numbers before and after |
| 5 Stress test | The worst case in plain English, the resilience score, and states searched with and without alpha-beta pruning |
| 6 How it works | Pipeline diagram and one card per algorithm, each with a "Show in the current run" link |
| 7 Benchmark | Runs the benchmark and shows tables and charts |
| 8 Geographic map | Original geographic overview with summary cards and broad-stage overlays |

The sidebar picks one of the 5 scenarios, or builds a **custom fault** (tick any line or
transformer, lower a grid station's output), sets the random seed, runs the analysis in a
background thread with a progress bar, and exports a report (text + figures).
**Presentation mode** (checkbox or `F11`) enlarges all fonts and hides the secondary
controls; the **Side panel** checkbox hides the whole sidebar to give the tabs more room; `F5` runs the analysis. Hover over the round **?** icons for plain-language help.
The current demonstration guide is in [`docs/DEMO_GUIDE.md`](docs/DEMO_GUIDE.md); figure
renders of each tab are in `docs/screenshots/`.

The GUI uses `src/pipeline.py` and the services. Its new replay layer reconstructs deterministic connectivity and allocation decisions and stores independent frames.

## Algorithms and where they are used

| Algorithm | File | Used for |
|---|---|---|
| DFS | `src/algorithms/uninformed/dfs.py` | Finds every node still energised from the working grid stations, so the dark zones are known |
| BFS | `src/algorithms/uninformed/bfs.py` | Finds the nearest backup source (fewest line hops) for each dark zone |
| Uniform Cost Search | `src/algorithms/uninformed/ucs.py` | Cheapest re-route that respects line and source capacity (service restoration) |
| A* | `src/algorithms/informed/astar.py` | Fastest road route for repair crews (heuristic: straight line at top speed) |
| Genetic Algorithm | `src/algorithms/optimization/genetic.py` | Order in which crews repair faults (priority-weighted completion time) |
| CSP (backtracking, MRV, forward checking) | `src/algorithms/csp/backtracking.py` | Builds a valid 24-hour load-shedding timetable |
| Simulated Annealing | `src/algorithms/optimization/annealing.py` | Improves the timetable's fairness and cuts breaker operations |
| Minimax with alpha-beta pruning | `src/algorithms/adversarial/minimax.py` | Worst-case stress test: adversary breaks parts, planner re-switches |

The algorithm files are generic (they know nothing about power grids). The files in
`src/services/` connect them to the grid problem.

## Project structure

```
smart_load_shedding_system_islamabad/
├── main.py                    command-line entry point and menu
├── gui.py                     starts the desktop GUI
├── requirements.txt
├── data/
│   ├── grid.json              22 nodes, 28 power lines, road links (generated)
│   └── scenarios.json         5 fault scenarios (generated)
├── tools/
│   └── generate_islamabad_data.py   real coordinates -> km, builds the data files, runs checks
├── src/
│   ├── config.py              all settings in one place
│   ├── pipeline.py            runs the 5 steps for one scenario
│   ├── models/                Grid, Node, Line, GridState, Scenario
│   ├── algorithms/            uninformed/ informed/ optimization/ csp/ adversarial/
│   ├── services/              supply, fault_detection, restoration, crew_dispatch,
│   │                          load_shedding, stress_test
│   ├── utils/                 report.py (text), visualization.py (CLI pictures),
│   │                          map_drawing.py (map shared by CLI and GUI)
│   └── gui/                   controller, viewmodel, figures (no tkinter) and the screens:
│                              app, sidebar, statusbar, overview/restoration/crews/
│                              shedding/stress/howitworks/benchmark tabs, widgets, theme
├── benchmarks/benchmark.py    algorithm comparison
├── tests/                     unit tests (algorithms, services, data, GUI logic)
├── docs/                      DEMO_GUIDE.md, PLACES.md (provenance), screenshots/
└── outputs/                   generated pictures and CSV
```

## The model

* **Nodes:** 2 grid stations (Sangjani 220 kV, Rawat 500 kV), 6 transformer / feeder points
  (132 kV grid stations), 12 consumer zones and 2 repair depots.
* **Zones:** 3 hospitals (PIMS, Shifa International, CMH Rawalpindi), 2 industrial
  (I-9 Industrial Area, Rawat Industrial Area / IMSEZ), 3 markets (Jinnah Super Market F-7,
  Karachi Company G-9, Saddar Bazaar) and 4 residential (F-6, G-11, Satellite Town, Bahria Town Phase 4).
* **Priority:** 1 hospital (never cut), 2 industrial, 3 market, 4 residential.
* **Lines:** each has a capacity in MW. Some are *normally open* (tie switches and backup
  feeders); closing one is how power is re-routed.
* **Roads:** follow the power lines plus extra links, at 1.25 x the straight-line distance
  (so the A* heuristic is admissible); crews drive at about 30 km/h.

## Scenarios

1. Feeder cable fault: Sangjani - Zero Point circuit
2. Transformer failure at Chaklala GSS
3. Sangjani Grid Station partial trip
4. Sangjani Grid Station full outage
5. Monsoon storm over the Margalla Hills (multiple faults)

## How the pipeline works (`src/pipeline.py`)

1. **Detect.** DFS from the working stations finds what is energised. A derated station that
   cannot carry its zones drops the least important ones. BFS reports how many switching
   steps away the nearest backup is.
2. **Restore.** Zones are re-routed in priority order (hospitals first) with UCS. A route may
   only use lines and sources with enough spare MW. Each zone ends up *served*, *re-routed*,
   *shed* (reachable but no spare MW) or *isolated* (no path until repaired).
3. **Dispatch.** A* gives travel times between depots and fault sites. The Genetic Algorithm
   orders the repairs to minimise `sum(weight x completion time)`. It is compared with
   nearest-first, heaviest-first and random orders.
4. **Shed.** The MW still unserved is the deficit. A 24-hour timetable (12 slots of 2 h) is
   built so that each slot cuts at least the deficit, no hospital is ever cut, no zone is cut
   for more than 2 slots in a row, and no zone exceeds its fair share. The CSP finds a valid
   timetable; Simulated Annealing then improves Jain's fairness index and reduces breaker
   operations while keeping every rule satisfied.
5. **Stress-test.** From the restored state, Minimax plays two rounds: the adversary fails a
   transformer or feeder, the planner closes a backup switch. The result is the worst case,
   plus a resilience score.

## Data sources and assumptions

### What is real and what is modelled

| Item | Status |
|---|---|
| Names of the grid stations, 132 kV grid stations, sectors, hospitals, markets, industrial areas | **Real** (IESCO / NTDC / public sources below) |
| Positions | **Approximate.** Sourced where a coordinate was found, otherwise interpolated or estimated (see `docs/PLACES.md`, column "Position basis") |
| Which grid station feeds which zone, line lengths, tie switches, backup feeders | **Modelled** - illustrative topology, not the real IESCO network |
| Line and station capacities (MW) | **Estimates.** Source capacity is the share of the real station given to the 12 modelled zones, not its nameplate rating |
| Zone demands (MW) | **Estimates** (basis below) |
| Repair times, crew speed, 2-hour shedding slots | **Assumptions** |

The 12 zones total about 164 MW, a small illustrative slice of the area. For scale, press
reports put IESCO's region-wide peak demand at roughly 2,200-2,400 MW across all its
districts. Real load management is applied feeder by feeder in rotating blocks; the model's
2-hour slots are an assumption, not IESCO's published schedule.

### Demand basis (all estimates, evening peak, aggregate for the named area)

| Zone type | Assumed demand | Reasoning |
|---|---|---|
| Hospital | 5-6 MW | large tertiary hospital: air-conditioning, theatres, imaging, laboratories |
| Industrial | 18-24 MW | many small and medium units (steel, marble, pharmaceuticals, food) |
| Market | 13-15 MW | one commercial markaz or bazaar: shops, lifts, air-conditioning |
| Residential | 13-20 MW | a sector or housing scheme of several thousand homes at about 1.5-2 kW diversified peak per home |

### How positions were produced

`tools/generate_islamabad_data.py` converts latitude/longitude to km with an equirectangular
projection around central Islamabad (33.68 N, 73.05 E). Islamabad's sectors form a regular
grid of roughly 2 km x 2 km, so sector centres without a sourced coordinate were
interpolated from the F-8 and H-8 coordinates. This lattice was checked against three
independent points: its I-10 centre is 0.6 km from the I-10 coordinate on Wikipedia, its
G-8 centre is 0.65 km from PIMS, and its H-8 centre is 0.8 km from Shifa International.
The script also checks that every road is at least as long as the straight line between its
ends (A* stays admissible) and that the healthy grid serves every zone without overload.

### Known problems found in sources

* Wikipedia's coordinates for **F-6** (33.42 N) and **Sihala** (33.15 N) are far from the real
  places (tens of km off), so they were **not used**. F-6 comes from the sector lattice.
  Sihala (named in the brief as an industrial area) was therefore left out; the second
  industrial zone is the Rawat area (Islamabad Model SEZ), which has a usable coordinate.
* No coordinate was found for the grid stations themselves. Sangjani uses the nearby village
  position, and the Rawat and 132 kV stations are placed near the area they are named after
  (about +-2 km). DHA Islamabad was not included because no usable coordinate was found.
* No list of Rescue 1122 or IESCO depot sites in Islamabad was found (new Rescue 1122
  stations were reported only as *planned*). Depot D1 uses the IESCO head office sector
  (G-7/4, from IESCO's own site); depot D2 is a **modelled** depot in Rawalpindi.

### Sources consulted

* IESCO Planning & Investigation: list of 132 kV / 220 kV grid stations and head office in G-7/4 - https://iesco.com.pk/index.php/pai-division-islamabad
* APP: fault at the 132 kV F-11 grid station affecting F-10, F-11 and G-11 feeders - https://www.app.com.pk/domestic/technical-fault-at-132-kv-grid-station-causes-power-suspension-to-key-feeders/
* APP and Profit/NTDC reports on the 220 kV Sangjani and 500 kV Rawat grid stations (Sangjani fault affecting Islamabad and Rawalpindi supply; Rawat as a northern hub)
* Wikipedia, Islamabad Electric Supply Company (network size) - https://en.wikipedia.org/wiki/Islamabad_Electric_Supply_Company
* ARY News and Pakistan Observer reports on IESCO peak demand and load management (dates not shown on the retrieved pages)
* NGA GeoNames gazetteer: Pakistan Institute of Medical Sciences (33.702832, 73.053291) - https://geonames.nga.mil
* Wikipedia: Shifa International Hospital, Combined Military Hospital Rawalpindi, F-8, H-8 and I-10 (Islamabad), Islamabad Model Special Economic Zone, Rawalpindi Cantonment, Satellite Town (Rawalpindi), Sangjani railway station
* Geocords.com: Bahria Town Phase IV geocode (street-level)
* Zameen.com, "Famous markets in Islamabad": Jinnah Super Market (F-7), Super Market (F-6), Karachi Company (G-9) - https://www.zameen.com/blog/famous-markets-islamabad.html
* Islamabad Chamber of Commerce and Industry: industrial areas I-9, I-10 and the Kahuta triangle - https://icci.com.pk/business-tips.html

Per-place provenance is generated into [`docs/PLACES.md`](docs/PLACES.md).

## Assumptions and limits

* Load-shedding rotation assumes feeders can be re-switched between slots (aggregate supply
  check, not a full power-flow calculation).
* Zones too large to fit inside the allowed shed band are exempt from rotation and reported
  as "too large to rotate".
* The adversary attacks transformers and feeders; grid stations are covered by their own scenarios.
* The data is an illustrative model, not official figures. Change the lists in
  `tools/generate_islamabad_data.py` (or edit `data/*.json`) to try other networks.
* The GUI could not be run on a real display in the environment where it was written (no
  tkinter there); see the note in `docs/DEMO_GUIDE.md`. Results are reproducible: `--seed`
  controls the GA and annealing.
