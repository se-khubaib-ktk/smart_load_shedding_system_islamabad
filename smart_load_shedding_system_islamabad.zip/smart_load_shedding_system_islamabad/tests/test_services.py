"""Tests for the grid model and the five services."""
import random
import unittest

from src import config
from src.models.grid import load_grid
from src.models.state import GridState, load_scenarios
from src.pipeline import run_scenario
from src.services.fault_detection import find_energized
from src.services.restoration import plan_restoration
from src.services.stress_test import run_stress_test
from src.services.supply import assign_supply


class ServiceTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.grid = load_grid()
        cls.scenarios = load_scenarios()
        cls.baseline = assign_supply(cls.grid, GridState())

    def test_healthy_grid_serves_everyone(self):
        self.assertEqual(len(self.baseline.routes), len(self.grid.zones))
        for source in self.grid.sources:
            self.assertLessEqual(self.baseline.source_load[source.id], source.capacity_mw)

    def test_no_line_is_overloaded_after_any_scenario(self):
        for sc in self.scenarios:
            plan = plan_restoration(self.grid, sc.state, self.baseline)
            for line_id, load in plan.loads.line_load.items():
                self.assertLessEqual(load, self.grid.lines[line_id].capacity_mw + 1e-9, sc.name)
            for source_id, load in plan.loads.source_load.items():
                self.assertLessEqual(load, sc.state.capacity_of(self.grid, source_id) + 1e-9, sc.name)

    def test_failed_parts_are_never_used(self):
        for sc in self.scenarios:
            plan = plan_restoration(self.grid, sc.state, self.baseline)
            for route in plan.loads.routes.values():
                self.assertFalse(set(route.lines) & sc.state.failed_lines, sc.name)
                self.assertFalse(set(route.nodes) & sc.state.failed_nodes, sc.name)

    def test_hospitals_are_served_whenever_possible(self):
        for sc in self.scenarios:
            plan = plan_restoration(self.grid, sc.state, self.baseline)
            unserved_hospitals = [z.id for z in self.grid.zones
                                  if z.priority == config.CRITICAL_PRIORITY and z.id not in plan.loads.routes]
            self.assertEqual(unserved_hospitals, [], sc.name)

    def test_dfs_detects_cut_off_zone(self):
        # Chaklala GSS (T5) feeds CMH (Z3) and Bahria Town (Z12); Saddar (Z8) is on T4
        state = GridState(failed_nodes={"T5"})
        energized = find_energized(self.grid, state)
        self.assertNotIn("Z12", energized)
        self.assertIn("Z8", energized)

    def test_shedding_timetable_respects_the_rules(self):
        result = run_scenario(self.grid, self.scenarios[3], verbose=False)   # S1 outage
        plan = result.shedding
        self.assertTrue(plan.feasible)
        for slot in plan.sa_schedule:
            shed_mw = sum(self.grid.nodes[z].demand_mw for z in slot)
            self.assertGreaterEqual(shed_mw, plan.deficit_mw - 1e-9)
            for zone in slot:
                self.assertGreater(self.grid.nodes[zone].priority, config.CRITICAL_PRIORITY)
        self.assertLessEqual(plan.sa_metrics.max_consecutive_hours,
                             plan.consecutive_limit * config.HOURS_PER_SLOT)

    def test_annealing_does_not_hurt_fairness_much(self):
        result = run_scenario(self.grid, self.scenarios[3], verbose=False)
        self.assertGreaterEqual(result.shedding.sa_metrics.jain_fairness,
                                result.shedding.csp_metrics.jain_fairness - 0.01)

    def test_dispatch_visits_every_fault_once(self):
        result = run_scenario(self.grid, self.scenarios[4], verbose=False)
        visited = [v.fault.id for crew in result.dispatch.visits for v in crew]
        self.assertEqual(sorted(visited), sorted(f.id for f in result.dispatch.faults))
        self.assertLessEqual(result.dispatch.cost, min(result.dispatch.baselines.values()) + 1e-6)

    def test_alpha_beta_gives_same_answer_with_fewer_states(self):
        sc = self.scenarios[0]
        plan = plan_restoration(self.grid, sc.state, self.baseline)
        r = run_stress_test(self.grid, sc.state, plan.switch_ops, compare_unpruned=True)
        self.assertEqual(r.worst_value, r.unpruned_value)
        self.assertLess(r.stats.nodes, r.unpruned_stats.nodes)

    def test_scenarios_are_meaningful(self):
        """At least two scenarios need load-shedding and at least one needs repair crews."""
        results = [run_scenario(self.grid, sc, verbose=False) for sc in self.scenarios]
        self.assertGreaterEqual(sum(1 for r in results if r.shedding.sa_schedule), 2)
        self.assertGreaterEqual(sum(1 for r in results if r.dispatch is not None), 1)
        self.assertEqual(len(self.scenarios), 5)

    def test_same_seed_gives_same_result(self):
        a = run_scenario(self.grid, self.scenarios[2], seed=7, verbose=False)
        b = run_scenario(self.grid, self.scenarios[2], seed=7, verbose=False)
        self.assertEqual(a.shedding.sa_schedule, b.shedding.sa_schedule)


if __name__ == "__main__":
    unittest.main()
