"""Regression tests for reversible frames and corrected boundary conditions."""
import unittest
import random
from copy import deepcopy
from src.gui.controller import AnalysisController
from src.gui.demo_trace import build_trace
from src.gui.demo_map import schematic
from src.services.supply import SupplyLoads, route_zone
from src.services.load_shedding import plan_shedding
from src.models.state import GridState
from src.services.fault_detection import find_energized

class ReplayTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.controller=AnalysisController(lambda *args:None)
        cls.grid=cls.controller.grid
        cls.runs=[cls.controller.analyze(s,42) for s in cls.controller.scenarios]

    def test_restore_replay_equals_pipeline_for_all_scenarios(self):
        for a in self.runs:
            fs=build_trace(self.grid,a)
            restored=[f for f in fs if f.stage=='Restore'][-1]
            self.assertEqual(restored.loads,a.result.restoration.loads)
            self.assertEqual(fs[-1].state,a.scenario.state)
            self.assertEqual(fs[-1].loads,a.result.restoration.loads)
            detected=[f for f in fs if f.visited][-1]
            self.assertEqual(detected.visited,find_energized(self.grid,a.scenario.state))

    def test_frames_do_not_share_mutable_state(self):
        fs=build_trace(self.grid,self.runs[0]); baseline=deepcopy(fs[0])
        fs[1].state.failed_lines.add('F1');fs[1].loads.routes.clear()
        self.assertEqual(fs[0],baseline)
        self.assertNotIn('F1',self.runs[0].scenario.state.failed_lines)

    def test_every_frame_respects_capacity_and_failed_components(self):
        for a in self.runs:
            for f in build_trace(self.grid,a):
                for lid,mw in f.loads.line_load.items():
                    l=self.grid.lines[lid]
                    self.assertLessEqual(mw,l.capacity_mw)
                    self.assertNotIn(lid,f.state.failed_lines)
                    self.assertNotIn(l.a,f.state.failed_nodes)
                    self.assertNotIn(l.b,f.state.failed_nodes)
                for src,mw in f.loads.source_load.items():
                    self.assertLessEqual(mw,f.state.capacity_of(self.grid,src))
                self.assertFalse(any(self.grid.nodes[z].priority==1 for z in f.cuts))
                for a,b in zip(f.road_path,f.road_path[1:]):
                    self.assertIn(b,[n for n,_ in self.grid.roads[a]])

    def test_failed_zone_cannot_receive_supply(self):
        state=GridState(failed_nodes={'Z1'})
        self.assertIsNone(route_zone(self.grid,state,SupplyLoads(),'Z1',True))
        self.assertIsNone(route_zone(self.grid,state,SupplyLoads(),'Z1',True,False))

    def test_deficit_with_empty_pool_is_infeasible(self):
        plan=plan_shedding(self.grid,10,[],random.Random(42))
        self.assertFalse(plan.feasible)
        self.assertIn('deficit',plan.message)

    def test_render_each_stage(self):
        import io
        for a in self.runs:
            stages={}
            for f in build_trace(self.grid,a):stages[f.stage]=f
            for f in stages.values():
                fig,_=schematic(self.grid,f,show_backups=True)
                fig.savefig(io.BytesIO(),format='png')

if __name__=='__main__':unittest.main()
