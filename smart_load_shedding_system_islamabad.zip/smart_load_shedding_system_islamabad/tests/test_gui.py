"""GUI tests. Everything except the last class runs without tkinter or a display."""
import io
import time
import unittest

import matplotlib
matplotlib.use("Agg")
from matplotlib.figure import Figure

from src.gui import figures, viewmodel as vm
from src.gui.controller import AnalysisController


class GuiLogicTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.controller = AnalysisController(lambda ms, fn: None)
        cls.grid = cls.controller.grid
        cls.analyses = [cls.controller.analyze(s, 42) for s in cls.controller.scenarios]

    def test_cards_have_six_entries(self):
        for analysis in self.analyses:
            cards = vm.build_cards(self.grid, analysis)
            self.assertEqual([c.key for c in cards],
                             ["supplied", "shed", "isolated", "repair", "fairness", "resilience"])

    def test_zone_table_covers_every_zone_with_hospitals_first(self):
        for analysis in self.analyses:
            rows = vm.zone_rows(self.grid, analysis)
            self.assertEqual(len(rows), len(self.grid.zones))
            self.assertEqual({r["type"] for r in rows[:3]}, {"Hospital"})

    def test_every_figure_renders(self):
        for analysis in self.analyses:
            built = [figures.gantt_figure(self.grid, analysis), figures.crew_comparison_figure(analysis),
                     figures.convergence_figure(analysis), figures.stress_figure(analysis),
                     figures.pipeline_figure("shed")]
            built += [figures.heatmap_figure(self.grid, analysis, w) for w in ("both", "csp", "sa")]
            for stage in (None, "detect", "restore", "dispatch", "shed", "stress"):
                built.append(figures.map_figure(self.grid, analysis, stage)[0])
            built.append(figures.map_figure(self.grid, analysis, "restore", "Z1", scale=1.35)[0])
            for fig in built:
                self.assertIsInstance(fig, Figure)
                fig.savefig(io.BytesIO(), format="png")

    def test_step_captions_exist_for_every_stage(self):
        for stage in (None, "detect", "restore", "dispatch", "shed", "stress"):
            self.assertGreater(len(vm.stage_caption(self.grid, self.analyses[0], stage)), 20)

    def test_custom_scenario_runs(self):
        scenario = self.controller.custom_scenario({"F1"}, {"T2"}, {"S1": 40.0})
        analysis = self.controller.analyze(scenario, 1)
        self.assertEqual(scenario.state.source_capacity, {"S1": 40.0})
        self.assertIn("F1", scenario.description)
        self.assertGreater(len(vm.stress_sentences(self.grid, analysis)), 0)

    def test_hospitals_are_served_whenever_possible(self):
        for analysis in self.analyses:
            plan = analysis.result.restoration
            for zone in self.grid.zones:
                if zone.priority == 1:
                    self.assertNotIn(zone.id, plan.capacity_short)

    def test_no_line_or_station_is_overloaded(self):
        for analysis in self.analyses:
            loads = analysis.result.restoration.loads
            for line_id, mw in loads.line_load.items():
                self.assertLessEqual(mw, self.grid.lines[line_id].capacity_mw + 1e-6)
            for source in self.grid.sources:
                cap = analysis.scenario.state.capacity_of(self.grid, source.id)
                self.assertLessEqual(loads.source_load.get(source.id, 0), cap + 1e-6)

    def test_benchmark_data_can_be_charted(self):
        data = self.controller.benchmark(42)
        parsed = vm.parse_benchmark(data.rows, data.scenario_names)
        tables = vm.benchmark_tables(parsed)
        self.assertEqual(len(tables), 4)
        for fig in figures.benchmark_figures(parsed).values():
            fig.savefig(io.BytesIO(), format="png")

    def test_background_run_delivers_result(self):
        queued, results = [], []
        controller = AnalysisController(lambda ms, fn: queued.append(fn))
        self.assertTrue(controller.run_async(controller.scenarios[0], 1, results.append, results.append))
        self.assertFalse(controller.run_async(controller.scenarios[0], 1, print, print))   # busy
        deadline = time.time() + 30
        while not results and time.time() < deadline:
            while queued:
                queued.pop(0)()
            time.sleep(0.02)
        self.assertEqual(len(results), 1)
        self.assertFalse(controller.busy)


def _display_available():
    try:
        import tkinter
        root = tkinter.Tk()
        root.destroy()
        return True
    except Exception:                  # no tkinter, or no display (headless)
        return False


@unittest.skipUnless(_display_available(), "tkinter or a display is not available")
class WindowSmokeTest(unittest.TestCase):
    def test_replay_controls_and_projector_layout(self):
        from src.gui.app import App
        app = App()
        errors = []
        app.report_callback_exception = lambda *args: errors.append(args)
        app.after_cancel(app._startup_job)
        try:
            app.geometry("1366x768")
            analysis = app.controller.analyze(app.controller.scenarios[0], 42)
            app.show_analysis(analysis)
            demo = app.overview
            demo.go(5)
            caption = demo.caption.get("1.0", "end")
            demo.go(6)
            demo.go(5)
            self.assertEqual(demo.caption.get("1.0", "end"), caption)
            demo.jump.set("Dispatch")
            demo.jump_stage()
            self.assertEqual(demo.frames[demo.index].stage, "Dispatch")
            demo.toggle_play()
            self.assertIsNotNone(demo.job)
            demo.stop()
            self.assertIsNone(demo.job)
            app.update()
            self.assertTrue(demo.next.winfo_ismapped())
            self.assertGreater(demo.frame.winfo_height(), 250)
            self.assertLessEqual(demo.caption.winfo_rooty() + demo.caption.winfo_height(),
                                 app.winfo_rooty() + app.winfo_height())
            app.toggle_presentation(flip=True)
            app.update()
            self.assertTrue(demo.next.winfo_ismapped())
            app.show_analysis(analysis)
            self.assertEqual(demo.index, 0)
            app.update()
            self.assertEqual(errors, [])
        finally:
            app.destroy()

    def test_window_builds_and_shows_every_tab(self):
        from src.gui.app import App
        app = App()
        try:
            app.show_analysis(app.controller.analyze(app.controller.scenarios[4], 42))
            app.toggle_presentation(flip=True)
            app.update_idletasks()
            self.assertEqual(len(app.notebook.tabs()), 8)
        finally:
            app.destroy()


if __name__ == "__main__":
    unittest.main()
