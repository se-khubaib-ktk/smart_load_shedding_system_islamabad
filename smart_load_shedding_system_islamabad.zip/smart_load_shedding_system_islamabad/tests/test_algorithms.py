"""Unit tests for the generic algorithms (no power-grid knowledge needed)."""
import random
import unittest

from src.algorithms.adversarial.minimax import minimax
from src.algorithms.csp.backtracking import solve_csp
from src.algorithms.informed.astar import astar
from src.algorithms.optimization.annealing import simulated_annealing
from src.algorithms.optimization.genetic import genetic_algorithm, order_crossover, swap_mutation
from src.algorithms.uninformed.bfs import bfs
from src.algorithms.uninformed.dfs import dfs
from src.algorithms.uninformed.ucs import ucs

# A -1- B -1- D     A -5- D is a long shortcut in hops but not in cost
GRAPH = {"A": {"B": 1, "D": 5}, "B": {"A": 1, "C": 1}, "C": {"B": 1, "D": 1}, "D": {"A": 5, "C": 1}}
COORD = {"A": 0, "B": 1, "C": 2, "D": 3}


class SearchTests(unittest.TestCase):
    def test_bfs_fewest_hops(self):
        result = bfs("A", lambda n: GRAPH[n], lambda n: n == "D")
        self.assertEqual(result.path, ["A", "D"])

    def test_ucs_cheapest(self):
        result = ucs("A", lambda n: GRAPH[n].items(), lambda n: n == "D")
        self.assertEqual(result.path, ["A", "B", "C", "D"])
        self.assertEqual(result.cost, 3)

    def test_astar_matches_ucs(self):
        result = astar("A", "D", lambda n: GRAPH[n].items(),
                       lambda n, g: abs(COORD[n] - COORD[g]))
        self.assertEqual(result.cost, 3)

    def test_no_path(self):
        self.assertFalse(bfs("A", lambda n: [], lambda n: n == "D").found)

    def test_dfs_reaches_everything(self):
        self.assertEqual(set(dfs("A", lambda n: GRAPH[n])), set(GRAPH))


class CSPTests(unittest.TestCase):
    def test_all_different(self):
        domains = {v: [1, 2, 3] for v in "xyz"}
        consistent = lambda a: len(set(a.values())) == len(a)
        solution, _ = solve_csp(domains, consistent)
        self.assertEqual(sorted(solution.values()), [1, 2, 3])

    def test_unsolvable(self):
        domains = {v: [1, 2] for v in "xyz"}
        consistent = lambda a: len(set(a.values())) == len(a)
        solution, _ = solve_csp(domains, consistent)
        self.assertIsNone(solution)


class OptimisationTests(unittest.TestCase):
    def test_genetic_sorts_a_permutation(self):
        rng = random.Random(1)
        target = list(range(7))

        def fitness(p):
            return sum(abs(a - b) for a, b in zip(p, target))

        def make():
            p = target[:]
            rng.shuffle(p)
            return p

        best, history = genetic_algorithm(make, fitness,
                                          lambda a, b: order_crossover(a, b, rng),
                                          lambda p: swap_mutation(p, rng),
                                          population_size=40, generations=60, rng=rng)
        self.assertEqual(sorted(best), target)            # still a valid permutation
        self.assertLessEqual(history[-1], history[0])     # never gets worse (elitism)

    def test_annealing_finds_minimum(self):
        rng = random.Random(2)
        best, _ = simulated_annealing(40, lambda x: x + rng.choice([-1, 1]),
                                      lambda x: (x - 5) ** 2, steps=3000, rng=rng)
        self.assertLessEqual(abs(best - 5), 1)


class MinimaxTests(unittest.TestCase):
    def test_pruning_keeps_the_same_value(self):
        # tiny game tree: states are tuples of moves, leaf value = sum
        moves = lambda s, mx: [1, 2, 3]
        apply = lambda s, m, mx: s + (m * (1 if mx else -1),)
        value = lambda s: sum(s) * 1.0
        with_pruning = minimax((), 4, True, moves, apply, value, use_pruning=True)
        without = minimax((), 4, True, moves, apply, value, use_pruning=False)
        self.assertEqual(with_pruning[0], without[0])
        self.assertLess(with_pruning[2].nodes, without[2].nodes)


if __name__ == "__main__":
    unittest.main()
