"""Checks on the Islamabad data files (data/grid.json and data/scenarios.json)."""
import math
import unittest

from src import config
from src.models.grid import load_grid
from src.models.state import load_scenarios

ROOT = config.ROOT_DIR
OLD_NAMES = ["Lahore", "Ravi", "Ghazi", "Gulberg", "Model Town", "Anarkali", "Johar",
             "Township", "Mayo", "Shalamar", "Sundar", "Faisal Town", "LESCO"]


class DataTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.grid = load_grid()
        cls.scenarios = load_scenarios()

    def test_size_and_zone_mix(self):
        by_priority = {p: 0 for p in config.PRIORITY_NAMES}
        for zone in self.grid.zones:
            by_priority[zone.priority] += 1
        self.assertLessEqual(len(self.grid.sources), 3)
        self.assertLessEqual(len(self.grid.zones), 15)
        self.assertEqual(len(self.grid.of_type("transformer")), 6)
        self.assertEqual(len(self.grid.depots), 2)
        self.assertGreaterEqual(by_priority[1], 3)       # hospitals
        self.assertGreaterEqual(by_priority[2], 2)       # industrial
        self.assertGreaterEqual(by_priority[3], 2)       # markets

    def test_roads_are_never_shorter_than_straight_lines(self):
        """Keeps the A* heuristic admissible."""
        km_per_minute = config.ROAD_SPEED_KMH / 60.0
        for a, edges in self.grid.roads.items():
            for b, minutes in edges:
                self.assertGreaterEqual(minutes * km_per_minute + 1e-9, self.grid.distance_km(a, b))

    def test_coordinates_look_like_islamabad(self):
        xs = [n.x for n in self.grid.nodes.values()]
        ys = [n.y for n in self.grid.nodes.values()]
        self.assertTrue(0 < max(xs) - min(xs) < 60 and 0 < max(ys) - min(ys) < 60)
        # the two grid stations are tens of km apart, the zones are not on top of each other
        s1, s2 = self.grid.sources
        self.assertGreater(self.grid.distance_km(s1.id, s2.id), 15)
        ids = list(self.grid.nodes)
        for i, a in enumerate(ids):
            for b in ids[i + 1:]:
                self.assertGreater(self.grid.distance_km(a, b), 0.5, f"{a} and {b} overlap")

    def test_scenarios_have_names_and_descriptions(self):
        for sc in self.scenarios:
            self.assertGreater(len(sc.name), 10)
            self.assertTrue(sc.description.endswith("."))
            for line_id in sc.state.failed_lines:
                self.assertIn(line_id, self.grid.lines)
            for node_id in sc.state.failed_nodes | set(sc.state.source_capacity):
                self.assertIn(node_id, self.grid.nodes)

    def test_no_leftovers_from_the_old_city(self):
        """The old invented Lahore names must not survive anywhere in the project."""
        checked = 0
        for path in ROOT.rglob("*"):
            if path.suffix not in {".py", ".json", ".md", ".txt", ".csv"}:
                continue
            if "__pycache__" in path.parts or path.name == "test_data.py":
                continue
            text = path.read_text(encoding="utf-8", errors="ignore")
            for name in OLD_NAMES:
                self.assertNotIn(name, text, f"'{name}' found in {path.relative_to(ROOT)}")
            checked += 1
        self.assertGreater(checked, 20)


if __name__ == "__main__":
    unittest.main()
