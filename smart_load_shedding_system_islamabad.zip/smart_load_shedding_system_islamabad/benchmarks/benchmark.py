"""Compares the algorithms on the same problems.

    python -m benchmarks.benchmark
"""
import csv
import random
import time

from src import config
from src.algorithms.informed.astar import astar
from src.algorithms.uninformed.bfs import bfs
from src.algorithms.uninformed.ucs import ucs
from src.models.grid import load_grid
from src.models.state import GridState, load_scenarios
from src.services.crew_dispatch import Fault, TravelTimes, plan_dispatch, simulate
from src.services.load_shedding import plan_shedding
from src.services.restoration import plan_restoration
from src.services.stress_test import run_stress_test
from src.services.supply import assign_supply
from src.algorithms.optimization.genetic import genetic_algorithm, order_crossover, swap_mutation


def run_benchmark(grid=None, scenarios=None, seed=config.DEFAULT_SEED):
    grid = grid or load_grid()
    scenarios = scenarios or load_scenarios()
    rows = []
    rows += _path_search(grid)
    rows += _crew_ordering(grid, seed)
    rows += _shedding(grid, scenarios, seed)
    rows += _minimax(grid, scenarios)

    config.OUTPUT_DIR.mkdir(exist_ok=True)
    out = config.OUTPUT_DIR / "benchmark.csv"
    with open(out, "w", newline="", encoding="utf-8") as handle:
        writer = csv.writer(handle)
        writer.writerow(["test", "algorithm", "metric", "value"])
        writer.writerows(rows)
    print(f"\nResults saved to {out}")
    return rows


def _heading(text):
    print(f"\n{text}\n{'-' * 78}")


# 1. Path search on the road network ---------------------------------------
def _path_search(grid):
    _heading("1. Road path search: depots to every other node (BFS vs UCS vs A*)")
    minutes = {(a, b): m for a, edges in grid.roads.items() for b, m in edges}
    pairs = [(d.id, n) for d in grid.depots for n in grid.nodes if n != d.id]
    totals = {"BFS": [0, 0.0, 0.0], "UCS": [0, 0.0, 0.0], "A*": [0, 0.0, 0.0]}
    neighbors = lambda n: grid.roads[n]
    heuristic = lambda n, g: grid.distance_km(n, g) / config.MAX_SPEED_KMH * 60.0

    for start, goal in pairs:
        runs = {}
        t = time.perf_counter()
        r = bfs(start, lambda n: [x for x, _ in grid.roads[n]], lambda n: n == goal)
        runs["BFS"] = (r, time.perf_counter() - t,
                       sum(minutes[(a, b)] for a, b in zip(r.path, r.path[1:])))
        t = time.perf_counter()
        r = ucs(start, neighbors, lambda n: n == goal)
        runs["UCS"] = (r, time.perf_counter() - t, r.cost)
        t = time.perf_counter()
        r = astar(start, goal, neighbors, heuristic)
        runs["A*"] = (r, time.perf_counter() - t, r.cost)
        for name, (res, secs, cost) in runs.items():
            totals[name][0] += res.expanded
            totals[name][1] += cost
            totals[name][2] += secs

    rows = []
    n = len(pairs)
    print(f"{'Algorithm':<10}{'avg nodes expanded':>20}{'avg travel (min)':>20}{'total time (ms)':>18}")
    for name, (expanded, cost, secs) in totals.items():
        print(f"{name:<10}{expanded / n:>20.1f}{cost / n:>20.1f}{secs * 1000:>18.2f}")
        rows += [("path search", name, "avg nodes expanded", round(expanded / n, 2)),
                 ("path search", name, "avg travel minutes", round(cost / n, 2))]
    print("BFS ignores travel time, so its routes can be slower. A* is optimal like UCS "
          "but expands fewer nodes.")
    return rows


# 2. Crew ordering ---------------------------------------------------------
def _crew_ordering(grid, seed, trials=10, jobs=9):
    _heading(f"2. Crew ordering: {jobs} random faults, 3 crews, {trials} trials (lower is better)")
    sites = [n.id for n in grid.nodes.values() if n.type in ("zone", "transformer")]
    crews = ["D1", "D2", "D1"]
    totals = {"Genetic Algorithm": 0.0, "nearest-first": 0.0, "heaviest-first": 0.0, "random": 0.0}

    for trial in range(trials):
        rng = random.Random(seed + trial)
        faults = [Fault(f"f{i}", "line", f"x{i}", rng.choice(sites), rng.choice([60, 90, 180]),
                        rng.choice([5, 20, 60, 120, 300])) for i in range(jobs)]
        travel = TravelTimes(grid)
        idx = list(range(jobs))

        def fitness(order):
            return simulate(order, faults, crews, travel)[0]

        def random_order():
            order = idx[:]
            rng.shuffle(order)
            return order

        best, _ = genetic_algorithm(random_order, fitness,
                                    lambda a, b: order_crossover(a, b, rng),
                                    lambda x: swap_mutation(x, rng),
                                    config.GA_POPULATION, config.GA_GENERATIONS,
                                    rng=rng)
        nearest = sorted(idx, key=lambda i: min(travel.minutes(c, faults[i].site) for c in crews))
        heaviest = sorted(idx, key=lambda i: -faults[i].weight)
        totals["Genetic Algorithm"] += fitness(best)
        totals["nearest-first"] += fitness(nearest)
        totals["heaviest-first"] += fitness(heaviest)
        totals["random"] += fitness(random_order())

    rows = []
    print(f"{'Method':<20}{'avg weighted cost':>20}")
    for name, total in totals.items():
        print(f"{name:<20}{total / trials:>20,.0f}")
        rows.append(("crew ordering", name, "avg weighted cost", round(total / trials)))
    return rows


# 3. Shedding timetable ----------------------------------------------------
def _shedding(grid, scenarios, seed):
    _heading("3. Load-shedding timetable: CSP alone vs CSP + Simulated Annealing")
    baseline = assign_supply(grid, GridState())
    rows = []
    print(f"{'Scenario':<34}{'CSP nodes':>10}{'Jain CSP':>10}{'Jain SA':>9}{'Ops CSP':>9}{'Ops SA':>8}{'Time s':>8}")
    for sc in scenarios:
        plan = plan_restoration(grid, sc.state, baseline)
        pool = [z.id for z in grid.zones if z.priority > 1 and z.id not in plan.isolated]
        t = time.perf_counter()
        s = plan_shedding(grid, plan.deficit_mw(grid), pool, random.Random(seed))
        secs = time.perf_counter() - t
        if not s.csp_schedule:
            print(f"{sc.name[:33]:<34}{'no shedding needed':>50}")
            continue
        print(f"{sc.name[:33]:<34}{s.csp_stats.nodes:>10}{s.csp_metrics.jain_fairness:>10.3f}"
              f"{s.sa_metrics.jain_fairness:>9.3f}{s.csp_metrics.breaker_operations:>9}"
              f"{s.sa_metrics.breaker_operations:>8}{secs:>8.2f}")
        rows += [("shedding", f"CSP / {sc.name}", "jain", round(s.csp_metrics.jain_fairness, 3)),
                 ("shedding", f"CSP+SA / {sc.name}", "jain", round(s.sa_metrics.jain_fairness, 3)),
                 ("shedding", f"CSP / {sc.name}", "breaker ops", s.csp_metrics.breaker_operations),
                 ("shedding", f"CSP+SA / {sc.name}", "breaker ops", s.sa_metrics.breaker_operations)]
    return rows


# 4. Minimax ---------------------------------------------------------------
def _minimax(grid, scenarios):
    _heading("4. Stress test: Minimax with and without alpha-beta pruning")
    baseline = assign_supply(grid, GridState())
    rows = []
    print(f"{'Scenario':<34}{'plain nodes':>12}{'alpha-beta':>12}{'saved':>8}{'same answer':>13}")
    for sc in scenarios:
        plan = plan_restoration(grid, sc.state, baseline)
        r = run_stress_test(grid, sc.state, plan.switch_ops, compare_unpruned=True)
        plain, pruned = r.unpruned_stats.nodes, r.stats.nodes
        print(f"{sc.name[:33]:<34}{plain:>12}{pruned:>12}{(1 - pruned / plain) * 100:>7.0f}%"
              f"{'yes' if r.unpruned_value == r.worst_value else 'NO':>13}")
        rows += [("minimax", f"plain / {sc.name}", "nodes", plain),
                 ("minimax", f"alpha-beta / {sc.name}", "nodes", pruned)]
    return rows


if __name__ == "__main__":
    run_benchmark()
