# GRID / IQ — Demonstration & Viva Guide

Smart Load-Shedding and Restoration System · Islamabad / Rawalpindi  
Demonstration edition · 29 October 2026

## 1. Start here

Extract the entire ZIP before running it. Open a terminal in the extracted project folder (the folder containing `gui.py`). Use Python 3.10 or newer with Tk support.

**Windows**

```text
py -m venv .venv
.venv\Scripts\python -m pip install -r requirements.txt
.venv\Scripts\python gui.py
```

**macOS / Linux**

```text
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python gui.py
```

Tk is included in many Python distributions, but some Linux installations require a separate `python3-tk` package. Run `python -m tkinter` using your selected Python to check it. The application is a local desktop program; it needs no API key, paid service or internet once dependencies are installed.

The first scenario loads automatically. Maximize the window. The side panel starts hidden to give the diagram enough space. Enable **Side panel** to choose a different scenario, then **Run analysis** (or F5). Hide it again before presenting. Use a 1366 × 768 or larger display if possible.

## 2. What to say in the first 30 seconds

> This is an educational decision-support system for a simplified Islamabad and Rawalpindi electricity network. It detects the impact of faults, reallocates supply while checking capacities, plans repair-crew jobs, builds a rotating load-shedding timetable, and explores additional failures. Different algorithms solve different subproblems. The demonstration replays those decisions so we can inspect what happened and why.

Do not describe this as live IESCO software. The place names are based on real locations, but the topology, capacities, demands, road connections and repair times are illustrative model inputs. The original provenance notes remain in `docs/PLACES.md`.

## 3. Read the screen

| Visual | Meaning |
|---|---|
| Square / S | Supply source; card shows allocated MW / available MW |
| Triangle / T | Transformer node |
| Circle / Z | Demand zone; card shows demand, priority and ON/OFF allocation |
| Diamond / D | Repair-crew depot |
| Green line | Used by the allocation in this frame |
| Blue line / outline | Current decision or highlighted route |
| Red cross | Failed component or connection disabled by a failed endpoint |
| Grey line / OFF zone | No allocation in this frame; not necessarily physically failed |
| Dashed backup line | Normally-open backup shown for inspection or diagnostic routing |
| Amber hatch / CUT | Proposed cut in the selected schedule slot |
| Purple dotted arrows | Planned crew travel on the road graph, not electricity flow |
| Small check mark | Node visited during the DFS replay |
| `F1 28/40` | Line F1 has 28 MW allocated against a 40 MW rating |

The primary view is a **schematic**, arranged into six feeder groups. It keeps labels separated; its screen distances are not inputs to routing. Algorithms still use the original model coordinates. Tab 8 retains the geographic overview.

Click a node or line to read its full details below the map. **All ties** reveals inactive backup lines; keep it off during the main explanation for a clean diagram. Active backup routes remain visible. P1/P2/P3/P4 on zone cards are priority classes: hospital, industrial, market and residential. `P1` as a line ID is a separate naming convention; inspect the object to distinguish them.

## 4. Replay controls

- **Next / Back**, or left/right arrow keys when focus is outside a text entry: move one decision.
- **Reset:** return to the healthy baseline.
- **Play / Pause:** advance about every 2.4 seconds. Pause for discussion.
- **Slider:** scrub directly to another frame.
- **Jump to stage:** Baseline, Detect, Restore, Dispatch, Schedule, Stress or Summary.
- **Export replay:** save scenario, random seed, explanations and frame data as JSON.
- **F11:** enlarge the application text. Use the ordinary window maximize control for full screen area.
- **Export report** in the side panel: save the analysis report and current diagram.

Back/Next show independent saved snapshots. They do not undo physical equipment actions or rerun randomized optimization. A new analysis builds a new replay and resets playback. The steps explain actual decisions and diagnostic results; this is not a low-level debugger showing every heap pop, GA chromosome or annealing candidate.

## 5. Recommended 8–10 minute demonstration

| Time | Action | Explanation to give |
|---|---|---|
| 0:00–0:45 | Show Baseline | Two sources, six transformers, twelve zones, two depots; total demand 164 MW. Explain symbols and MW. |
| 0:45–1:45 | Scenario 1, Detect | F2 fails. Step through a few DFS visits. Reachability and capacity are different questions. Jump to the BFS backup checks if useful. |
| 1:45–3:00 | Jump to Restore | Step through hospital allocations first. Read one UCS route, its cost and MW. Back once, then Next to demonstrate repeatable visual changes. |
| 3:00–4:00 | Jump to Dispatch | Purple path shows crew travel. Read arrival and finish times. Explain that jobs are planned, not already repaired. Open the Crews tab for the timeline. |
| 4:00–5:00 | Open Shedding / Schedule | Show the original CSP timetable beside its annealed version. Explain fairness and switching tradeoffs. Step through two schedule slots. |
| 5:00–6:00 | Choose Scenario 2, rerun | A failed transformer can isolate a zone even when there is enough aggregate supply elsewhere. Highlight Z12. |
| 6:00–7:00 | Choose Scenario 3, rerun | No physical component has failed, but available generation is lower. Show capacity shortage and rotating cuts. |
| 7:00–8:00 | Jump to Stress, then Summary | Explain adversary versus planner, hypothetical faults, alpha-beta pruning, then return to the actual plan. |
| 8:00–10:00 | Benchmark / questions | Run the benchmark if time permits. Discuss measured results and model limitations, not a universal “best algorithm.” |

For a five-minute demonstration, use Scenario 1 throughout and jump between stages. For a longer demonstration, finish with Scenario 5 (multiple faults). Do not spend the whole session clicking every DFS frame.

## 6. Verified reference outcomes

These are the current code's seed-42 restoration allocations, before any physical repairs. They are useful rehearsal checkpoints. GA/annealing results can change with seed; do not memorize timings as guarantees.

| Scenario | Allocated / 164 MW | Isolated zones | Capacity-short zones | Planned tie closures |
|---|---|---|---|---|
| 1: F2 cable fault | 150 MW | None | Z10 | TL1, TL2, TL3 |
| 2: T5 transformer failure | 144 MW | Z12 | None | B3 |
| 3: S1 reduced to 55 MW | 137 MW | None | Z10, Z9 | TL2, TL3, TL4, TL5 |
| 4: S1 unavailable | 88 MW | None | Z6, Z12, Z11, Z10, Z9 | TL2, TL4, TL1 |
| 5: Multiple storm faults | 68 MW | Z5, Z12, Z10 | Z8, Z11, Z9 | TL1, B3, B2, B4, TL2 |

A priority-based greedy allocation can leave demand unserved even if total nameplate generation exceeds total demand. Local line bottlenecks and earlier allocations matter. These results should not be described as the global maximum possible supply.

## 7. How the system works internally

1. **Load data.** `data/grid.json` describes nodes, power lines, backup lines and extra roads. `data/scenarios.json` describes failures and source deratings. `src/config.py` contains policy weights and algorithm settings.
2. **Healthy reference.** UCS allocates normal supply with backup ties closed to traversal (unavailable). This records each zone's original source and path.
3. **Fault impact.** DFS walks healthy, normally closed electrical connections from working sources. The service identifies disconnected zones and source-overload impacts. BFS checks minimum-hop backup possibilities without checking capacity.
4. **Restoration.** Zones are processed in priority order. Inside a priority class, unaffected zones precede affected ones, then larger demands come first. UCS searches a feasible route using remaining source and line capacities. Successful routes reserve capacity and record backup closures. A failed capacity-aware search is retried ignoring capacity to distinguish capacity shortage from physical isolation.
5. **Crew plan.** A* supplies travel times on the separate road graph. GA evolves permutations of repair jobs. Each job in a permutation is assigned to the crew that can arrive earliest (repair duration for that job is the same for every crew). The score is the sum of weighted completion times.
6. **Shedding.** The restoration deficit for reachable but unserved zones becomes an aggregate target. A CSP chooses cut sets for twelve two-hour slots. Hospitals and isolated zones are excluded from the voluntary rotation pool. Simulated annealing tries feasible swaps to improve the combined fairness/switching objective.
7. **Stress analysis.** A four-ply game alternates extra failure, switch response, extra failure and response. Minimax chooses a worst-case branch; alpha-beta skips branches that cannot affect that minimax decision.
8. **Presentation.** The analysis runs in a background thread. GUI updates are delivered on Tk's event loop. The replay constructs independent frames from the results and deterministic allocation logic. Original analysis tabs remain available for details.

## 8. Why each algorithm was chosen

| Algorithm | Role and justification | Important qualification |
|---|---|---|
| DFS | Reachability needs a traversal, not a shortest path. Time O(V+E), memory O(V). | BFS could also perform this task. DFS does not optimize restoration. |
| BFS | Minimum number of edges to a backup source. Unweighted graph traversal is O(V+E). | Minimum hops is not minimum distance, minimum switches or proof of sufficient MW. |
| UCS | Nonnegative weighted electrical routes; no special heuristic is needed. Binary-heap Dijkstra-style search is roughly O((V+E) log V). | Optimal for one route in the current residual graph; sequential greedy allocation is not globally optimal. |
| A* | Road travel has a destination and a geographic lower bound. f(n)=g(n)+h(n) prioritizes promising paths. | Optimality depends on nonnegative costs and a valid heuristic. Worst-case work can still be large. |
| Genetic algorithm | Job permutations grow factorially. Population search explores competing orders without enumerating all n! permutations. | Heuristic, not a proof of optimum. On tiny cases an exhaustive search can be simpler and stronger. Compare against baselines. |
| CSP | Feasibility is central: each slot must meet the shedding band while respecting daily caps and consecutive-cut limits. MRV and forward checking reduce wasted branching. | Backtracking is exponential in the worst case. The solver has a search budget; “not found” does not prove mathematical infeasibility. |
| Simulated annealing | Improves a feasible schedule by allowing some worse moves early, then cooling. Useful for escaping local minima in fairness/switching tradeoffs. | Stochastic heuristic; better combined energy does not guarantee every individual metric improves. |
| Minimax + alpha-beta | Suitable for a bounded adversary/planner thought experiment. Pruning preserves the same search value for the same game tree and evaluation. | Hypothetical worst case, not a failure probability forecast. Actual pruning benefit depends on move order. |

**Why not one algorithm?** Connectivity, weighted paths, job permutations, timetable constraints and adversarial choices are different problem structures. Multiple algorithms are justified by these roles; adding algorithms merely to increase the count would not improve the system.

## 9. Equations and settings you should know

- **UCS route cost:** sum of line lengths plus 1 km-equivalent for every normally-open line on the path. This is a modelling penalty, not money, electrical loss or switching time. The implementation applies it to each route using that line.
- **A* heuristic:** straight-line distance / 50 km/h × 60 minutes. Model road edges use a 1.25 detour factor and 30 km/h. The heuristic is a lower bound under these assumptions.
- **Crew objective:** sum over faults of `(priority-weighted dependent MW × completion minutes)`. Lower is better. This differs from minimizing the makespan, which is the latest crew finish time.
- **Priority weights:** hospitals 10, industrial 3, markets 2, residential 1. These are explicit policy choices, not learned values.
- **GA defaults:** population 60, 80 generations, tournament size 3, crossover probability 0.9, mutation probability 0.25, two elites.
- **Shedding horizon:** 12 slots × 2 hours. Default consecutive-cut cap is 2 slots (4 hours); the search can relax it to 3 or 4 slots. Daily caps can also relax. The replay reports what was used.
- **Fairness:** Jain = `(sum x)^2 / (n × sum x²)`. Here x is cut-slot count divided by the priority-class tolerance: 0.6 industrial, 0.8 market, 1.0 residential. Therefore 1.0 means equal normalized burden, not necessarily equal cut hours.
- **Annealing energy:** `10 × (1 − Jain) + 0.02 × breaker operations`. Initial temperature 1.0; cooling factor 0.995; 6,000 attempts. Invalid neighbors are rejected.
- **Breaker operations:** initial cut-set size plus symmetric differences between consecutive slots. The existing metric does not count a final end-of-day reconnection.
- **Stress resilience:** fraction of currently served weighted load surviving additional worst-case loss under the simplified evaluation. It is not a real-world reliability percentage.

## 10. Honest limitations and how to explain them

**Electrical model:** This is whole-zone path allocation. It does not solve AC/DC power flow, voltage limits, reactive power, losses, protection coordination or radiality. Source and line MW caps are checked for restoration routes, but transformer thermal limits are not separately modelled.

**Timetable:** The CSP is aggregate-MW feasible under its constraints. It does not reroute and validate every energized zone against every line in each time slot. A proposed cut therefore appears as an overlay while the map's numeric MW remains the restoration reference. Do not claim the timetable is ready for field operation. Per-slot capacity-constrained routing is a strong next extension.

**Stress score:** The original minimax evaluator checks connectivity and source capacity but ignores line capacities. The demonstration's hypothetical frames separately compute capacity-checked allocations; these MW figures can differ from the simplified minimax score. This discrepancy is explicitly disclosed.

**Repair plan:** Crew completion times are predicted. Showing a planned visit does not clear the fault or simulate the post-repair network. Repair completion followed by rerouting would be another useful extension.

**Critical loads:** Hospitals are prioritized and excluded from planned voluntary cuts. This cannot guarantee hospital power when faults isolate them or available supply is inadequate.

**Data and scope:** This is a small illustrative network with estimated inputs, static travel times and fixed repair durations. No live telemetry, real switches or dispatch systems are connected. The replay is a decision-level explanation, not an instruction-by-instruction execution trace.

## 11. Likely viva questions

**What is the difference between load shedding and isolation?** Shedding intentionally reduces connected demand to match supply. Isolation means a fault has removed every usable path; a timetable cannot repair that path.

**Why does a hospital get served before a residential zone?** Priority ordering reserves capacity for more critical services first. This is a policy encoded in the model.

**Why can BFS return a different route from UCS?** BFS counts edges equally; UCS sums their weighted costs.

**What makes the A* heuristic admissible here?** Straight-line travel at 50 km/h cannot exceed the model's longer road travel at 30 km/h. That argument must be revisited if the road data or speed assumptions change.

**Why use a GA when there are few faults?** It demonstrates a method applicable to larger permutation spaces. For a handful of faults, exhaustive enumeration is a valid alternative and could establish an optimum for comparison.

**Is the GA guaranteed to beat nearest-first?** No. Compare the measured scores; a heuristic can tie or lose to a baseline.

**Why CSP before annealing?** CSP first finds a feasible timetable; annealing then tries feasible changes to improve its objective.

**Can fairness get worse after annealing?** Yes, an improvement in switching operations may compensate in the combined objective. Check both metrics and the combined energy.

**Does pruning change the minimax answer?** With the same game tree, evaluation and depth, alpha-beta preserves the value. Equal-valued action choices can differ with ordering.

**Why does the map use a schematic?** To separate labels and reveal electrical relationships. Algorithm costs still use the geographic model coordinates; the screen layout changes no inputs.

**Does Back rerun the algorithms?** No. It selects an independent snapshot, so the explanation and values are restored together.

**What does MW versus MWh mean?** MW is instantaneous power demand or allocation. MWh is energy: a 10 MW cut lasting two hours leaves 20 MWh unserved.

**What would make this production-ready?** Validated network data, physical power-flow and protection constraints, per-slot routing, telemetry, contingency validation, operational approvals and much stronger testing. These are future engineering requirements, not current features.

## 12. Rehearsal and troubleshooting

1. Install dependencies and run the project before class, then test it offline.
2. Keep seed 42, rehearse Scenario 1, and know how to jump directly to each stage.
3. Prepare Scenario 2 for isolation and Scenario 3 for capacity shortage.
4. Read one source, one line and one hospital card aloud. Explain units correctly.
5. Keep inactive ties hidden until asked about redundancy.
6. If the window is crowded, hide Side panel, maximize, or return from enlarged-text mode.
7. If Python cannot find `src`, confirm the whole ZIP was extracted and launch the root `gui.py`.
8. If no display is available (e.g. a headless server), run the command-line application or view the guide; Tk needs a desktop display.
9. Do not interpret a failed CSP search as proof of infeasibility; mention search limits and relaxations.
10. End with: “This project makes the decision process inspectable; its main next step is validating each proposed schedule against a richer physical grid model.”

## 13. Code map and verification

| File | Responsibility |
|---|---|
| `gui.py` | Desktop entry point |
| `main.py` | Original command-line entry point |
| `src/pipeline.py` | Runs all decision services |
| `src/gui/demo_tab.py` | Playback, stage navigation, inspector, export |
| `src/gui/demo_trace.py` | Reversible decision snapshots |
| `src/gui/demo_map.py` | Schematic symbols, lines and MW labels |
| `src/services/` | Fault, restoration, crew, shedding and stress logic |
| `src/algorithms/` | Reusable search and optimization implementations |
| `tests/test_replay.py` | Replay equivalence, frame isolation, capacity and fault regressions |

Run all tests from the project root with `python -m unittest discover -s tests`. Some Tk tests skip when no display is available. See `docs/VALIDATION.md` for the checks performed on this delivered version.
