# Demonstration edition — changes

## Presentation

- Added a dedicated first tab with an uncluttered electrical schematic; retained the geographic view as tab 8.
- Added independent replay frames for healthy reference, incident, individual DFS visits, BFS backup diagnostics, individual UCS allocations, crew travel plans, schedule slots, hypothetical stress moves and the actual-plan summary.
- Added Back/Next, reset, autoplay/pause, stage jumps, timeline scrubbing and keyboard navigation.
- Added synchronized allocated MW, source capacities, line ratings and explicit node types and statuses.
- Added clickable full component details, optional inactive ties and replay JSON export.
- Reserved space for controls/explanations and corrected initial Tk/Matplotlib DPI sizing.
- Preserved detailed restoration, crew, timetable, stress and benchmark views.

## Correctness and stability

- A failed demand node can no longer receive a route, including capacity-free diagnostic searches.
- A positive deficit with an empty eligible shedding pool is reported as infeasible instead of incorrectly saying no deficit exists.
- Road adjacency construction is sorted to stabilize equal-cost route choices across runs.
- Figure replacement cancels pending old-canvas callbacks.
- Corrected descriptions of BFS (minimum hops, not minimum switches) and the simplified stress evaluation.

## Documentation

- Added a self-contained HTML demonstration guide and editable Markdown source.
- Included setup, symbol legend, timed script, verified seed-42 outcomes, algorithms, equations, parameter choices, viva questions and troubleshooting.
- Documented aggregate-only timetable feasibility, simplified stress scoring, heuristic limits and planned-versus-completed repair semantics.

The algorithms and input network remain educational models; this release does not add live grid control or physical power-flow simulation.
