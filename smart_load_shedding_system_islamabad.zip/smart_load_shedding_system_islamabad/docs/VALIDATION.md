# Validation — 29 October 2026

## Latest resumed-session run

Command: `python -m unittest discover -s tests`

**43 tests discovered: 41 passed, 2 skipped, no failures.** The two skipped tests require a Tk desktop display, which was unavailable in the resumed session.

Coverage includes existing search, data, service, chart and controller tests, plus replay regressions across all five scenarios:

- Final replay restoration equals the pipeline's allocation.
- DFS replay visits equal the service's reachable-node set.
- Frames do not share mutable state.
- Displayed allocations respect source/line capacities and failed components.
- Hospitals do not appear in voluntary scheduled cuts.
- Crew replay paths follow actual road edges.
- A failed zone cannot receive an allocation.
- Positive deficit with no eligible shedding pool is infeasible.
- Every replay stage can render as a figure.

## Earlier native-window verification in this task

The Tk application was run in a virtual display and visually inspected at 1400 × 840. This caught and led to fixes for hidden replay controls and initial DPI clipping. The corrected window showed the schematic, symbol legend, inspector, playback controls and explanation together. An earlier 42-test suite passed with the desktop smoke test enabled before the final additional navigation/layout test was added.

The latest added navigation/layout test targets a 1366 × 768 window, Back/Next caption restoration, stage jumps, playback cancellation, presentation mode and reset after analysis. It is included, but skipped in the latest headless run. No claim is made that the completed package was tested on the user's Windows computer.

## Scope

Passing these tests establishes consistency for the supplied small model, not engineering validity for a real electricity network. In particular, the timetable is aggregate-only, and the original minimax evaluator ignores line limits. See the demonstration guide for exact limitations.
