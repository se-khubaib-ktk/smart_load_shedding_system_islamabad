# Demonstration guide

The current guide is [DEMONSTRATION_GUIDE.html](DEMONSTRATION_GUIDE.html), which opens offline in your browser. A [Markdown version](DEMONSTRATION_GUIDE.md) is also included. It covers setup, an 8–10 minute presentation, algorithm justifications, expected results, viva answers and limitations.
