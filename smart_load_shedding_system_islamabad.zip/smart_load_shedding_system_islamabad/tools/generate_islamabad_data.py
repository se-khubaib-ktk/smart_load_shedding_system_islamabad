"""Builds data/grid.json and data/scenarios.json for the Islamabad / Rawalpindi model.

    python tools/generate_islamabad_data.py            write the data files and run the checks
    python tools/generate_islamabad_data.py --check    only run the checks (nothing is written)

How the coordinates are made
----------------------------
1. Every place has a latitude/longitude and a "how" tag saying where it came from:
     source    -- a coordinate found in a published source (see SOURCES below)
     lattice   -- the centre of an Islamabad sector, interpolated from the regular
                  ~2 km sector grid (see sector_centre); validated against sources
     estimate  -- placed by hand near the named area because no coordinate was found
                  (accuracy about +-2 km); used for most grid-station sites
2. Latitude/longitude are converted to kilometres with an equirectangular projection
   around the centre of Islamabad:  x = R * dlon * cos(lat0),  y = R * dlat.
   The result is shifted so that the south-west corner sits at about (1 km, 1 km),
   which keeps every coordinate positive like the original data file.
3. The checks at the end make sure every road is at least as long as the straight line
   between its ends (so the A* heuristic stays admissible) and that the healthy grid
   serves every zone without overloading anything.

IMPORTANT: place names and approximate positions are real. Line topology, capacities
and demands are ILLUSTRATIVE ESTIMATES, not official IESCO or NTDC data.
"""
import argparse
import json
import math
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

EARTH_RADIUS_KM = 6371.0088
LAT0, LON0 = 33.68, 73.05            # projection centre (central Islamabad)

# ---------------------------------------------------------------------------
# Sources (retrieved while building this model; see README "Data sources")
# ---------------------------------------------------------------------------
SOURCES = {
    "N1": "NGA GeoNames gazetteer, Pakistan Institute of Medical Sciences "
          "(33.702832, 73.053291) - geonames.nga.mil",
    "W1": "Wikipedia 'Shifa International Hospital' (33.6755, 73.0672)",
    "W2": "Wikipedia 'Combined Military Hospital Rawalpindi' (33.581093, 73.047168)",
    "W3": "Wikipedia 'F-8, Islamabad' (33.7115884, 73.0396297) - lattice anchor",
    "W4": "Wikipedia 'H-8, Islamabad' (33.6826, 73.0649) - lattice anchor",
    "W5": "Wikipedia 'I-10, Islamabad' (33.64687, 73.03616) - used to validate the lattice",
    "W6": "Wikipedia 'Islamabad Model Special Economic Zone' (33.49062, 73.19818)",
    "W7": "Wikipedia 'Rawalpindi Cantonment' (33.59583, 73.04611) - Saddar lies inside it",
    "W8": "Wikipedia 'Satellite Town, Rawalpindi' (33.63333, 73.06667)",
    "W9": "Wikipedia 'Sangjani railway station' (33.6963, 72.8504) - proxy for Sangjani village",
    "G1": "Geocords.com street geocode, Bahria Town Phase IV (33.549356, 73.1308576)",
    "I1": "IESCO Planning & Investigation page - list of 132 kV / 220 kV grid stations "
          "and IESCO head office in G-7/4 - iesco.com.pk/index.php/pai-division-islamabad",
    "A1": "APP news: fault at 132 kV F-11 grid station affecting F-10, F-11, G-11 feeders",
    "A2": "APP news (1 Jul): technical fault at 220 kV Sangjani grid station disrupts supply "
          "to grid stations serving Islamabad, Rawalpindi and Attock",
    "P1": "Profit / NTDC: 500 kV Rawat grid station is a major hub for northern Punjab, "
          "supplying Rawalpindi and Islamabad",
    "Z1": "Zameen.com 'Famous markets in Islamabad' - Jinnah Super Market (F-7), "
          "Super Market (F-6), Karachi Company (G-9)",
    "C1": "ICCI business tips - main industrial areas are I-9, I-10 and the Kahuta triangle "
          "(Sihala); steel, marble, pharmaceuticals, flour, soap, light engineering",
}

# ---------------------------------------------------------------------------
# Sector lattice: Islamabad's sectors form a regular, slightly rotated grid
# (about 2 km x 2 km each). Letters run north -> south, numbers run east -> west.
# The anchors F-8 and H-8 (two rows apart) give the row step; the column step is the
# row step turned by 90 degrees.
# ---------------------------------------------------------------------------
def to_km(lat, lon):
    x = math.radians(lon - LON0) * EARTH_RADIUS_KM * math.cos(math.radians(LAT0))
    y = math.radians(lat - LAT0) * EARTH_RADIUS_KM
    return x, y


def to_latlon(x, y):
    lat = LAT0 + math.degrees(y / EARTH_RADIUS_KM)
    lon = LON0 + math.degrees(x / (EARTH_RADIUS_KM * math.cos(math.radians(LAT0))))
    return lat, lon


_F8 = to_km(33.7115884, 73.0396297)
_H8 = to_km(33.6826, 73.0649)
_ROW = ((_H8[0] - _F8[0]) / 2, (_H8[1] - _F8[1]) / 2)        # one letter step (F -> G)
_COL = (_ROW[1], -_ROW[0])                                   # one number step (8 -> 9)


def sector_centre(letter, number):
    """Approximate (lat, lon) of the centre of sector e.g. ('G', 9)."""
    rows = "EFGHI".index(letter) - 1                          # F is row 0
    cols = number - 8                                         # 8 is column 0
    return to_latlon(_F8[0] + rows * _ROW[0] + cols * _COL[0],
                     _F8[1] + rows * _ROW[1] + cols * _COL[1])


def km_between(a, b):
    ax, ay = to_km(*a)
    bx, by = to_km(*b)
    return math.hypot(ax - bx, ay - by)


# ---------------------------------------------------------------------------
# Places.  (id, name, type, (lat, lon), how, sources/notes, extras)
#   zones: demand_mw + priority;  sources: capacity_mw
# Demand basis (all ESTIMATES, MW at evening peak, aggregate for the named area):
#   hospital 5-6 MW     large tertiary hospital (HVAC, theatres, imaging, labs)
#   industrial 18-24 MW many small and medium units (steel, marble, pharma, food)
#   market 13-15 MW     one commercial markaz / bazaar (shops, lifts, air-conditioning)
#   residential 13-20   a sector or housing scheme of several thousand homes at about
#                       1.5-2 kW diversified evening peak per home
# Source capacity is the share of the real station that the 12 modelled zones may use,
# NOT the nameplate rating of the real station.
# ---------------------------------------------------------------------------
PLACES = [
    # --- grid stations (bulk supply points) -------------------------------------
    ("S1", "Sangjani 220 kV Grid Station", "source", (33.6963, 72.8504), "estimate",
     "W9, A2: real NTDC/IESCO station; position proxied by Sangjani village", {"capacity_mw": 100}),
    ("S2", "Rawat 500 kV Grid Station", "source", (33.4900, 73.1830), "estimate",
     "P1: real NTDC station near Rawat; exact site not retrieved", {"capacity_mw": 90}),
    # --- 132 kV grid stations used as transformer / feeder points ---------------
    ("T1", "F-11 132 kV GSS", "transformer", sector_centre("F", 11), "lattice",
     "A1, I1: real IESCO station; placed at the centre of sector F-11", {}),
    ("T2", "Zero Point 132 kV GSS", "transformer", (33.6945, 73.0640), "estimate",
     "I1: real IESCO station; placed near the Zero Point interchange (+-2 km)", {}),
    ("T3", "I-8 132 kV GSS", "transformer", sector_centre("I", 8), "lattice",
     "I1: real IESCO station; placed at the centre of sector I-8", {}),
    ("T4", "Satellite Town 132 kV GSS", "transformer", (33.6340, 73.0790), "estimate",
     "I1, W8: real IESCO station; placed in Satellite Town, Rawalpindi (+-2 km)", {}),
    ("T5", "Chaklala 132 kV GSS", "transformer", (33.6100, 73.0950), "estimate",
     "I1: real IESCO station; placed near Chaklala (+-2 km)", {}),
    ("T6", "Old Rawat 132 kV GSS", "transformer", (33.5000, 73.1950), "estimate",
     "I1: real IESCO station; placed in the Rawat area (+-2 km)", {}),
    # --- consumer zones ----------------------------------------------------------
    ("Z1", "PIMS Hospital (G-8)", "zone", (33.702832, 73.053291), "source",
     "N1", {"demand_mw": 6, "priority": 1}),
    ("Z2", "Shifa International Hospital (H-8)", "zone", (33.6755, 73.0672), "source",
     "W1", {"demand_mw": 5, "priority": 1}),
    ("Z3", "CMH Rawalpindi", "zone", (33.581093, 73.047168), "source",
     "W2", {"demand_mw": 6, "priority": 1}),
    ("Z4", "I-9 Industrial Area", "zone", sector_centre("I", 9), "lattice",
     "C1: centre of sector I-9", {"demand_mw": 24, "priority": 2}),
    ("Z5", "Rawat Industrial Area (IMSEZ)", "zone", (33.49062, 73.19818), "source",
     "W6: Islamabad Model SEZ near Rawat; load is modelled", {"demand_mw": 18, "priority": 2}),
    ("Z6", "Jinnah Super Market (F-7)", "zone", sector_centre("F", 7), "lattice",
     "Z1: F-7 markaz; centre of sector F-7", {"demand_mw": 13, "priority": 3}),
    ("Z7", "Karachi Company (G-9)", "zone", sector_centre("G", 9), "lattice",
     "Z1: G-9 markaz; centre of sector G-9", {"demand_mw": 14, "priority": 3}),
    ("Z8", "Saddar Bazaar (Rawalpindi)", "zone", (33.59583, 73.04611), "source",
     "W7: Rawalpindi Cantonment, which contains Saddar", {"demand_mw": 15, "priority": 3}),
    ("Z9", "F-6 Sector", "zone", sector_centre("F", 6), "lattice",
     "centre of sector F-6 (Wikipedia's own F-6 coordinate is wrong and was NOT used)",
     {"demand_mw": 13, "priority": 4}),
    ("Z10", "G-11 Sector", "zone", sector_centre("G", 11), "lattice",
     "A1: centre of sector G-11", {"demand_mw": 14, "priority": 4}),
    ("Z11", "Satellite Town (Rawalpindi)", "zone", (33.63333, 73.06667), "source",
     "W8", {"demand_mw": 16, "priority": 4}),
    ("Z12", "Bahria Town Phase 4", "zone", (33.549356, 73.1308576), "source",
     "G1: street-level geocode", {"demand_mw": 20, "priority": 4}),
    # --- repair depots -------------------------------------------------------------
    ("D1", "IESCO Head Office Depot (G-7/4)", "depot", sector_centre("G", 7), "lattice",
     "I1: IESCO head office is in sector G-7/4; depot role is modelled", {}),
    ("D2", "Rawalpindi Repair Depot (modelled)", "depot", (33.5990, 73.0830), "estimate",
     "modelled depot between Saddar and Chaklala; no official depot location was found", {}),
]

# Power lines: (id, from, to, capacity_mw, normally_open)
LINES = [
    # feeders from the two grid stations
    ("F1", "S1", "T1", 40, False), ("F2", "S1", "T2", 55, False), ("F3", "S1", "T3", 45, False),
    ("F4", "S2", "T4", 40, False), ("F5", "S2", "T5", 40, False), ("F6", "S2", "T6", 35, False),
    # one spur from each transformer to each of its zones (capacity = 1.5 x demand)
    ("P1", "T1", "Z10", 21, False), ("P2", "T1", "Z7", 21, False),
    ("P3", "T2", "Z1", 9, False), ("P4", "T2", "Z6", 20, False), ("P5", "T2", "Z9", 20, False),
    ("P6", "T3", "Z2", 8, False), ("P7", "T3", "Z4", 36, False),
    ("P8", "T4", "Z11", 24, False), ("P9", "T4", "Z8", 23, False),
    ("P10", "T5", "Z3", 9, False), ("P11", "T5", "Z12", 30, False),
    ("P12", "T6", "Z5", 27, False),
    # backup feeders (normally open): hospitals first, then the big industrial loads
    ("B1", "T3", "Z1", 9, True), ("B2", "T2", "Z2", 8, True), ("B3", "T4", "Z3", 9, True),
    ("B4", "T2", "Z4", 36, True), ("B5", "T5", "Z5", 27, True),
    # tie switches between neighbouring transformers (normally open)
    ("TL1", "T1", "T2", 30, True), ("TL2", "T2", "T4", 30, True), ("TL3", "T3", "T4", 30, True),
    ("TL4", "T3", "T5", 30, True), ("TL5", "T5", "T6", 30, True),
]

# Extra roads for repair crews (every power line is also a road).
EXTRA_ROADS = [
    ("D1", "T1"), ("D1", "T2"), ("D1", "T3"), ("D1", "Z1"), ("D1", "Z6"), ("D1", "Z9"),
    ("D1", "D2"), ("D2", "T4"), ("D2", "T5"), ("D2", "Z8"), ("D2", "Z3"), ("D2", "T6"),
    ("S1", "D1"), ("S2", "D2"), ("S2", "T6"),
    ("Z1", "Z2"), ("Z2", "Z4"), ("Z6", "Z9"), ("Z7", "Z10"), ("Z7", "Z4"),
    ("Z8", "Z3"), ("Z8", "Z11"), ("Z11", "T5"), ("Z12", "T6"), ("Z12", "Z3"), ("Z5", "Z12"),
    ("T2", "T3"), ("T4", "T5"),
]

# Scenarios (state of the grid) - professional names + one-sentence descriptions.
SCENARIOS = [
    {"id": 1, "name": "Feeder cable fault: Sangjani - Zero Point circuit",
     "description": "The 132 kV circuit from Sangjani Grid Station to the Zero Point GSS "
                    "trips, cutting PIMS, F-6 and the F-7 market off their normal feed.",
     "failed_lines": ["F2"], "failed_nodes": [], "source_derate": {}, "crews": ["D1", "D2"]},
    {"id": 2, "name": "Transformer failure at Chaklala GSS",
     "description": "The power transformer at Chaklala GSS burns out; CMH has a backup "
                    "feeder but Bahria Town has none and waits for repair.",
     "failed_lines": [], "failed_nodes": ["T5"], "source_derate": {}, "crews": ["D1", "D2"]},
    {"id": 3, "name": "Sangjani Grid Station partial trip",
     "description": "Sangjani drops from 100 MW to 55 MW after a generation shortfall, "
                    "so the north-west of the city must share the remaining power.",
     "failed_lines": [], "failed_nodes": [], "source_derate": {"S1": 55}, "crews": ["D1", "D2"]},
    {"id": 4, "name": "Sangjani Grid Station full outage",
     "description": "Sangjani goes offline completely; the Islamabad sectors must be fed "
                    "through tie switches from the Rawat side.",
     "failed_lines": [], "failed_nodes": [], "source_derate": {"S1": 0}, "crews": ["D1", "D2"]},
    {"id": 5, "name": "Monsoon storm over the Margalla Hills (multiple faults)",
     "description": "Storm damage trips two feeders, two grid stations and a spur line "
                    "while Rawat is derated.",
     "failed_lines": ["F2", "F5", "P1"], "failed_nodes": ["T3", "T6"],
     "source_derate": {"S2": 70}, "crews": ["D1", "D2"]},
]


# ---------------------------------------------------------------------------
def build_grid_dict():
    """Project all places to km and return the dictionary that becomes grid.json."""
    xy = {pid: to_km(*latlon) for pid, _n, _t, latlon, *_rest in PLACES}
    min_x = min(x for x, _ in xy.values())
    min_y = min(y for _, y in xy.values())
    nodes = {}
    for pid, name, kind, _latlon, _how, _note, extra in PLACES:
        x, y = xy[pid]
        node = {"name": name, "type": kind,
                "x": round(x - min_x + 1.0, 2), "y": round(y - min_y + 1.0, 2)}
        node.update(extra)
        nodes[pid] = node
    return {
        "city": "Islamabad (simplified IESCO model)",
        "nodes": nodes,
        "lines": [{"id": i, "from": a, "to": b, "capacity_mw": c, "normally_open": o}
                  for i, a, b, c, o in LINES],
        "extra_roads": [list(p) for p in EXTRA_ROADS],
    }


def run_checks(grid_path):
    """Validate the generated grid. Raises AssertionError with a clear message."""
    from src import config
    from src.models.grid import load_grid
    from src.models.state import GridState
    from src.services.supply import assign_supply

    # 1. validate the sector lattice against an independent coordinate
    gap = km_between(sector_centre("I", 10), (33.64687, 73.03616))
    print(f"lattice check: I-10 centre vs Wikipedia I-10 point differ by {gap:.2f} km")
    assert gap < 1.5, "sector lattice is off"

    grid = load_grid(grid_path)

    # 2. no two nodes on top of each other
    ids = list(grid.nodes)
    closest = min((grid.distance_km(a, b), a, b) for i, a in enumerate(ids) for b in ids[i + 1:])
    print(f"closest pair of nodes: {closest[1]}-{closest[2]} at {closest[0]:.2f} km")
    assert closest[0] > 0.5, f"nodes {closest[1]} and {closest[2]} overlap"

    # 3. every road is at least as long as the straight line (A* stays admissible)
    km_per_min = config.ROAD_SPEED_KMH / 60.0
    worst = 1e9
    for a, edges in grid.roads.items():
        for b, minutes in edges:
            ratio = minutes * km_per_min / grid.distance_km(a, b)
            worst = min(worst, ratio)
            assert ratio >= 1.0 - 1e-9, f"road {a}-{b} is shorter than the straight line"
    print(f"road length / straight line: smallest ratio {worst:.2f} (must be >= 1.00)")

    # 4. heuristic never overestimates the true shortest travel time (Floyd-Warshall)
    inf = float("inf")
    dist = {a: {b: (0.0 if a == b else inf) for b in ids} for a in ids}
    for a, edges in grid.roads.items():
        for b, minutes in edges:
            dist[a][b] = min(dist[a][b], minutes)
    for k in ids:
        for i in ids:
            for j in ids:
                if dist[i][k] + dist[k][j] < dist[i][j]:
                    dist[i][j] = dist[i][k] + dist[k][j]
    for a in ids:
        for b in ids:
            assert dist[a][b] < inf, f"road network is not connected ({a}-{b})"
            h = grid.distance_km(a, b) / config.MAX_SPEED_KMH * 60.0
            assert h <= dist[a][b] + 1e-9, f"A* heuristic overestimates {a}-{b}"
    print("A* heuristic is admissible for every pair of nodes")

    # 5. healthy grid serves every zone and nothing is overloaded
    base = assign_supply(grid, GridState(), allow_open=False)
    assert len(base.routes) == len(grid.zones), "healthy grid does not serve every zone"
    for line_id, load in base.line_load.items():
        assert load <= grid.lines[line_id].capacity_mw, f"line {line_id} overloaded"
    for source in grid.sources:
        assert base.source_load[source.id] <= source.capacity_mw, f"{source.id} overloaded"
    loads = ", ".join(f"{s.id} {base.source_load[s.id]:.0f}/{s.capacity_mw:.0f} MW" for s in grid.sources)
    print(f"healthy grid serves {len(base.routes)} zones, "
          f"{grid.total_demand():.0f} MW total  ({loads})")


def write_provenance(path):
    """docs/PLACES.md: where every coordinate came from."""
    lines = ["# Places, positions and provenance\n",
             "Generated by `tools/generate_islamabad_data.py`. Names are real; positions are "
             "approximate; demands and capacities are illustrative estimates.\n",
             "| ID | Name | Type | Lat, Lon | Position basis | Notes |", "|---|---|---|---|---|---|"]
    for pid, name, kind, (lat, lon), how, note, extra in PLACES:
        lines.append(f"| {pid} | {name} | {kind} | {lat:.4f}, {lon:.4f} | {how} | {note} |")
    lines += ["", "## Source codes", ""]
    lines += [f"* **{k}** - {v}" for k, v in SOURCES.items()]
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def main():
    parser = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    parser.add_argument("--check", action="store_true", help="only validate the existing files")
    args = parser.parse_args()

    grid_file = ROOT / "data" / "grid.json"
    scenario_file = ROOT / "data" / "scenarios.json"
    if not args.check:
        grid_file.write_text(json.dumps(build_grid_dict(), indent=1) + "\n", encoding="utf-8")
        scenario_file.write_text(json.dumps(SCENARIOS, indent=1) + "\n", encoding="utf-8")
        write_provenance(ROOT / "docs" / "PLACES.md")
        print(f"wrote {grid_file.name}, {scenario_file.name} and docs/PLACES.md")
    run_checks(grid_file)
    print("all checks passed")


if __name__ == "__main__":
    main()
