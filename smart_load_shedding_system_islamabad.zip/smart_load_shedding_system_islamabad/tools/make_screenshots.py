"""Renders the figure shown on every GUI tab into docs/screenshots/ (no display needed).

    python tools/make_screenshots.py

The GUI itself embeds exactly these matplotlib figures, so these files show what each tab
displays. They are figure renders, not photographs of the Tk window (cards, tables and
buttons are not included).
"""
import io
import sys
from pathlib import Path

import matplotlib
matplotlib.use("Agg")

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from src.gui import figures                       # noqa: E402
from src.gui.controller import AnalysisController  # noqa: E402

OUT = ROOT / "docs" / "screenshots"


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    controller = AnalysisController(lambda ms, fn: None)
    grid = controller.grid
    analysis = controller.analyze(controller.scenarios[4], 42)       # the busiest scenario
    quiet = controller.analyze(controller.scenarios[2], 42)          # a partial trip
    shots = {
        "1_overview_map.png": figures.map_figure(grid, analysis)[0],
        "1_overview_step_detect.png": figures.map_figure(grid, analysis, "detect")[0],
        "1_overview_step_dispatch.png": figures.map_figure(grid, analysis, "dispatch")[0],
        "2_restoration_route_focus.png": figures.map_figure(grid, analysis, "restore", "Z1")[0],
        "3_crews_timeline.png": figures.gantt_figure(grid, analysis),
        "3_crews_ga_comparison.png": figures.crew_comparison_figure(analysis),
        "3_crews_ga_convergence.png": figures.convergence_figure(analysis),
        "4_shedding_heatmap.png": figures.heatmap_figure(grid, analysis, "both"),
        "4_shedding_partial_trip.png": figures.heatmap_figure(grid, quiet, "both"),
        "5_stress_pruning.png": figures.stress_figure(analysis),
        "5_stress_worst_case_map.png": figures.map_figure(grid, analysis, "stress")[0],
        "6_how_it_works_pipeline.png": figures.pipeline_figure("shed"),
    }
    data = controller.benchmark(42)
    from src.gui import viewmodel as vm
    parsed = vm.parse_benchmark(data.rows, data.scenario_names)
    for i, (title, fig) in enumerate(figures.benchmark_figures(parsed).items(), 1):
        shots[f"7_benchmark_{i}_{title.lower().replace(' ', '_').replace('-', '_')}.png"] = fig
    for name, fig in shots.items():
        fig.savefig(OUT / name, dpi=110)
        print("saved", OUT / name)


if __name__ == "__main__":
    main()
