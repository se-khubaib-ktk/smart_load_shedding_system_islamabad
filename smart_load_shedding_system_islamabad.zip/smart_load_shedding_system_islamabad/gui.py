"""Starts the desktop GUI:  python gui.py"""
import sys


def start():
    try:
        import tkinter  # noqa: F401  (ships with Python; some Linux systems need python3-tk)
    except ImportError:
        sys.exit("tkinter is not installed. On Debian/Ubuntu run: sudo apt install python3-tk")
    try:
        import matplotlib  # noqa: F401
    except ImportError:
        sys.exit("matplotlib is missing. Install it with: pip install -r requirements.txt")
    if sys.platform == "win32":      # crisp text: without this Windows stretches the window as a blurry bitmap
        try:
            import ctypes
            ctypes.windll.shcore.SetProcessDpiAwareness(1)
        except Exception:
            pass
    from src.gui.app import main
    main()


if __name__ == "__main__":
    start()
