"""Smart Load-Shedding and Restoration System - command line entry point.

    python main.py                 interactive menu
    python main.py --list          list scenarios
    python main.py --scenario 3    run one scenario
    python main.py --all           run every scenario
    python main.py --benchmark     compare the algorithms
Add --plot to save pictures into the outputs/ folder.
"""
import argparse

from src import config
from src.models.grid import load_grid
from src.models.state import load_scenarios
from src.pipeline import run_scenario


def parse_args():
    parser = argparse.ArgumentParser(description="Smart Load-Shedding and Restoration System")
    parser.add_argument("--list", action="store_true", help="list the scenarios")
    parser.add_argument("--scenario", type=int, help="run one scenario by number")
    parser.add_argument("--all", action="store_true", help="run every scenario")
    parser.add_argument("--benchmark", action="store_true", help="run the algorithm benchmark")
    parser.add_argument("--plot", action="store_true", help="save pictures to outputs/")
    parser.add_argument("--seed", type=int, default=config.DEFAULT_SEED, help="random seed")
    return parser.parse_args()


def list_scenarios(scenarios):
    print("\nAvailable scenarios:")
    for sc in scenarios:
        print(f"  {sc.id}. {sc.name}")


def menu(grid, scenarios, args):
    while True:
        print("\n=== Smart Load-Shedding and Restoration System ===")
        list_scenarios(scenarios)
        print("  A. run all scenarios")
        print("  B. run the algorithm benchmark")
        print("  P. toggle saving plots (currently %s)" % ("ON" if args.plot else "OFF"))
        print("  Q. quit")
        choice = input("Choose: ").strip().lower()
        if choice == "q":
            break
        elif choice == "a":
            for sc in scenarios:
                run_scenario(grid, sc, args.seed, plot=args.plot)
        elif choice == "b":
            from benchmarks.benchmark import run_benchmark
            run_benchmark(grid, scenarios, args.seed)
        elif choice == "p":
            args.plot = not args.plot
        elif choice.isdigit() and 1 <= int(choice) <= len(scenarios):
            run_scenario(grid, scenarios[int(choice) - 1], args.seed, plot=args.plot)
        else:
            print("Please choose one of the options shown.")


def main():
    args = parse_args()
    grid = load_grid()
    scenarios = load_scenarios()

    if args.list:
        list_scenarios(scenarios)
    elif args.benchmark:
        from benchmarks.benchmark import run_benchmark
        run_benchmark(grid, scenarios, args.seed)
    elif args.all:
        for sc in scenarios:
            run_scenario(grid, sc, args.seed, plot=args.plot)
    elif args.scenario:
        matching = [s for s in scenarios if s.id == args.scenario]
        if not matching:
            raise SystemExit(f"No scenario number {args.scenario}. Use --list.")
        run_scenario(grid, matching[0], args.seed, plot=args.plot)
    else:
        menu(grid, scenarios, args)


if __name__ == "__main__":
    main()
